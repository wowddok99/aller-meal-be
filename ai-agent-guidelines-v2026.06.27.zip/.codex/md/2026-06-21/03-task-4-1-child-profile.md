# Task 4.1 ChildProfile 소유권 모델

## 작업 범위

- 인증 사용자의 자녀 생성, 목록, 단건 조회, 수정, 삭제 API를 구현했습니다.
- PostgreSQL `child_profiles`와 소유권 조건을 저장소 SQL에 적용했습니다.

## 주요 변경

- `ChildProfile` 도메인과 `ChildProfileId`, 학교·학년·반 유효성 규칙을 추가했습니다.
- 자녀 조회·수정·삭제 SQL에 `user_id` 조건을 포함해 타 사용자 접근을 차단했습니다.
- 존재하지 않는 자녀와 타 사용자 자녀는 동일하게 `404 RESOURCE_NOT_FOUND`로 응답합니다.

## 검증

- Java 21 `./gradlew.bat :safe-meal-api:build --no-daemon`: 성공
- 실제 인증 API: 자녀 생성 `201`, 소유자 삭제 `204`: 성공
- 실제 교차 소유권 API: 타 사용자 `GET`·`PATCH`·`DELETE` 모두 `404`: 성공

## 리뷰 및 다음 행동

- 초기 리뷰 finding인 누락 `schoolId`의 500 응답 경로를 `INVALID_REQUEST`로 수정했습니다.
- blocker·major 없음.
- 다음 태스크는 Task 4.2 자녀 알레르기 관리입니다.
