# Checkpoint 2 Identity E2E 검증

## 작업 범위

- 회원가입, 이메일 인증, 로그인, Refresh Token 갱신, 로그아웃, 비밀번호 재설정 전체 API 흐름을 실제 Compose 환경에서 검증했습니다.
- Access Token과 Refresh Token의 응답 본문 및 JavaScript 접근 가능 저장소 노출 여부를 점검했습니다.

## 주요 확인

- Mailpit 수신 이메일의 일회성 token으로 이메일 인증과 비밀번호 재설정을 완료했습니다.
- 로그인과 refresh는 `200`, 로그아웃과 비밀번호 재설정 확인은 `204`를 반환했습니다.
- 로그아웃 후 refresh와 이전 비밀번호 로그인은 각각 `401`로 거부됐으며, 새 비밀번호 로그인은 `200`으로 성공했습니다.
- login·refresh JSON에는 `accessToken`, `refreshToken` field가 없고, `access_token`·`refresh_token` cookie는 `HttpOnly`로 발급됐습니다. JavaScript 접근이 필요한 `csrf_token`은 인증 token이 아닙니다.

## 검증

- `docker compose --env-file .env.example config --quiet`: 성공
- `docker compose --env-file .env.example up -d` 및 `docker compose --env-file .env.example ps`: PostgreSQL, Redis, RabbitMQ, MinIO, Mailpit 모두 `healthy`
- Java 21 `./gradlew.bat clean build --no-daemon`: 성공
- 실제 API E2E: signup `201`, verification `200`, login `200`, refresh `200`, logout `204`, logout 후 refresh `401`, password reset `204`, 기존 password login `401`, 신규 password login `200`

## 리뷰 및 다음 행동

- 현재 Checkpoint 2 범위의 운영 코드 diff는 없으며, 인증 응답과 cookie 계약을 보안 관점에서 재검토한 결과 blocker·major 발견사항은 없습니다.
- 다음 태스크는 `Task 4.1 ChildProfile 소유권 모델`입니다.
