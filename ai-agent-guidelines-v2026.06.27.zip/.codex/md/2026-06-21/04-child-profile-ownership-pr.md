# PR 제목

feat: 자녀 프로필 소유권 관리 추가

# PR 본문

## 개요

인증 사용자가 자신의 자녀 프로필을 생성하고 관리할 수 있도록 ChildProfile CRUD API를 추가했습니다.

소유자 식별자는 API 요청의 인증 사용자에서만 가져오며, 저장소 조회·수정·삭제에도 소유자 조건을 적용했습니다.

## 주요 변경

- 자녀 이름, 학년, 반, 현재 학교를 관리하는 ChildProfile 도메인과 PostgreSQL 스키마를 추가했습니다.
- `/api/v1/children` CRUD API와 일관된 오류 응답을 추가했습니다.
- 타 사용자 자녀의 조회·수정·삭제를 존재 여부와 구분되지 않는 `404`로 차단했습니다.

## 영향 범위

- 인증 사용자는 여러 자녀를 독립적으로 관리할 수 있습니다.
- 자녀 식별자만으로 다른 사용자의 자녀 정보를 열람하거나 변경할 수 없습니다.

## 검증

- Java 21 `./gradlew.bat :safe-meal-api:build --no-daemon`: 성공
- 실제 API 교차 소유권 검증: 타 사용자 `GET`·`PATCH`·`DELETE` `404`, 소유자 삭제 `204`

# 커밋 메시지

```text
feat: 자녀 프로필 소유권 관리 추가

- ChildProfile 도메인과 자녀 프로필 CRUD API 추가
- PostgreSQL owner-scoped 저장소로 타 사용자 접근 차단
```
