# 계약 타입 독립 파일 구조 리팩터링 스펙 결과

## 작업 범위

- API, application 유스케이스, outbound port의 중첩 계약 타입 현황 조사
- 계약 타입 독립 파일 분리 정책과 목표 패키지 구조 결정
- 동작 보존형 구조 리팩터링 스펙과 순차 구현 태스크 작성
- 구현은 수행하지 않음

## 주요 결정

- private 구현 helper만 중첩 타입으로 허용한다.
- 외부 참조 가능한 계약 타입은 처음부터 독립 파일로 선언한다.
- API 응답은 기능별 `response`, port 입력은 `command`, port 반환은 `result`
  패키지에 배치한다.
- `CompletionResult`는 `MealCollectionCompletionResult`로 구체화한다.
- endpoint, JSON 계약, port 동작, DB schema와 외부 연동 흐름은 변경하지 않는다.
- 자동 구조 검사와 테스트 코드 작성은 이번 범위에서 제외한다.

## 검증

- 현재 중첩 타입 전수 검색 및 매핑표 대조: 완료
- 대상 계약 타입 11개와 유지 대상 private `Rows` 포함 확인: 완료
- 구현 태스크를 태스크당 최대 5파일 범위로 분할: 완료
- `git diff --check -- .codex/docs/specs/contract-type-organization-refactoring.md`: 성공

## 다음 행동

- 스펙 승인 후 Task 1 API 알레르기·학교 응답 타입 분리부터 순서대로 구현한다.
