# 계약 타입 구조 리팩터링 커밋 및 PR 문구

## 검증 결과

- `docker compose --env-file .env.example ps`: PostgreSQL, Redis, RabbitMQ, MinIO,
  Mailpit 모두 `healthy`
- Java 21 `:safe-meal-api:bootRun`: 성공
- Flyway 11개 migration 검증 및 PostgreSQL 연결: 성공
- `GET /api/v1/allergens`: HTTP 200, `code`, `name` field 계약 유지
- `GET /api/v1/public/schools`: HTTP 200, `schools`, `page`, `pageSize`,
  `totalCount` 및 학교 응답 field 계약 유지
- 잘못된 학교 검색 요청: HTTP 400, 공통 오류 응답 field 계약 유지

## 커밋 메시지

```text
refactor: 계약 타입을 독립 파일로 분리

- API 응답 계약을 기능별 response 패키지로 이동
- application port 입력·반환 계약을 command와 result 패키지로 분리
- 급식 수집 결과 타입의 이름과 위치를 명확하게 정리
- private 구현 helper만 중첩 타입으로 유지
```

## PR 제목

refactor: 계약 타입을 독립 파일로 분리

## PR 본문

## 개요

Controller, service, outbound port 내부에 중첩되어 있던 외부 참조 가능 계약 타입을
독립 파일로 분리했습니다.

API 응답 계약은 기능별 `response` 패키지에서 관리하고, application outbound port의
입력과 반환 계약은 `command`, `result` 패키지에서 관리하도록 구조를 정리했습니다.
계약 타입의 위치를 예측할 수 있어 다른 계층과 후속 기능에서 명시적으로 참조할 수
있습니다.

급식 수집 결과처럼 역할이 모호했던 타입은 책임이 드러나는 이름과 위치로 변경했습니다.
중첩 타입은 외부 계약이 아닌 private 구현 helper에만 사용하도록 프로젝트 규칙도
문서화했습니다.

기존 API endpoint, JSON field, 급식 수집 동작과 외부 연동 계약은 변경하지 않았습니다.

## 주요 변경

### API 응답 계약 분리

- `AllergenResponse`를 알레르기 `response` 패키지의 독립 파일로 이동
- `SchoolResponse`, `SchoolSearchResponse`를 학교 `response` 패키지의 독립 파일로 이동
- `ApiError`, `ApiErrorResponse`를 오류 `response` 패키지의 독립 파일로 이동
- Controller와 예외 처리 계층이 분리된 응답 계약을 참조하도록 변경
- 기존 API JSON field와 응답 구조 유지

### Application 및 Port 계약 분리

- `RawPayload` 입력 계약을 outbound port `command` 패키지로 이동
- `SchoolSearchResult`, `RawMealResponse`, `MealSaveResult` 반환 계약을 outbound port
  `result` 패키지로 이동
- `CompletionResult`를 `MealCollectionCompletionResult`로 구체화하여 독립 파일로 분리
- 급식 수집 유스케이스 결과를 `MealCollectionResult` 독립 파일로 분리
- service와 infra adapter가 분리된 계약 타입을 참조하도록 변경

### 중첩 타입 관리 규칙 정리

- 외부에서 참조하는 API, application, port 계약은 독립 파일로 관리
- API 응답은 기능별 `response` 패키지에서 관리
- port 입력과 반환 계약은 각각 `command`, `result` 패키지에서 관리
- `NeisMealJsonNormalizer.Rows`처럼 외부 참조가 필요 없는 private 구현 helper만
  중첩 타입으로 유지

## 영향 범위

- 계약 타입을 기능과 역할에 따라 찾고 재사용하기 쉬워집니다.
- Controller, service, port가 커져도 외부 계약이 구현 클래스 내부에 누적되지 않습니다.
- 후속 공개 급식 조회 API에서 기존 계약 구조를 일관되게 확장할 수 있습니다.
- 기존 알레르기 조회와 학교 검색 API의 endpoint 및 JSON 응답 계약은 유지됩니다.
- 기존 NEIS 급식 수집, PostgreSQL 저장, MinIO 원본 저장 흐름에는 영향 없습니다.
