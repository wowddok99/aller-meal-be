# 계약 타입 독립 파일 구조 리팩터링 결과

## 작업 범위

- API 응답 계약을 기능별 `response` 패키지의 독립 파일로 분리
- application 유스케이스 결과를 기능 패키지의 독립 파일로 분리
- outbound port 입력·반환 계약을 `command`, `result` 패키지로 분리
- private 구현 helper만 중첩 타입으로 허용하는 규칙 문서화

## 주요 변경

- `AllergenResponse`, `SchoolResponse`, `SchoolSearchResponse`, `ApiError`,
  `ApiErrorResponse`를 API response 패키지로 이동했다.
- `RawPayload`를 port command 패키지로 이동했다.
- `SchoolSearchResult`, `RawMealResponse`, `MealSaveResult`를 port result 패키지로
  이동했다.
- `CompletionResult`를 `MealCollectionCompletionResult`로 구체화하고 독립
  파일로 분리했다.
- `MealCollectionResult`를 application meal 패키지의 독립 파일로 분리했다.
- `NeisMealJsonNormalizer.Rows`는 private 구현 helper로 유지했다.

## 리뷰 결과

- `impl-runner`, `pr-reviewer` 역할 호출은 child model/service tier 해석 오류로
  실행되지 않아 동일 스펙과 리뷰 기준으로 메인 스레드에서 구현·검토했다.
- 직접 리뷰에서 남은 `MealRepository` unused import 1건을 수정했다.
- 수정 후 미해결 blocker와 major 발견사항은 없다.

## 검증

- Java 21 `.\gradlew.bat clean build --no-daemon`: 성공
- `docker compose --env-file .env.example config --quiet`: 성공
- private이 아닌 중첩 계약 타입: 0건
- 이전 중첩 타입 이름 참조: 0건
- private 중첩 타입: 의도한 `NeisMealJsonNormalizer.Rows` 1건
- API 응답 record component reflection: 기존 JSON field 계약 유지
- `git diff --check`: 성공
- `docker compose --env-file .env.example ps`: PostgreSQL, Redis, RabbitMQ, MinIO,
  Mailpit 모두 `healthy`
- Java 21 `:safe-meal-api:bootRun`: 성공
- 실제 API 기동 시 Flyway 11개 migration 검증 및 PostgreSQL 연결: 성공
- `GET /api/v1/allergens`: HTTP 200, `code`, `name` field 계약 유지
- `GET /api/v1/public/schools`: HTTP 200, 검색 결과와 학교 응답 field 계약 유지
- 잘못된 학교 검색 요청: HTTP 400, `error.code`, `message`, `details`, `traceId`
  field 계약 유지

## 다음 행동

- Task 3.6은 사용자 지시에 따라 시작하지 않고 대기한다.
