# Task 3.4 Meal 및 CollectionJob 도메인 결과

## 작업 범위

- `Meal`, `MealItem`, `CollectionJob` 도메인과 식사·라벨링·수집 작업 상태 정의
- 급식 및 수집 작업 저장 포트와 JDBC 어댑터 구현
- Flyway V8 급식·메뉴·메뉴 알레르기·수집 작업 스키마 추가
- 동일 학교·날짜·식사 타입 급식의 멱등 upsert 및 활성 수집 작업 중복 방지

## 주요 변경

- 급식 자연키 충돌 시 기존 `meal_id`를 유지하며 메타데이터와 메뉴를 갱신한다.
- 메뉴 교체는 급식 upsert와 같은 트랜잭션에서 처리한다.
- 활성 `PENDING`·`RUNNING` 수집 작업은 부분 unique index로 한 건만 허용한다.
- 완료·실패 작업 이후 같은 대상의 새 수집 작업 생성을 허용한다.
- `CollectionJob` 시작·성공·실패 상태 전이와 실패 정보 불변식을 정의한다.

## Reviewer Findings 수정

- `CollectionJobRepository.save(expectedStatus, job)` 상태 CAS와 0행 동시성 예외를 적용했다.
- `Meal`에 `sourceVersion`, `sourceReceivedAt`을 추가하고 더 늦으며 다른 source만
  갱신하도록 CAS를 적용했다. stale·동일 source replay는 기존 급식과 메뉴를 유지하며
  `MealSaveResult.applied=false`로 호출자에게 명시한다.
- 메뉴 교체 전 `meal_item_allergens`를 명시 삭제한다.
- `Meal` aggregate 상태와 모든 `MealItem` labeling 상태 조합을 검증한다.
- 종료된 `CollectionJob`에만 `responseTimeMillis`가 필수인 Java·DB 불변식을 적용했다.
- 메뉴명, 원본 텍스트, source version, 영양·원산지 정보, 실패 정보 길이를 Java·DB에서
  함께 제한한다.
- 기존 적용된 V8을 변경하지 않고 Flyway V9 보강 migration을 추가했다.
- pr-finalizer에서 JDBC 어댑터의 반복 `Optional.get()`과 불필요한 완전 수식 타입을
  제거했다. 동작과 저장 계약은 변경하지 않았다.

## 검증

- Java 21 `.\gradlew.bat clean build --no-daemon`: 성공
- pr-finalizer Java 21 `.\gradlew.bat clean build --no-daemon`: 성공
- `docker compose --env-file .env.example config --quiet`: 성공
- `docker compose --env-file .env.example up -d` 및 `ps`: 5개 서비스 모두 `healthy`
- API 실제 기동 및 Flyway V8 적용: 성공
- API 실제 기동 및 Flyway V9 적용: 성공
- 실제 PostgreSQL assertion:
  - 반복 급식 upsert 후 자연키 데이터 1건 및 최초 `meal_id` 유지: 성공
  - 메뉴 교체 및 갱신 데이터 반영: 성공
  - 활성 동일 수집 작업 중복 방지: 성공
  - 완료 후 동일 대상 새 수집 작업 생성: 성공
  - CollectionJob 상태 CAS 성공 1행·stale CAS 0행: 성공
  - 활성·종료 상태별 `responseTimeMillis` DB CHECK: 성공
  - stale·동일 source replay 거부 및 기존 메뉴·allergen 관계 유지: 성공
  - 최신 source 갱신 및 메뉴 교체 시 allergen 관계 삭제: 성공
  - 외부 문자열 길이 DB CHECK: 성공
- Java 21 `jshell` 도메인 assertion:
  - Meal aggregate와 MealItem labeling 불일치 거부: 성공
  - CollectionJob 상태별 응답시간 불일치 거부: 성공
  - 외부 문자열 길이 초과 거부: 성공
- `git diff --check`: 성공

## 남은 블로커 및 다음 행동

- 테스트 코드는 사용자 요청에 따라 작성·수정하지 않았다.
- 다음 행동: Task 3.5 NEIS 급식 수집 및 정규화 구현.
