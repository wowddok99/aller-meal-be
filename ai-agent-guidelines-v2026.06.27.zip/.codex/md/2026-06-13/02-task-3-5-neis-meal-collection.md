# Task 3.5 NEIS 급식 수집 및 정규화 결과

## 작업 범위

- 실제 NEIS `mealServiceDietInfo` 원본 fetch 포트와 HTTP 어댑터
- MinIO 원본 저장 후 strict JSON 검증 및 급식·메뉴 정규화
- Meal CAS 저장 및 CollectionJob 성공·실패·응답시간 기록
- timeout, 제한 retry, 지수 backoff, CircuitBreaker 적용
- Task 3.6 공개 조회 API는 구현하지 않음

## 주요 변경

- `MealCollectionService`가 `PENDING -> RUNNING -> SUCCEEDED/FAILED` CAS 전이를 관리한다.
- 원본 bytes를 MinIO와 `raw_meal_objects`에 먼저 저장한 뒤 normalizer를 호출한다.
- 요청 학교·날짜·식사 타입과 NEIS 응답 행이 일치할 때만 정규화한다.
- 메뉴명에서는 끝의 NEIS 알레르기 번호만 제거하고 `rawText`에는 원문을 보존한다.
- 무자료 `INFO-200`은 원본을 보존하고 Meal 0건의 성공 수집으로 기록한다.
- Resilience4j core `2.3.0` Retry·CircuitBreaker를 사용한다.
  - timeout `5s`, 최대 3회, 초기 `200ms`, 배수 `2.0`
  - 10-call sliding window, 최소 5회, 실패율 50%, open 30초
- 실제 검증 중 발견한 `JdbcCollectionJobRepository`의 `RETURNING` SQL 공백 오류를 수정했다.

## Reviewer findings 수정

- Meal 저장·삭제와 CollectionJob `SUCCEEDED` 전이를 하나의 원자 트랜잭션으로 묶었다.
- `meal_collection_versions` tombstone CAS로 최신 무자료 삭제와 stale 재수집 거부를 보장했다.
- RUNNING lease와 만료 회수 CAS를 추가했다.
- `responseTimeMillis`는 NEIS 호출만, `collectionDurationMillis`는 전체 수집을 기록한다.
- HTTP 200 API 오류·JSON·대상·count 검증 실패도 CircuitBreaker 실패로 기록한다.
- `list_total_count`, 빈 성공, row count 불일치를 strict 검증한다.
- streaming 최대 payload 제한과 opt-in batch `run-once` 진입점을 추가했다.
- 실패 job raw object 연결, 실패 문자열 정규화, 408·429 `Retry-After`+jitter,
  MinIO bucket 생성 경쟁 처리를 보강했다.
- 동일 hash 최신 응답도 `source_received_at` watermark를 전진시키되 콘텐츠는
  재적용하지 않아 중간 stale Meal이 최신 tombstone을 덮지 못하게 했다.
- HTTP fetch 성공을 즉시 CircuitBreaker 성공으로 기록하지 않고 validation 완료까지
  지연했다. fetch+validation은 정확히 한 결과로 기록되며 모든 validation 예외를 실패로 집계한다.
- fetch 성공 후 raw 저장이 실패하면 외부 호출 성공으로 permission을 명시 반환한다.
  내부 저장 실패는 외부 NEIS CircuitBreaker 실패 통계에 포함하지 않는다.
- normalizer는 `head[0]`이 존재하는 객체인지 먼저 strict 검증한다.

## 검증

- Java 21 `.\gradlew.bat clean build --no-daemon`: 성공
- `docker compose --env-file .env.example config --quiet`: 성공
- Compose 5개 서비스 `healthy`: 성공
- 실제 NEIS 정상 흐름:
  - 서울미동초등학교 2026-06-12 중식
  - CollectionJob `SUCCEEDED`, 응답시간 `577ms`
  - PostgreSQL Meal 1건, MealItem 7건, raw metadata 1건
  - MinIO 원본 객체 1653 bytes 및 SHA-256 확인
- 실제 NEIS 무자료 흐름:
  - 2099-01-01 중식
  - 원본 저장 후 Meal 0건, CollectionJob `SUCCEEDED`, 응답시간 `362ms`
- 장애 흐름:
  - 연결 거부 endpoint에 2회 retry와 `300ms` backoff 적용
  - 첫 작업 `FAILED,347ms,NEIS_IO_ERROR`
  - 다음 작업 `FAILED,1ms,NEIS_CIRCUIT_OPEN`
  - 장애 중 raw metadata 생성 없음
- 실제 PostgreSQL 보강 흐름:
  - CollectionJob 성공 CAS 실패 시 Meal·source version 원자 rollback
  - 최신 무자료 tombstone 이후 stale Meal 재수집 거부
  - 만료 RUNNING job `FAILED/LEASE_EXPIRED` 회수 후 새 `PENDING` 생성
- 로컬 HTTP mock: 429 `Retry-After`+jitter, payload 초과 중단, HTTP 200 validation
  실패 CircuitBreaker 기록, strict 빈 성공·count 불일치 거부 성공
- 실제 batch run-once 진입점 정상 수집·MinIO·PostgreSQL 정규화 성공
- 실제 HTTP 200 비정상 JSON:
  - CollectionJob `FAILED/NEIS_INVALID_RESPONSE`
  - NEIS 응답 `45ms`, 전체 수집 `183ms`
  - 실패 job `raw_object_id`와 MinIO 원본 2 bytes 연결 성공
- 실제 PostgreSQL watermark 순서:
  - `A(t1 tombstone) -> A(t3 동일 hash) -> B(t2 stale meal)`
  - 최종 `hash-A / t3 / has_meal=false` 유지, stale Meal 적용 0건
- 같은 JVM CircuitBreaker:
  - 실제 invalid HTTP 200 validation 실패 5회 후 다음 호출 `NEIS_CIRCUIT_OPEN`
  - `IllegalArgumentException` validation 실패 5회 후 다음 호출 `NEIS_CIRCUIT_OPEN`
- raw 저장 실패 application 흐름:
  - `recordExternalCallSuccess` 1회, validation 성공·실패 callback 0회
  - 내부 실패는 `COLLECTION_FAILED`, 외부 호출 breaker 결과는 성공으로 분리
- 실제 CircuitBreaker OPEN→HALF_OPEN 후 내부 실패 반환 계약 12회 반복:
  - permission 누수·HALF_OPEN 고착 없이 다음 외부 호출 허용
- `head[0]=null` 및 문자열 응답: 각각 `NEIS_INVALID_RESPONSE`
- Flyway V9~V11 적용·검증: 성공
- 정상·무자료·장애 검증 DB 데이터와 MinIO 객체 정리: 성공
- `git diff --check`: 성공

## 공식 참고

- Resilience4j decorator와 조합: https://resilience4j.readme.io/docs/getting-started
- Retry 설정: https://resilience4j.readme.io/docs/retry
- CircuitBreaker 설정: https://resilience4j.readme.io/docs/circuitbreaker
- Resilience4j `2.3.0` release: https://github.com/resilience4j/resilience4j/releases/tag/v2.3.0

## 남은 블로커 및 다음 행동

- 테스트 코드는 사용자 요청에 따라 작성·수정하지 않았다.
- Task 3.5 후속 리뷰가 다음 행동이다.
- 사용자 지시에 따라 Task 3.6은 시작하지 않았다.
