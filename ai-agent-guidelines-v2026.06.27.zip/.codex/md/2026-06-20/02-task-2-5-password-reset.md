# Task 2.5 비밀번호 재설정 완료 보고

## 작업 범위

- 비밀번호 재설정 요청·확인 API를 구현했습니다.
- Redis hash·만료·일회성 token과 Mailpit SMTP 재설정 메일을 추가했습니다.
- 비밀번호 변경 후 현재 사용자 Refresh Token session을 전체 폐기하도록 구현했습니다.

## 주요 변경

- `POST /api/v1/auth/password-resets`는 계정 존재 여부를 공개하지 않고 `202 Accepted`를 반환합니다.
- `POST /api/v1/auth/password-resets/confirm`은 Lua 기반 원자 token consume 뒤 PBKDF2 hash로 비밀번호를 변경합니다.
- Refresh Token 저장소는 사용자별 활성 token 인덱스와 폐기 시각을 사용해 신규·기존 token 모두의 재설정 후 갱신을 막습니다.

## 검증

- Java 21 `./gradlew.bat :safe-meal-api:build --no-daemon`: 성공
- Java 21 `./gradlew.bat build --no-daemon`: 성공
- `git diff --check`: 성공
- 최초 리뷰에서 기존 Refresh Token이 사용자 인덱스에 없을 수 있는 문제를 확인하고 사용자별 폐기 시각으로 수정했습니다.
- 후속 압축 리뷰에서 새 blocker·major는 없습니다.
- Compose 5개 서비스 health, 실제 API 기동 및 Flyway V1~V11 적용: 성공
- Mailpit 재설정 메일 token으로 비밀번호 변경 `204`, 기존 비밀번호 로그인 `401`, 새 비밀번호 로그인 `200`: 성공
- 기존 Refresh Token 1개와 동시 2개 모두 비밀번호 재설정 뒤 `/refresh` `401`: 성공
- 재설정 token 재사용 `400 INVALID_PASSWORD_RESET_TOKEN`, 미존재 이메일 재설정 요청 `202`: 성공

## 다음 행동

- Task 2.6 로그인 제한, Origin·CSRF 및 인증 rate limit을 진행합니다.
