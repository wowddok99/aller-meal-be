# PR 제목

feat: 비밀번호 재설정 및 Refresh Token 폐기 구현

# PR 본문

## 개요

이메일 기반 비밀번호 재설정 요청과 확인 API를 추가했습니다. 재설정 token은 원문을 저장하거나 응답으로 반환하지 않고, Redis에 해시와 만료시간을 함께 저장합니다.

확인 요청은 Redis Lua script로 token을 한 번만 소비한 뒤 비밀번호를 다시 해시해 저장합니다. 비밀번호가 변경되면 해당 사용자의 Refresh Token session을 즉시 제거합니다.

기존 배포에서 생성된 Refresh Token도 비밀번호 재설정 이후 갱신되지 않도록 사용자별 폐기 시각을 적용했습니다.

## 주요 변경

### 비밀번호 재설정 API

- `POST /api/v1/auth/password-resets`가 존재 여부를 노출하지 않는 `202 Accepted` 응답으로 재설정 메일 발송을 요청합니다.
- `POST /api/v1/auth/password-resets/confirm`가 유효한 단회 token과 새 비밀번호로 비밀번호를 변경하고 `204 No Content`를 반환합니다.
- 만료되었거나 이미 사용한 token은 `INVALID_PASSWORD_RESET_TOKEN` 오류로 처리합니다.

### token 및 이메일 전송

- password reset 전용 Redis key namespace에 사용자별 최신 token hash와 token별 사용자 ID를 저장합니다.
- 일회성 token consume은 Lua script로 원자 처리해 동시에 들어온 확인 요청이 하나만 성공합니다.
- SMTP 메일에 재설정 링크와 token을 포함하고, token·비밀번호·암호화 이메일을 API 응답과 로그에 노출하지 않습니다.

### Refresh Token 폐기

- 사용자별 활성 token hash 인덱스를 유지해 비밀번호 변경 시 모든 활성 Refresh Token을 제거합니다.
- 인덱스 생성 전 발급된 기존 token도 사용자별 폐기 시각과 발급 시각을 비교해 재설정 후 갱신을 차단합니다.

## 영향 범위

- 인증된 활성 사용자는 이메일로 비밀번호를 재설정할 수 있습니다.
- 비밀번호 재설정 뒤 기존 Refresh Token으로 access token을 다시 발급할 수 없습니다.
- 현재 access token은 기존 만료시간까지 유효할 수 있으며, Refresh Token 폐기 범위가 본 변경의 보장 대상입니다.

## 검증

- Java 21 `./gradlew.bat :safe-meal-api:build --no-daemon`: 성공
- Java 21 `./gradlew.bat build --no-daemon`: 성공
- `git diff --check`: 성공
- Compose 5개 서비스 health 및 API Flyway V1~V11 적용: 성공
- 실제 Mailpit 재설정 메일 token으로 비밀번호 변경, 기존 password 거부, 새 password 로그인: 성공
- 기존 Refresh Token 1개와 동시 2개 session의 재설정 후 `/refresh` `401`: 성공
- token 재사용 `400 INVALID_PASSWORD_RESET_TOKEN`, 미존재 이메일 `202`: 성공

# 커밋 메시지

```text
feat: 비밀번호 재설정 및 Refresh Token 폐기 구현

- 일회성 Redis 비밀번호 재설정 token과 SMTP 메일 발송 추가
- 비밀번호 변경 후 사용자 Refresh Token session 전체 폐기
- 기존 Refresh Token의 재설정 후 갱신 차단
```
