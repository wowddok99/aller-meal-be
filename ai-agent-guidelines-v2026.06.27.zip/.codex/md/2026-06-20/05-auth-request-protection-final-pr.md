# PR 제목

feat: 인증 요청 보호 구현

# PR 본문

## 개요

로그인 실패를 제한하고 인증 API 요청 빈도를 제어해 반복 인증 시도의 영향을 줄입니다.

cookie 인증 상태가 있는 변경 요청은 허용 Origin과 CSRF token을 함께 검증합니다.

## 주요 변경

### 로그인 제한

- 이메일 검색 hash별 로그인 실패를 Redis에 기록하고 5회 실패 시 15분 동안 로그인을 잠급니다.
- 정상 로그인은 잠금 상태를 원자적으로 확인한 뒤 실패 횟수를 초기화합니다.
- 빈 비밀번호도 실패 횟수에 포함합니다.

### 인증 요청 보호

- 인증 API 요청을 IP와 경로별로 분당 20회 제한합니다.
- 로그인 시 JavaScript가 읽을 수 있는 CSRF token cookie를 발급합니다.
- access token 또는 Refresh Token cookie가 포함된 변경 요청은 허용 Origin과 `X-CSRF-Token`의 cookie 일치를 요구합니다.

## 영향 범위

- 반복 로그인 실패는 `429 LOGIN_TEMPORARILY_LOCKED`를 반환합니다.
- 인증 API rate limit 초과는 `429 AUTH_RATE_LIMITED`를 반환합니다.
- CSRF 검증 실패는 `403 CSRF_VALIDATION_FAILED`를 반환합니다.
- Bearer token만 사용하는 요청은 CSRF cookie 검증 대상이 아닙니다.

## 검증

- Java 21 `./gradlew.bat build --no-daemon`: 성공
- 로그인 실패 6회: `401,401,401,401,401,429`
- cookie 인증 변경 요청 CSRF 누락: `403 CSRF_VALIDATION_FAILED`
- 인증 API 21회 요청: 마지막 요청 `429 AUTH_RATE_LIMITED`
- 전체 diff reviewer finding 수정 후 cavecrew-reviewer: `No issues.`

# 커밋 메시지

```text
feat: 인증 요청 보호 구현

- 로그인 실패 잠금과 인증 API rate limit 추가
- cookie 인증 변경 요청의 Origin·CSRF 검증 추가
```
