# Task 2.3 이메일 인증 완료 및 로그인 완료 보고

## 작업 범위

- 일회성 이메일 인증 token 확인 API 추가
- 로그인 API 추가
- Access Token 발급·검증 및 Refresh Token Redis 저장 추가
- `access_token`, `refresh_token` HttpOnly cookie 발급 추가
- 주요 `/api/v1/**` 요청 인증 필터 추가

## 주요 변경

- `GET /api/v1/auth/email-verifications/confirm?token=...`에서 Redis token을 consume하고 사용자 이메일 인증 상태를 `VERIFIED`로 변경한다.
- Redis 이메일 인증 token consume은 Lua script로 token 확인과 삭제를 원자 처리한다.
- `POST /api/v1/auth/login`은 이메일·비밀번호·사용자 상태·이메일 인증 상태를 확인하고 인증 cookie 2개를 발급한다.
- Access Token은 HMAC SHA-256 방식으로 서명하고, 필터에서 서명·만료·현재 사용자 상태를 재검증한다.
- `/api/v1/public/**`, `/api/v1/allergens`, 인증 API를 제외한 `/api/v1/**` 요청은 인증된 `ACTIVE`·`VERIFIED` 사용자만 통과한다.

## 검증

- `JAVA_HOME=$(/usr/libexec/java_home -v 21) PATH="$JAVA_HOME/bin:$PATH" sh ./gradlew :safe-meal-api:build --no-daemon`: 성공
- 실제 API 기동 및 Flyway 11개 migration 검증: 성공
- `POST /api/v1/auth/signup`: `201`, `UNVERIFIED` 사용자 생성 성공
- 미인증 사용자 `POST /api/v1/auth/login`: `403 EMAIL_NOT_VERIFIED` 성공
- Mailpit 인증 메일 token 추출 후 `GET /api/v1/auth/email-verifications/confirm`: `200 VERIFIED` 성공
- 동일 인증 token 재사용: `400 INVALID_EMAIL_VERIFICATION_TOKEN` 성공
- 인증 사용자 `POST /api/v1/auth/login`: `200`, `access_token` 및 `refresh_token` HttpOnly cookie 발급 성공
- 미로그인 보호 경로 `/api/v1/me`: `401 UNAUTHORIZED` 성공
- 로그인 cookie 포함 보호 경로 `/api/v1/me`: 인증 필터 통과 후 라우팅 `404 RESOURCE_NOT_FOUND` 성공
- `JAVA_HOME=$(/usr/libexec/java_home -v 21) PATH="$JAVA_HOME/bin:$PATH" sh ./gradlew build --no-daemon`: 성공

## 리뷰 결과

- `pr-reviewer`: 최초 리뷰에서 이메일 인증 token consume 순서 관련 major 발견
- `impl-runner`: Redis Lua 원자 consume 및 confirmer 권위값 수정
- `cavecrew-reviewer`: 동시 confirm 원자성 major 발견
- `impl-runner`: `consume`을 단일 Redis Lua script로 수정
- `pr-reviewer`: 수정 후 blocker/major 없음

## 남은 작업

- Task 2.4에서 Refresh Token rotation, 로그아웃, 재사용 탐지 구현 필요
- CSRF, Origin, rate limit은 Task 2.6 범위로 남김

## PR 초안

제목: `feat: 이메일 인증 완료 및 로그인 구현`

본문:

```markdown
## 개요

- 이메일 인증 token 완료 API와 로그인 API를 추가했습니다.
- Access Token과 Refresh Token을 HttpOnly cookie로 발급합니다.
- 주요 `/api/v1/**` 요청에 인증 필터를 적용했습니다.

## 주요 변경

- Redis 이메일 인증 token consume을 Lua script로 원자 처리
- HMAC SHA-256 기반 Access Token 발급·검증 추가
- Refresh Token Redis 저장 추가
- 미인증 계정 로그인 및 미로그인 보호 경로 접근 차단

## 검증

- `sh ./gradlew :safe-meal-api:build --no-daemon`
- `sh ./gradlew build --no-daemon`
- 실제 API 기동, Mailpit token confirm, login cookie 발급, 보호 경로 인증 필터 확인

## 영향 및 리스크

- Task 2.4 전까지 Refresh Token rotation과 로그아웃은 아직 구현되지 않았습니다.
- CSRF, Origin, 인증 rate limit은 Task 2.6에서 처리합니다.
```
