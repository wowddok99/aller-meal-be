# PR 제목

feat: 이메일 인증 완료 및 로그인 구현

# PR 본문

## 개요

회원이 이메일 인증 링크로 계정을 인증하고, 인증된 계정으로 로그인할 수 있는 Identity 인증 흐름을 추가했습니다. 이번 변경은 가입 이후 이메일 인증 완료와 로그인까지를 다루며, Refresh Token 재발급, 로그아웃, 재사용 탐지는 아직 제공하지 않습니다.

이메일 인증 token은 Redis에서 일회성으로 소비됩니다. token 원문은 API 응답이나 저장소에 남기지 않고 SHA-256 hash로 비교하며, Redis Lua script로 token 확인과 삭제를 한 번에 수행해 동시에 같은 링크가 요청되어도 한 요청만 성공하도록 했습니다.

로그인 성공 시 서버는 Access Token과 Refresh Token을 HttpOnly cookie로 발급합니다. Access Token은 HMAC SHA-256 서명과 만료 시각을 포함하고, API 인증 필터는 token 서명과 만료뿐 아니라 현재 사용자 상태와 이메일 인증 상태를 다시 확인합니다.

API, application, infra 계층의 책임을 분리했습니다. API는 요청·응답, cookie 발급, 인증 필터와 오류 code 매핑을 담당하고, application은 인증 완료와 로그인 유스케이스를 담당하며, infra는 Access Token 서명, PBKDF2 비밀번호 검증, Redis token 저장을 담당합니다.

## 주요 변경

### 이메일 인증 완료 API

- `GET /api/v1/auth/email-verifications/confirm?token=...`을 추가해 유효한 인증 token으로 사용자 이메일 인증 상태를 `VERIFIED`로 변경합니다.
- Redis에 저장된 인증 token hash를 일회성으로 소비하고, 이미 사용했거나 만료된 token은 `INVALID_EMAIL_VERIFICATION_TOKEN`으로 응답합니다.
- Redis Lua script로 token hash 확인, 사용자 key 확인, token key 삭제, 사용자 key 삭제를 단일 원자 명령으로 수행합니다.

### 로그인 API와 인증 cookie

- `POST /api/v1/auth/login`을 추가해 이메일과 비밀번호로 인증된 사용자가 로그인할 수 있게 했습니다.
- 이메일 또는 비밀번호가 올바르지 않거나 비활성 사용자이면 `INVALID_LOGIN_CREDENTIALS`로 응답하고, 아직 이메일 인증이 끝나지 않은 사용자는 `EMAIL_NOT_VERIFIED`로 응답합니다.
- 로그인 성공 시 `access_token`과 `refresh_token`을 HttpOnly cookie로 발급하고, 응답 본문에는 token 원문 없이 사용자 ID, 이메일 인증 상태, 만료 시각만 반환합니다.

### Access Token과 Refresh Token 저장

- Access Token은 HMAC SHA-256으로 서명하고 사용자 ID, 역할, 사용자 상태, 이메일 인증 상태, 만료 시각을 포함합니다.
- 인증 필터는 Access Token 서명과 만료 시각을 검증한 뒤, DB에서 현재 사용자를 다시 조회해 `ACTIVE` 및 `VERIFIED` 상태인지 확인합니다.
- Refresh Token 원문은 cookie로만 전달하고, Redis에는 SHA-256 hash와 만료 시각을 저장합니다.
- `.env.example`과 API 설정에 Access Token 서명 key, Access Token TTL, Refresh Token TTL 설정을 추가했습니다.

### 주요 API 인증 필터

- `/api/v1/public/**`, `/api/v1/allergens`, `/api/v1/auth/**`의 공개·인증 진입점을 제외한 `/api/v1/**` 요청에 인증 필터를 적용했습니다.
- 미로그인 요청은 `UNAUTHORIZED`, 이메일 미인증 사용자는 `EMAIL_NOT_VERIFIED`로 응답합니다.
- 인증 오류 응답도 기존 `ApiErrorResponse` 형식과 `X-Trace-Id` 흐름을 유지합니다.

## 영향 범위

- 가입을 마친 사용자는 이메일 인증 링크를 통해 계정을 인증하고 로그인할 수 있습니다.
- 인증 token은 Redis에서 원자적으로 소비되어 같은 인증 링크의 중복 사용을 방지합니다.
- 로그인 이후 주요 API는 인증된 `ACTIVE` 및 `VERIFIED` 사용자만 접근할 수 있습니다.
- 기존 공개 학교·급식 조회 API와 알레르기 조회 API는 계속 비회원 접근이 가능합니다.
- Refresh Token 재발급, 로그아웃, 재사용 탐지는 아직 제공하지 않습니다.
- CSRF, Origin 검증, 인증 rate limit은 아직 적용하지 않았습니다.

## 검증

- `JAVA_HOME=$(/usr/libexec/java_home -v 21) PATH="$JAVA_HOME/bin:$PATH" sh ./gradlew :safe-meal-api:build --no-daemon`: 성공
- `JAVA_HOME=$(/usr/libexec/java_home -v 21) PATHg="$JAVA_HOME/bin:$PATH" sh ./gradlew build --no-daemon`: 성공
- 실제 API 기동 및 Flyway 11개 migration 검증: 성공
- `POST /api/v1/auth/signup`: `201`, `UNVERIFIED` 사용자 생성 성공
- 미인증 사용자 `POST /api/v1/auth/login`: `403 EMAIL_NOT_VERIFIED` 성공
- Mailpit 인증 메일 token 추출 후 `GET /api/v1/auth/email-verifications/confirm`: `200 VERIFIED` 성공
- 동일 인증 token 재사용: `400 INVALID_EMAIL_VERIFICATION_TOKEN` 성공
- 인증 사용자 `POST /api/v1/auth/login`: `200`, `access_token` 및 `refresh_token` HttpOnly cookie 발급 성공
- 미로그인 보호 경로 `/api/v1/me`: `401 UNAUTHORIZED` 성공
- 로그인 cookie 포함 보호 경로 `/api/v1/me`: 인증 필터 통과 후 라우팅 `404 RESOURCE_NOT_FOUND` 성공

# 커밋 메시지

```text
feat: 이메일 인증 완료 및 로그인 구현

- 일회성 이메일 인증 token confirm API 추가
- 로그인 시 Access Token과 Refresh Token을 HttpOnly cookie로 발급
- Redis Lua script로 이메일 인증 token consume 원자화
- 주요 API 요청 인증 필터 추가
```
