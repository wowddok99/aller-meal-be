# PR 제목

feat: 공개 학교 및 급식 조회 API 구현

# PR 본문

## 개요

비회원이 저장된 학교 정보와 학교별 일간·주간 급식을 조회할 수 있는 공개 API를
추가했습니다.

일간 조회는 지정 날짜의 조식, 중식, 석식을 확인하며, 주간 조회는 지정 날짜가
속한 월요일부터 일요일까지의 급식을 조회합니다. 수집 완료된 급식과 NEIS에서
급식 없음이 확인된 결과는 PostgreSQL의 `meal_collection_versions`를 기준으로
판별하여, 급식이 없는 날짜도 완료된 조회 결과로 처리합니다.

아직 수집 결과가 없는 대상은 활성 `CollectionJob`을 멱등하게 생성하거나 기존
작업을 재사용하고 비동기 수집을 요청합니다. 처리 중에는 `202 Accepted`와
`Retry-After`를 반환하며, 수집 완료 후 같은 URL을 재조회하면 저장된 급식을
`200 OK`로 반환합니다.

application 모듈은 급식 기간 조회와 비동기 수집 실행을 port로 정의하고, infra
모듈에서 PostgreSQL 조회와 실제 비동기 실행을 담당합니다. 공개 응답은 별도
response 계약으로 구성하며 개인화 위험도는 포함하지 않습니다.

## 주요 변경

### 공개 학교 및 급식 조회 API 추가

- `GET /api/v1/public/schools/{schoolId}` 학교 단건 조회를 추가했습니다.
- `GET /api/v1/public/schools/{schoolId}/meals/{date}` 일간 급식 조회를
  추가했습니다.
- `GET /api/v1/public/schools/{schoolId}/meals/weekly?date={date}` 주간 급식
  조회를 추가했습니다.
- 존재하지 않는 학교는 `404 RESOURCE_NOT_FOUND`로 반환합니다.
- 공개 급식 응답에 조회 범위, 수집 상태, 재조회 시간, 완료 급식과 아직 수집이
  끝나지 않은 날짜·식사 타입을 제공합니다.

### PostgreSQL 기반 완료 결과 조회 추가

- 학교와 날짜 범위로 `meal_collection_versions`와 `meals`를 조회하는 기간 조회
  계약을 추가했습니다.
- `has_meal=false`로 기록된 급식 없음 결과도 완료 상태로 처리하여 같은
  날짜·식사 타입의 반복 수집을 방지합니다.
- 저장된 급식은 날짜와 식사 타입 순으로 반환하며 메뉴, 라벨링 상태, 영양 정보,
  원산지 정보와 원본 수신 시각을 제공합니다.

### 미확인 급식 비동기 수집 추가

- 저장 여부가 확인되지 않은 날짜와 식사 타입별로 `CollectionJob`을 멱등하게
  생성하거나 활성 작업을 재사용합니다.
- `PENDING` 작업은 전용 `TaskExecutor`로 비동기 실행하여 API 요청 thread에서
  NEIS 수집 완료를 기다리지 않습니다.
- `CollectionJob` 상태 CAS가 동시 실행 중 하나만 `RUNNING`으로 전이하도록
  보장합니다.
- executor 요청 실패와 실제 수집 실패를 기록하고, 다른 실행자가 먼저 상태를
  변경한 동시 실행 요청은 정상 경쟁 상황으로 처리합니다.

### 공개 조회 상태 계약 추가

- 요청 범위의 모든 날짜·식사 타입이 완료되면 `READY`와 `200 OK`를 반환합니다.
- 하나 이상의 날짜·식사 타입이 미확인이면 `COLLECTING`, `202 Accepted`,
  `Retry-After: 3`을 반환합니다.
- API response, application result, outbound port command/result를 독립 파일로
  구성했습니다.

## 영향 범위

- 비회원이 학교 단건과 일간·주간 일반 급식을 조회할 수 있습니다.
- 급식이 아직 없으면 비동기 수집을 요청하고 같은 URL로 완료 결과를 재조회할 수
  있습니다.
- 동시 동일 요청은 PostgreSQL 활성 작업 제약과 상태 CAS를 통해 중복
  `CollectionJob` 및 외부 호출을 제한합니다.
- NEIS에서 급식 없음이 확인된 결과를 완료 상태로 조회하여 급식이 없는 날짜를
  반복 수집하지 않습니다.
- 공개 응답에는 자녀 정보, 개인 알레르기 교집합, 개인화 위험도가 포함되지
  않습니다.
- 기존 학교 검색, User, Outbox, RabbitMQ Consumer 처리 흐름에는 영향 없습니다.

## 검증

- Java 21 `clean build`: 성공
- Docker Compose 설정 검증과 PostgreSQL, Redis, RabbitMQ, MinIO, Mailpit
  health 확인: 성공
- 실제 API 기동과 Flyway V1~V11 적용: 성공
- 공개 학교 단건 조회 `200`, 미존재 학교 조회 `404 RESOURCE_NOT_FOUND`: 성공
- 일간 급식 최초 조회 `202 + Retry-After: 3`, 재조회 `200 READY`: 성공
- 주간 급식 월요일~일요일 범위 최초 조회 `202`, 재조회 `200 READY`: 성공
- 동일 학교·날짜 동시 5요청 후 식사 타입별 `CollectionJob` 1건 유지: 성공
