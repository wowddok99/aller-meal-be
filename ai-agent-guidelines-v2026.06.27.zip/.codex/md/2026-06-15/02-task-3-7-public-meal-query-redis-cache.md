# Task 3.7 공개 조회 Redis 캐시와 중복 호출 방지 완료 보고

## 작업 범위

- 공개 READY 급식 Redis cache-first 조회
- target별 Redis dispatch lock
- Redis 장애 시 PostgreSQL과 DB CAS fallback
- Redis connect/read timeout 설정

## 주요 변경

- application `PublicMealQueryCache` port 추가
- `public-meal-query:v1` READY JSON cache, TTL 10분 적용
- `public-meal-dispatch:v1` `SET NX` lock, TTL 10초 적용
- Redis 오류를 cache miss·lock 허용으로 변환해 핵심 조회·수집 흐름 유지
- Redis connect/read timeout을 500ms로 제한

## 리뷰

- 최초 `pr-reviewer`: blocker 없음, major 1건
  - Redis 중단 시 기본 command timeout으로 요청이 1분 이상 정체되는 문제 수정
- 후속 `cavecrew-reviewer`: 새 blocker/major 없음
- 잔여 minor: cache TTL 동안 최신 PostgreSQL 변경 반영 지연 가능, 공개 IP rate
  limit 미구현

## 검증

- Redis READY cache 생성과 TTL 600초: 성공
- PostgreSQL 중단 상태에서 Redis cache hit 공개 조회 `200`: 성공
- Redis 중단 상태 PostgreSQL READY fallback `200`, 0.22초: 성공
- Redis 중단 상태 미확인 target fallback `202`, 0.03초: 성공
- 동시 동일 요청 5건에서 dispatch lock 3개, meal type별 `CollectionJob` 1건: 성공
- Compose 5개 서비스 health: 성공
- Java 21 clean build: 성공

## PR

- 제목: `feat: 공개 급식 조회 Redis 캐시 적용`
- 요약:
  - Redis cache-first 공개 급식 조회 추가
  - Redis dispatch lock으로 동시 요청 중복 실행 제한
  - Redis 장애 시 PostgreSQL과 DB CAS fallback 유지

## 다음 행동

- Checkpoint 3 종합 실제 흐름을 검증한다.
