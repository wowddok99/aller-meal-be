# Task 3.6 공개 학교·급식 조회 API 완료 보고

## 작업 범위

- 공개 학교 단건 조회
- 공개 일간·주간 급식 조회
- 미확인 급식 target의 멱등 `CollectionJob` 생성과 비동기 수집
- 완료 tombstone 기반 급식 없음 재수집 방지

## 주요 변경

- `meal_collection_versions` 기반 기간 조회 계약과 PostgreSQL 구현 추가
- `PENDING` 작업을 비동기 실행하고 상태 CAS로 외부 호출 전 단일 실행 보장
- 일간·주간 조회의 `200 READY` 및 `202 COLLECTING + Retry-After` 계약 추가
- 공개 응답을 독립 response 타입으로 구성하고 개인화 위험도 제외

## 리뷰

- 최초 `pr-reviewer`: blocker 없음, major 2건
  - 기존 `PENDING` 작업 복구 dispatch 누락 수정
  - executor 거절 시 `500` 및 복구 불가 문제 수정
- 후속 `cavecrew-reviewer`: 새 blocker/major 없음
- 실제 동시 요청 로그 점검: 예상 CAS loser의 `ERROR` stack trace를 debug 처리
- 잔여 minor: bounded N+1 메뉴 조회, 공개 IP rate limit 미구현

## 검증

- Java 21 clean build: 성공
- Compose 설정 및 5개 서비스 health: 성공
- 실제 API 기동 및 Flyway V1~V11 적용: 성공
- 공개 학교 단건 `200`, 미존재 학교 `404`: 성공
- 일간 최초 `202 + Retry-After: 3`, 재조회 `200 READY`: 성공
- 주간 월~일 범위 최초 `202`, 재조회 `200 READY`: 성공
- 동일 target 동시 5요청 후 meal type별 `CollectionJob` 1건: 성공

## PR

- 제목: `feat: 공개 학교 및 급식 조회 API 구현`
- 요약:
  - 비회원 학교 단건·일간·주간 급식 조회 제공
  - 미확인 급식의 멱등 비동기 수집과 재조회 계약 제공
  - 급식 없음 tombstone과 처리 중 작업 재사용

## 다음 행동

- 완료된 Task 3.6 브랜치에서 Task 3.7 전용 브랜치를 생성한다.
- Redis 공개 조회 캐시, Redis 장애 fallback, 동시 동일 요청 중복 제한을 구현한다.
