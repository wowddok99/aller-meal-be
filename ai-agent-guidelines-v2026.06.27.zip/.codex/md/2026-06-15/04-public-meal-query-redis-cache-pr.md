# PR 제목

feat: 공개 급식 조회 Redis 캐시 적용

# PR 본문

## 개요

공개 일간·주간 급식 조회에 Redis 우선 조회 흐름을 추가하여, 수집이 완료된
급식을 PostgreSQL 조회 없이 빠르게 반환할 수 있도록 구성했습니다.

요청 범위의 모든 날짜·식사 타입이 완료된 `READY` 결과만 Redis에 JSON으로
저장하며, 처리 중인
`COLLECTING` 결과는 캐시하지 않습니다. 캐시 miss 또는 Redis 오류가 발생하면
PostgreSQL에서 완성 데이터를 조회하고, 조회 결과가 `READY`이면 Redis 저장을
시도한 뒤 반환합니다.

동시 동일 요청이 같은 `PENDING` 작업을 반복해서 executor에 전달하지 않도록
날짜·식사 타입별 Redis `SET NX` 잠금을 추가했습니다. Redis 장애로 잠금을 사용할
수 없으면 비동기 수집 요청을 계속 전달하며, PostgreSQL의 활성 작업 고유 제약과
현재 상태가 `PENDING`일 때만 `RUNNING`으로 변경하는 조건부 갱신이 중복 작업
생성과 중복 외부 호출을 막습니다.

application 모듈은 `PublicMealQueryCache` port에만 의존하며, infra 모듈의
`RedisPublicMealQueryCache`가 실제 캐시와 비동기 실행 요청 잠금을 구현합니다.

## 주요 변경

### 공개 급식 READY 캐시 추가

- `public-meal-query:v1:{schoolId}:{rangeStart}:{rangeEnd}` 형식의 버전된 cache
  key를 사용합니다.
- `READY` 공개 급식 결과를 JSON으로 저장하고 기본 TTL 10분을 적용합니다.
- 공개 급식 조회 시 Redis를 먼저 확인하고 cache hit이면 저장된 결과를 즉시
  반환합니다.
- cache miss이면 PostgreSQL 조회와 기존 비동기 수집 판단 흐름을 수행합니다.
- `COLLECTING` 결과는 캐시하지 않아 후속 재조회에서 완료 여부를 다시 확인합니다.

### 동시 요청 실행 잠금 추가

- `public-meal-dispatch:v1:{schoolId}:{mealDate}:{mealType}` 형식의
  날짜·식사 타입별 잠금 key를 사용합니다.
- Redis `SET NX`와 기본 TTL 10초를 적용하여 같은 `PENDING` 작업의 반복
  비동기 실행 요청을 제한합니다.
- 잠금 TTL 만료 후에도 남아 있는 `PENDING` 작업은 후속 조회에서 다시 실행
  요청할 수 있습니다.
- PostgreSQL의 활성 `CollectionJob` 고유 제약과 조건부 상태 변경을 최종 중복
  실행 방지 수단으로 유지합니다.

### Redis 장애 fallback 추가

- Redis cache 조회 실패를 cache miss로 변환하여 PostgreSQL 조회를 계속합니다.
- Redis cache 저장 실패는 조회 응답을 실패시키지 않고 경고 로그만 기록합니다.
- Redis 실행 잠금을 사용할 수 없으면 비동기 수집 요청을 계속 전달하고,
  PostgreSQL의 활성 작업 제약과 조건부 상태 변경으로 중복 실행을 방지합니다.
- Redis connect timeout과 read timeout을 500ms로 제한하여 장애 시 요청 정체를
  줄였습니다.
- Redis 캐시와 잠금 오류는 내부 비밀값 없이 간결한 로그로 기록합니다.

### 모듈 경계와 설정 추가

- application 모듈에 `PublicMealQueryCache` outbound port를 추가했습니다.
- infra 모듈에 Spring Data Redis 의존성과 `RedisPublicMealQueryCache` adapter를
  추가했습니다.
- Redis host와 port를 환경 변수로 설정할 수 있도록 API 설정을 추가했습니다.
- 캐시 TTL과 실행 잠금 TTL을 설정값으로 조정할 수 있도록 구성했습니다.

## 영향 범위

- 반복되는 공개 일간·주간 급식 조회는 Redis cache hit 시 PostgreSQL 부하 없이
  응답할 수 있습니다.
- 동시 동일 요청의 반복 비동기 실행 요청을 Redis 잠금으로 줄이고, PostgreSQL의
  활성 작업 고유 제약과 조건부 상태 변경으로 최종 중복 실행 방지를 유지합니다.
- Redis가 중단되어도 PostgreSQL의 저장 급식 조회와 비동기 수집 작업이 계속
  동작합니다.
- Redis cache hit이면 PostgreSQL 장애 중에도 캐시된 READY 공개 급식을 반환할
  수 있습니다.
- READY cache TTL 동안 PostgreSQL의 최신 변경 반영이 지연될 수 있습니다.
- 공개 학교 검색, 개인화 위험도, 기존 수집 정규화와 Outbox 흐름에는 영향
  없습니다.

## 검증

- Java 21 `clean build`: 성공
- Docker Compose 설정 검증과 5개 서비스 health 확인: 성공
- Redis READY cache 생성과 TTL 600초 확인: 성공
- PostgreSQL 중단 상태에서 Redis cache hit 공개 조회 `200`: 성공
- Redis 중단 상태에서 PostgreSQL READY fallback `200`, 응답 시간 0.22초: 성공
- Redis 중단 상태에서 미확인 날짜·식사 타입 조회 `202`, 응답 시간 0.03초: 성공
- 동시 동일 요청 5건에서 날짜·식사 타입별 Redis 실행 잠금 3개와 식사 타입별
  `CollectionJob` 1건 유지: 성공
