# PR 제목

feat: Refresh Token rotation과 로그아웃 구현

# PR 본문

## 개요

Refresh Token 갱신 요청에서 기존 token을 폐기하고 새 token으로 교체하는 rotation 흐름을 추가했습니다. Refresh Token은 Redis에 hash 기반 session chain으로 저장되며, 서버는 token 원문을 저장하지 않습니다.

폐기된 Refresh Token이 다시 사용되면 같은 session chain의 현재 active token까지 삭제합니다. 이로써 탈취되었거나 오래된 Refresh Token 재사용이 감지될 때 이후 갱신도 차단됩니다.

로그아웃은 현재 Refresh Token session을 Redis에서 제거하고 `access_token`, `refresh_token` 쿠키를 함께 삭제합니다. API 계층은 응답 타입을 독립 파일로 유지하고, application과 infra 경계는 기존 port 구조를 따릅니다.

## 주요 변경

### Refresh Token rotation

- `POST /api/v1/auth/refresh`를 추가해 Refresh Token 쿠키를 기준으로 새 Access Token과 Refresh Token을 발급합니다.
- Redis 저장 구조를 active token, 사용 완료 token, session chain pointer, revoked chain marker로 분리했습니다.
- Lua script로 기존 active token 폐기, 새 active token 저장, 기존 token 사용 완료 기록을 원자적으로 수행합니다.

### 재사용 탐지와 session chain 무효화

- 사용 완료로 기록된 Refresh Token이 다시 들어오면 같은 session chain의 현재 active token을 삭제합니다.
- 재사용 탐지 후 직전에 발급된 Refresh Token으로 다시 갱신해도 `401 UNAUTHORIZED`가 반환됩니다.
- Redis에는 token 원문 대신 hash와 session chain 식별자만 저장합니다.

### 로그아웃

- `POST /api/v1/auth/logout`을 추가해 현재 Refresh Token session을 Redis에서 제거합니다.
- 로그아웃 응답은 `204 No Content`이며 인증 쿠키 두 개를 `Max-Age=0`으로 삭제합니다.
- refresh와 logout endpoint는 Access Token 없이 Refresh Token 쿠키만으로 동작하도록 인증 필터 공개 경로에 포함했습니다.

## 영향 범위

- 인증 사용자는 Access Token 만료 전후에 Refresh Token 쿠키로 세션을 갱신할 수 있습니다.
- 폐기된 Refresh Token 재사용이 감지되면 같은 session chain의 추가 갱신이 차단됩니다.
- 로그아웃 후에는 Redis active session과 family pointer가 제거되어 해당 Refresh Token으로 갱신할 수 없습니다.
- 기존 로그인 응답 JSON field는 유지되며, Refresh 응답도 동일한 만료 시각 구조를 제공합니다.

## 검증

- `sh ./gradlew :safe-meal-api:build --no-daemon`: 성공
- 실제 API 기동 및 Flyway 11개 migration 검증: 성공
- 인증 사용자 `POST /api/v1/auth/refresh`: `200`, 새 Refresh Token 발급 및 기존 token `used` 전환 확인 성공
- 폐기된 Refresh Token 재사용: `401 UNAUTHORIZED`, session chain active 제거 및 `revoked-family` 기록 확인 성공
- 재사용 탐지 후 직전에 발급된 Refresh Token 사용: `401 UNAUTHORIZED` 확인 성공
- `POST /api/v1/auth/logout`: `204`, `access_token`·`refresh_token` 쿠키 `Max-Age=0` 삭제와 Redis active/family 제거 확인 성공
- 검증 후 Redis `refresh-token:v2:*` key 정리: 완료
- `sh ./gradlew build --no-daemon`: 성공

# 커밋 메시지

```text
feat: Refresh Token rotation과 로그아웃 구현

- Refresh Token 갱신 시 기존 token을 폐기하고 새 token을 발급
- 폐기된 Refresh Token 재사용 시 같은 session chain의 active token 삭제
- 로그아웃 시 Redis session과 인증 쿠키 제거
```
