# Task 2.4 Refresh rotation, 로그아웃, 재사용 탐지 완료 보고

## 작업 범위

- `POST /api/v1/auth/refresh` API를 추가해 Refresh Token rotation 시 기존 token을 폐기하고 새 Access Token·Refresh Token 쿠키를 재발급했다.
- `POST /api/v1/auth/logout` API를 추가해 Refresh Token session과 인증 쿠키를 제거했다.
- Redis Refresh Token 저장 구조를 `active`, `used`, `family`, `revoked-family` key로 확장했다.
- Redis Lua script로 refresh rotation과 재사용 탐지를 원자적으로 처리했다.

## 주요 변경

- 로그인 시 Refresh Token family id를 함께 저장해 한 session chain 안에서 token 상태를 추적한다.
- 정상 refresh 시 기존 active token을 used token으로 전환하고 새 active token을 저장한다.
- used token 재사용이 감지되면 같은 family의 현재 active token을 삭제하고 family를 revoked 상태로 기록한다.
- logout 시 현재 active token과 family pointer를 삭제하고 `access_token`, `refresh_token` 쿠키를 `Max-Age=0`으로 삭제한다.

## 검증 명령과 결과

- `sh ./gradlew :safe-meal-api:build --no-daemon`: 성공
- 실제 API 기동 및 Flyway 11개 migration 검증: 성공
- 인증 사용자 `POST /api/v1/auth/refresh`: `200`, 새 Refresh Token 발급 및 기존 token `used` 전환 확인 성공
- 폐기된 Refresh Token 재사용: `401 UNAUTHORIZED`, session chain active 제거 및 `revoked-family` 기록 확인 성공
- 재사용 탐지 후 직전에 발급된 Refresh Token 사용: `401 UNAUTHORIZED` 확인 성공
- `POST /api/v1/auth/logout`: `204`, `access_token`·`refresh_token` 쿠키 `Max-Age=0` 삭제와 Redis active/family 제거 확인 성공
- 검증 후 Redis `refresh-token:v2:*` key 정리: 완료
- `sh ./gradlew build --no-daemon`: 성공

## 리뷰 결과

- 최초 diff 리뷰: blocker/major 없음
- 후속 영향 범위 리뷰: blocker/major 없음

## 남은 블로커 또는 다음 행동

- 블로커 없음
- 다음 태스크는 비밀번호 재설정이며, 비밀번호 변경 후 Refresh session 폐기 연계 지점 확인 필요
