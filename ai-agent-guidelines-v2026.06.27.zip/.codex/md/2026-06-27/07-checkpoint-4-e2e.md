# Checkpoint 4 E2E 검증 보고서

## 작업 범위

- 회원 1명이 자녀 2명을 등록하고 각 자녀별 개인화 위험 급식을 조회할 수 있는지 확인했습니다.
- 정보 없음(`UNKNOWN`)과 라벨링 실패(`LABELING_FAILED`) 메뉴가 안전(`SAFE`)으로 표시되지 않는지 확인했습니다.
- 운영 코드 변경 없이 실제 API 기동, PostgreSQL fixture, 인증 Bearer token으로 흐름을 검증했습니다.

## 주요 검증

- 실제 API로 자녀 2명을 등록했습니다.
- 첫째 자녀는 알레르기 `[2]`, 둘째 자녀는 알레르기 `[5]`로 설정했습니다.
- 검증 급식은 라벨링 완료 메뉴 1개, 정보 없음 메뉴 1개, 라벨링 실패 메뉴 1개로 구성했습니다.
- 첫째 자녀는 라벨링 완료 메뉴의 allergen `[2]`와 매칭되어 전체 위험도 `RISKY`로 응답했습니다.
- 둘째 자녀는 라벨링 완료 메뉴와 매칭되지 않았지만 라벨링 실패 메뉴 때문에 전체 위험도 `LABELING_FAILED`로 응답했습니다.
- 두 자녀 모두 `UNKNOWN`과 `LABELING_FAILED` 메뉴가 `SAFE`가 아닌 상태로 응답했습니다.

## 검증 명령과 결과

- `$env:JAVA_HOME='C:\Program Files\Eclipse Adoptium\jdk-21.0.8.9-hotspot'; $env:Path="$env:JAVA_HOME\bin;$env:Path"; .\gradlew.bat build --no-daemon`: 성공
- `docker compose --env-file .env.example ps`: 5개 서비스 `healthy`
- API 실제 기동: Java 21, Flyway V1~V15 검증 성공
- `POST /api/v1/children` 2회: 자녀 2명 등록 성공
- PostgreSQL `child_profiles` 확인: 검증 회원 자녀 2건
- `GET /api/v1/children/{firstChildId}/meals/2026-06-27`: `200 READY`, 전체 위험도 `RISKY`, 메뉴 위험도 `RISKY`·`UNKNOWN`·`LABELING_FAILED`, matched allergen `[2]`
- `GET /api/v1/children/{secondChildId}/meals/2026-06-27`: `200 READY`, 전체 위험도 `LABELING_FAILED`, 메뉴 위험도 `SAFE`·`UNKNOWN`·`LABELING_FAILED`, matched allergen 없음
- `GET /api/v1/children/{firstChildId}/meals/weekly?date=2026-06-27`: `200 READY`, range `2026-06-22`~`2026-06-28`, meal 1건
- 검증 데이터와 API 프로세스 정리: 완료

## 남은 블로커 또는 다음 행동

- 블로커 없음
- 다음 행동: Task 5.1 등록 학교 수집 Scheduler의 대상 날짜 산출과 중복 실행 방지 기준을 확인합니다.
