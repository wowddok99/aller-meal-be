# PR 제목

feat: 등록 학교 급식 자동 수집 Scheduler 구현

# PR 본문

## 개요

활성 학교 수집 구독을 기준으로 오늘부터 설정된 기간까지의 급식 수집 작업을 자동 생성하고 dispatch하는 Batch Scheduler를 추가합니다.

Scheduler는 `Asia/Seoul` 날짜 기준으로 학교별 대상 급식 날짜와 식사 유형을 계산합니다. 이미 수집 완료된 급식 target은 건너뛰고, 아직 활성 상태인 `CollectionJob`은 재사용만 하며 신규 작업으로 다시 dispatch하지 않습니다.

Batch 애플리케이션은 수집 Scheduler에 필요한 Infra 패키지와 설정만 스캔하도록 좁혔습니다. 이로써 Batch 기동 시 Auth 메일 발송 Bean 같은 API 전용 설정이 함께 올라오지 않습니다.

## 주요 변경

### 등록 학교 수집 Scheduler

- `RegisteredSchoolMealCollectionScheduler`를 추가해 활성 구독 학교의 대상 날짜별 `CollectionJob`을 생성합니다.
- 기존 `meal_collection_versions`에 수집 완료 이력이 있는 급식은 중복 수집하지 않습니다.
- `CollectionJobRepository.createOrGetActive()` 결과가 새로 만든 작업 ID와 일치할 때만 비동기 dispatch합니다.
- Scheduler 결과로 활성 구독 수, 대상 수, 요청 작업 수, 스킵 수를 반환합니다.

### 활성 구독 조회 포트

- `SchoolCollectionSubscriptionRepository.findActiveSubscriptions()`를 추가했습니다.
- JDBC 구현은 `registered_child_count > 0`인 학교 구독만 조회합니다.

### Batch 기동과 설정

- `RegisteredSchoolMealCollectionScheduledTask`를 추가하고 `safe-meal.collection.scheduler.enabled` 설정으로 활성화합니다.
- 같은 프로세스 안에서 Scheduler 실행이 겹치지 않도록 `AtomicBoolean` 실행 가드를 둡니다.
- Batch 스캔 범위를 수집 관련 패키지로 제한하고, 수집 설정과 MinIO 설정만 명시적으로 import합니다.
- `safe-meal-batch`가 사용하는 Infra와 Jackson 의존성을 compile 의존성으로 명시했습니다.

## 영향 범위

- 등록 자녀가 있는 학교는 Batch Scheduler가 주기적으로 급식 수집 작업을 요청할 수 있습니다.
- 이미 수집 완료된 급식과 이미 활성 작업이 있는 급식은 중복 dispatch되지 않습니다.
- 외부 NEIS 호출 실패는 기존 수집 서비스 경로를 통해 `CollectionJob` 실패 상태와 실패 코드로 남습니다.
- 현재 Scheduler는 활성 구독 학교 전체를 대상으로 동작하며, 알림 대상 생성과 이메일 발송은 아직 제공하지 않습니다.

## 검증

- `.\gradlew.bat :safe-meal-batch:bootJar --no-daemon` 성공
- `docker compose --env-file .env.example ps`에서 PostgreSQL, Redis, RabbitMQ, MinIO, Mailpit healthy 확인
- Batch jar 실제 기동 검증 성공: 활성 구독 target 6건 중 기존 수집 완료 LUNCH 1건 skip, 신규 5건 dispatch
- 검증 Fixture 학교에서 BREAKFAST, DINNER 작업이 `FAILED`와 `NEIS_IO_ERROR`로 운영 데이터에 기록됨 확인
- 검증 Fixture와 검증 중 생성된 실패 `CollectionJob` 5건 정리 성공
- `.\gradlew.bat build --no-daemon` 성공
- `git diff --check` 성공

# 커밋 메시지

```text
feat: 등록 학교 급식 자동 수집 Scheduler 구현

- 활성 학교 수집 구독을 조회해 날짜별 급식 수집 작업을 멱등 생성
- 기존 수집 완료 target과 활성 CollectionJob 중복 dispatch 방지
- Batch Scheduler 설정과 실행 중복 방지 가드 추가
- Batch 기동 범위를 수집 관련 Infra 설정으로 제한
```
