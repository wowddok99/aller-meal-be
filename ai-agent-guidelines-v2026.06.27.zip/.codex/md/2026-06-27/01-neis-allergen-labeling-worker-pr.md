# PR 제목

feat: NEIS 알레르기 번호 라벨링 Worker 구현

# PR 본문

## 개요

NEIS 급식 메뉴의 원본 텍스트에 포함된 알레르기 번호만 사용해 메뉴별 알레르기 라벨을 저장하는 Worker 흐름을 추가합니다. 급식 수집 결과가 DB에 새로 저장된 경우에만 `MealCollected` Outbox 이벤트를 만들고, Worker는 해당 이벤트를 멱등 소비해 메뉴 라벨링 상태와 `meal_item_allergens` 관계를 갱신합니다.

라벨링 결과는 번호가 있으면 `LABELED`, 번호 정보가 없으면 `UNKNOWN`, 번호 suffix 형식이 깨졌거나 기준 알레르기 번호에 없는 값이면 `LABELING_FAILED`로 저장됩니다. 라벨링 완료 후에는 `MealLabeled` Outbox 이벤트를 만들고 공개 급식 Redis cache를 삭제해 `PENDING` 상태가 TTL 동안 남지 않게 했습니다.

## 주요 변경

### 라벨링 도메인 흐름

- `NeisAllergenLabelParser`를 추가해 메뉴 원본 텍스트의 마지막 괄호 suffix에서 NEIS 알레르기 번호만 추출합니다.
- `MealAllergenLabelingService`를 추가해 급식 단위 라벨링 상태를 계산하고 `MealLabeled` Outbox 이벤트를 생성합니다.
- 기준 알레르기 번호에 없는 값은 안전하게 `LABELING_FAILED`로 처리합니다.

### 저장 및 이벤트 연결

- `MealRepository`에 `findById()`와 `saveAllergenLabels()`를 추가하고 JDBC 구현에서 `meals`, `meal_items`, `meal_item_allergens`를 한 트랜잭션으로 갱신합니다.
- 급식 수집 저장이 실제 적용된 경우에만 `MealCollected` Outbox 이벤트를 생성합니다.
- Worker listener가 `MealCollected`만 처리하고 비대상 이벤트는 consumed 기록 없이 건너뜁니다.

### 공개 조회 cache 보호

- `PublicMealQueryCache`에 daily·weekly cache 삭제 계약을 추가했습니다.
- 라벨링 성공 뒤 해당 급식 날짜의 일간·주간 공개 조회 cache를 삭제합니다.
- Worker 실행 환경에서 공통 JSON 직렬화 bean을 사용할 수 있도록 `ObjectMapper` bean을 명시했습니다.

## 영향 범위

- NEIS 알레르기 번호가 있는 메뉴는 이후 위험도 계산에서 사용할 수 있는 `meal_item_allergens` 데이터로 저장됩니다.
- 정보 없음과 파싱 실패가 안전한 메뉴로 오인되지 않도록 상태를 분리합니다.
- 기존 공개 급식 조회는 유지되며, 라벨링 완료 직후 Redis READY cache가 삭제되어 다음 조회에서 갱신된 라벨링 상태를 읽습니다.
- 실제 RabbitMQ 재전송에서도 동일 `message_id`는 consumed 기록으로 한 번만 처리됩니다.
- 이번 검증은 Worker 책임 범위인 저장된 급식 라벨링과 이벤트 멱등성을 대상으로 했으며, NEIS API 실제 호출부터 원본 저장까지의 수집 파이프라인 E2E는 다시 실행하지 않았습니다.

## 검증

- `.\gradlew.bat build --no-daemon` 성공
- `jshell` NEIS 알레르기 parser smoke 성공
- `docker compose --env-file .env.example config --quiet` 성공
- `git diff --check` 성공
- `docker compose --env-file .env.example ps` 5개 서비스 `healthy` 확인
- Worker 실제 기동 및 Flyway V1~V15 검증 성공
- DB에 검증용 급식 데이터를 삽입한 뒤 RabbitMQ `MealCollected` publish, Worker 소비, 메뉴 라벨 저장, `MealLabeled` Outbox 생성 성공
- 동일 `message_id` 재전송 후 `MealLabeled` Outbox 1건과 consumed 1건 유지 확인

# 커밋 메시지

```text
feat: NEIS 알레르기 번호 라벨링 Worker 구현

- 수집 저장 완료 급식에 MealCollected Outbox 이벤트 생성
- Worker에서 MealCollected를 멱등 소비해 메뉴 알레르기 번호 저장
- 정보 없음과 파싱 실패 라벨링 상태 분리
- 라벨링 완료 후 MealLabeled Outbox 이벤트와 공개 급식 cache 삭제 추가
- Worker 런타임 JSON bean과 트랜잭션 proxy 기동 문제 수정
```
