# 자녀별 위험도 계산 완료 보고서

## 작업 범위

- 자녀 알레르기와 메뉴별 allergen code를 입력으로 받는 도메인 위험도 계산 계약을 추가했습니다.
- `UNKNOWN`, `LABELING_FAILED`, `PENDING` 메뉴가 `SAFE`로 반환되지 않도록 위험 상태를 분리했습니다.
- 급식 source 정보, 급식 날짜와 타입, 메뉴 원본, 메뉴별 allergen code, 자녀 allergen code 기반 `riskVersion`을 생성했습니다.

## 주요 변경

- `ChildMealRiskCalculator`가 메뉴별 교집합을 계산하고 전체 급식 위험도를 집계합니다.
- `ChildMealRisk`, `MealItemRisk`, `MealRiskLevel` 계약 타입을 독립 파일로 추가했습니다.
- 잘못된 allergen code와 급식에 없는 메뉴 ID 입력을 거부합니다.

## 검증 명령과 결과

- `$env:JAVA_HOME='C:\Program Files\Eclipse Adoptium\jdk-21.0.8.9-hotspot'; $env:Path="$env:JAVA_HOME\bin;$env:Path"; .\gradlew.bat build --no-daemon`: 성공
- Java 21 `jshell` 도메인 위험도 smoke: 교집합 `RISKY`, `UNKNOWN` 비안전, `LABELING_FAILED` 비안전, 급식 변경 시 `riskVersion` 변경 성공
- `git diff --check`: 성공

## 리뷰 결과

- 최초 리뷰: blocker/major 없음
- 후속 압축 리뷰: subagent 도구 모델 해석 문제로 실행 불가, 메인 스레드에서 수정 영향 범위 재검토 완료
- 잔여 위험: 사용자 요청 원칙에 따라 도메인 단위 테스트 파일은 작성하지 않았고, JShell smoke와 전체 빌드로 대체했습니다.

## 남은 블로커 또는 다음 행동

- 블로커 없음
- 다음 행동: 개인화 급식 API에서 owner-scoped 자녀 조회, 급식·메뉴 allergen 조회, 위험도 계산 결과 응답을 연결합니다.
