# Task 5.1 등록 학교 수집 Scheduler 완료 보고

## 작업 범위

- 활성 학교 수집 구독을 조회하는 application port/result와 JDBC 구현을 추가했다.
- `Asia/Seoul` 기준 대상 날짜와 `MealType`별 수집 작업을 생성하는 `RegisteredSchoolMealCollectionScheduler`를 추가했다.
- 이미 수집 완료된 target과 이미 활성 상태인 `CollectionJob`을 스킵해 중복 수집과 중복 dispatch를 방지했다.
- Batch Scheduler를 추가하고 `safe-meal.collection.scheduler.*` 설정으로 활성화·주기·대상 일수를 제어한다.
- Batch 앱 스캔 범위를 수집 Scheduler 필요 패키지와 설정으로 제한해 API Auth 메일 Bean 없이 기동되도록 정리했다.

## 리뷰 결과

- 최초 리뷰 발견: 기존 활성 PENDING 작업을 다시 dispatch할 수 있는 중복 dispatch 위험.
- 수정: `createOrGetActive()` 반환 작업 ID가 신규 pending 작업 ID와 같을 때만 dispatch한다.
- 추가 발견: Batch 전체 패키지 스캔으로 Auth 메일 Bean이 필요해 실제 Batch 기동 실패.
- 수정: Batch 스캔 범위를 수집 관련 패키지로 제한하고 필요한 Infra 설정만 import했다.
- 잔여 blocker/major 없음.

## 검증 명령과 결과

- `.\gradlew.bat :safe-meal-batch:bootJar --no-daemon`: 성공
- `docker compose --env-file .env.example ps`: PostgreSQL, Redis, RabbitMQ, MinIO, Mailpit healthy
- Batch jar 실제 기동: 성공
- Scheduler Fixture 검증: 활성 구독 target 6건 중 기존 수집 완료 LUNCH 1건 skip, 신규 5건 dispatch
- Fixture 학교 DB 확인: BREAKFAST, DINNER `CollectionJob`이 `FAILED`, `NEIS_IO_ERROR`로 기록됨
- 검증 Fixture와 검증 중 생성된 실패 `CollectionJob` 5건 정리: 성공
- `.\gradlew.bat build --no-daemon`: 성공
- `git diff --check`: 성공

## 남은 블로커 또는 다음 행동

- 블로커 없음.
- 다음 태스크는 Task 5.2 알림 대상 생성 Scheduler다.
