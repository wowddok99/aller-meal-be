# 개인화 오늘·주간 급식 API 완료 보고서

## 작업 범위

- 인증 자녀 기준 오늘, 특정 날짜, 주간 개인화 급식 위험도 조회 API를 추가했습니다.
- 기존 공개 급식 조회의 `READY`/`COLLECTING` 흐름을 재사용하고, 조회된 급식에 자녀별 위험도를 붙였습니다.
- 자녀 소유권 검증과 미인증 접근 차단을 실제 API 흐름으로 확인했습니다.

## 주요 변경

- `PersonalizedMealQueryService`가 owner-scoped 자녀 조회, 공개 급식 조회, 자녀 allergen code 조회, 메뉴 allergen code 조회, 위험도 계산을 조합합니다.
- `PersonalizedMealController`가 `/api/v1/children/{childId}/meals/today`, `/api/v1/children/{childId}/meals/{date}`, `/api/v1/children/{childId}/meals/weekly`를 제공합니다.
- API 응답에 급식 `riskLevel`, `riskVersion`, 메뉴별 `riskLevel`, `matchedAllergenCodes`를 포함했습니다.
- `ChildAllergenRepository`와 `MealRepository`에 위험도 조회용 읽기 메서드를 추가하고 JDBC 구현을 연결했습니다.

## 검증 명령과 결과

- `$env:JAVA_HOME='C:\Program Files\Eclipse Adoptium\jdk-21.0.8.9-hotspot'; $env:Path="$env:JAVA_HOME\bin;$env:Path"; .\gradlew.bat :safe-meal-api:compileJava --no-daemon`: 성공
- `$env:JAVA_HOME='C:\Program Files\Eclipse Adoptium\jdk-21.0.8.9-hotspot'; $env:Path="$env:JAVA_HOME\bin;$env:Path"; .\gradlew.bat build --no-daemon`: 성공
- `docker compose --env-file .env.example ps`: 5개 서비스 `healthy`
- API 실제 기동: Java 21, Flyway V1~V15 검증 성공
- `GET /api/v1/children/{childId}/meals/2026-06-27`: `200 READY`, meal 1건, 전체 위험도 `RISKY`, item 위험도 `RISKY`·`UNKNOWN`·`LABELING_FAILED`, matched allergen `[2]`, `riskVersion` 64자
- `GET /api/v1/children/{childId}/meals/weekly?date=2026-06-27`: `200 READY`, range `2026-06-22`~`2026-06-28`, meal 1건
- `GET /api/v1/children/{childId}/meals/today`: `200 READY`, `Asia/Seoul` 기준 `2026-06-27`, 위험도 응답
- 미인증 개인화 급식 조회: `401 UNAUTHORIZED`
- 교차 소유권 자녀 조회: `404 RESOURCE_NOT_FOUND`
- `git diff --check`: 성공

## 리뷰 결과

- 최초 리뷰: blocker/major 없음
- 후속 영향 범위 리뷰: endpoint routing, owner-scoped 조회, 202/200 응답, 위험도 상태 노출 확인
- 잔여 위험: 사용자 요청 원칙에 따라 API 통합 테스트 파일은 작성하지 않았고, 실제 API 기동과 PostgreSQL fixture 기반 검증으로 대체했습니다.

## 남은 블로커 또는 다음 행동

- 블로커 없음
- 다음 행동: Checkpoint 4에서 회원 자녀 등록부터 개인화 위험도 조회까지 실제 E2E 흐름을 검증합니다.
