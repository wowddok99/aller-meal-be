# PR 제목

feat: 개인화 급식 위험도 조회 API 추가

# PR 본문

## 개요

인증된 회원이 자녀별 오늘, 특정 날짜, 주간 급식 위험도를 조회할 수 있는 API를 추가했습니다.

조회 흐름은 기존 공개 급식 조회의 수집 상태와 재조회 응답을 재사용하고, 저장된 급식이 있으면 자녀 알레르기와 메뉴 allergen code를 결합해 개인화 위험도를 계산합니다.

자녀 조회는 항상 로그인 사용자 기준으로 제한하며, 다른 사용자의 자녀 ID는 리소스 없음으로 응답합니다.

## 주요 변경

### 개인화 급식 조회 API

- `GET /api/v1/children/{childId}/meals/today`로 `Asia/Seoul` 기준 오늘 급식 위험도를 조회합니다.
- `GET /api/v1/children/{childId}/meals/{date}`로 특정 날짜 급식 위험도를 조회합니다.
- `GET /api/v1/children/{childId}/meals/weekly?date=yyyy-MM-dd`로 해당 주 월요일부터 일요일까지 급식 위험도를 조회합니다.
- 수집이 끝난 대상은 `200 READY`, 아직 수집 대상이 남은 경우는 기존 공개 조회와 같은 `202 Accepted`와 `Retry-After`로 응답합니다.

### 위험도 응답

- 급식 응답에 `riskLevel`과 `riskVersion`을 추가했습니다.
- 메뉴 응답에 메뉴별 `riskLevel`과 `matchedAllergenCodes`를 추가했습니다.
- `UNKNOWN`, `LABELING_FAILED`, `PENDING` 메뉴는 안전으로 표시하지 않고 각각의 위험 상태로 응답합니다.

### 저장소 조회

- 자녀 allergen code를 owner-scoped로 조회하는 포트 메서드를 추가했습니다.
- 여러 급식의 메뉴 allergen code를 한 번에 조회하는 포트 메서드를 추가했습니다.
- PostgreSQL 조회는 모두 parameterized query로 구현했습니다.

## 영향 범위

- 회원은 자녀별 알레르기 설정이 반영된 개인화 급식 위험도를 API로 조회할 수 있습니다.
- 공개 급식 조회, 수집, 라벨링 Worker 계약은 변경하지 않았습니다.
- 다른 사용자의 자녀 ID를 통한 위험도 조회는 `404 RESOURCE_NOT_FOUND`로 차단됩니다.
- 실제 알림 생성과 알림 이력 조회는 아직 제공하지 않습니다.

## 검증

- `.\gradlew.bat :safe-meal-api:compileJava --no-daemon`: 성공
- `.\gradlew.bat build --no-daemon`: 성공
- Compose 5개 서비스 health 확인: 성공
- API 실제 기동 및 Flyway V1~V15 검증: 성공
- 인증된 자녀 날짜 급식 조회: `200 READY`, 전체 위험도 `RISKY`, 메뉴 위험도 `RISKY`, `UNKNOWN`, `LABELING_FAILED`, matched allergen `[2]`, `riskVersion` 64자 확인
- 인증된 자녀 주간 급식 조회: `200 READY`, range `2026-06-22`~`2026-06-28`, meal 1건 확인
- 인증된 자녀 오늘 급식 조회: `200 READY`, `Asia/Seoul` 기준 날짜와 위험도 응답 확인
- 미인증 개인화 급식 조회: `401 UNAUTHORIZED`
- 교차 소유권 자녀 조회: `404 RESOURCE_NOT_FOUND`
- `git diff --check`: 성공

# 커밋 메시지

```text
feat: 개인화 급식 위험도 조회 API 추가

- 자녀별 오늘, 날짜, 주간 급식 위험도 조회 API 추가
- 자녀 알레르기와 메뉴 알레르기 코드를 결합해 급식·메뉴 위험도 응답 생성
- owner-scoped 자녀 조회와 미인증·교차 소유권 차단 적용
```
