# Task 4.5 NEIS 알레르기 번호 라벨링 Worker

## 작업 범위

- NEIS 메뉴 원본 텍스트의 알레르기 번호 parser 구현
- `MealCollected` Outbox 생성과 Worker 소비 연결
- 메뉴별 알레르기 관계 저장 및 급식 라벨링 상태 갱신
- 처리 완료 시 `MealLabeled` Outbox 생성
- 라벨링 완료 후 공개 급식 Redis cache 삭제
- Worker 실제 기동 중 발견한 `ObjectMapper` bean 누락과 `final` service 트랜잭션 proxy 문제 수정
- 검증 범위는 DB에 저장된 급식 이후의 Worker 라벨링이며, NEIS API 실제 호출부터 원본 저장까지의 수집 파이프라인 E2E는 이번에 다시 실행하지 않았다.

## 주요 변경

- `NeisAllergenLabelParser`가 마지막 괄호 suffix에서 숫자만 추출한다.
- 번호가 없으면 `UNKNOWN`, malformed suffix 또는 기준 데이터에 없는 번호는 `LABELING_FAILED`로 처리한다.
- `JdbcMealRepository.saveAllergenLabels()`가 `meals`, `meal_items`, `meal_item_allergens`를 트랜잭션으로 갱신한다.
- Worker listener는 `MealCollected`만 멱등 소비하고 비대상 이벤트는 consumed 기록 없이 건너뛴다.
- reviewer major finding인 공개 급식 Redis cache stale 위험을 daily·weekly cache 삭제로 수정했다.
- Worker runtime wiring을 보강해 `safe-meal-worker`가 RabbitMQ listener까지 정상 시작되도록 했다.

## 검증 명령과 결과

- `.\gradlew.bat build --no-daemon`: 성공
- `jshell` parser smoke: 성공
  - `돼지고기볶음(5.6.10.13.)` -> `LABELED [5, 6, 10, 13]`
  - `백미밥` -> `UNKNOWN`
  - `메뉴명(채식)` -> `UNKNOWN`
  - `이상한메뉴(1.a)` -> `LABELING_FAILED`
- `docker compose --env-file .env.example config --quiet`: 성공
- `git diff --check`: 성공
- `docker compose --env-file .env.example ps`: 5개 서비스 `healthy`
- Worker 실제 기동 및 Flyway V1~V15 검증: 성공
- DB에 검증용 급식 데이터를 삽입한 뒤 RabbitMQ `MealCollected` publish routed true, Worker 소비, 메뉴 상태 저장, allergen 관계 4건, `MealLabeled` Outbox 1건 생성: 성공
- 동일 `message_id` 재전송 후 `MealLabeled` Outbox 1건, consumed 1건, allergen 관계 4건 유지: 성공
- 검증 데이터와 Worker 프로세스 정리: 완료

## 남은 블로커 또는 다음 행동

- 블로커 없음.
- 다음 행동은 자녀별 위험도 계산 입력 계약과 `UNKNOWN`·`LABELING_FAILED` 처리 기준 확인이다.
