# PR 제목

feat: 자녀별 급식 위험도 계산 추가

# PR 본문

## 개요

자녀가 등록한 알레르기와 라벨링된 메뉴 알레르기 코드의 교집합을 계산하는 도메인 계약을 추가했습니다.

메뉴 라벨링 결과가 `UNKNOWN`, `LABELING_FAILED`, `PENDING`인 경우에는 위험 없음으로 반환하지 않고 별도 위험 상태로 남겨 후속 개인화 조회 API가 안전 경고를 표시할 수 있게 했습니다.

위험도 결과는 급식 source 정보, 급식 날짜와 타입, 메뉴 원본, 메뉴별 allergen code, 자녀 allergen code를 SHA-256 canonical hash로 묶은 `riskVersion`을 포함합니다.

## 주요 변경

### 위험도 계산 계약

- `ChildMealRiskCalculator`가 자녀 allergen code와 메뉴별 allergen code를 정규화하고 교집합을 계산합니다.
- 메뉴별 결과인 `MealItemRisk`에 매칭된 allergen code와 메뉴 위험 상태를 담습니다.
- 급식 단위 결과인 `ChildMealRisk`에 전체 위험 상태, 메뉴별 결과, `riskVersion`을 담습니다.

### 비안전 라벨링 상태

- 라벨링 완료 메뉴에서 매칭 allergen code가 없을 때만 `SAFE`를 반환합니다.
- `UNKNOWN`, `LABELING_FAILED`, `PENDING` 메뉴는 `SAFE`가 아닌 각각의 상태로 반환합니다.
- 매칭된 allergen code가 하나라도 있으면 급식 전체 위험도는 `RISKY`로 반환합니다.

### 변경 감지

- 급식 source version, source 수신 시각, 급식 날짜와 타입, 메뉴 원본, 메뉴 라벨링 상태, 메뉴 allergen code, 자녀 allergen code가 바뀌면 `riskVersion`이 바뀝니다.
- 급식에 없는 메뉴 ID가 allergen code 입력에 포함되면 잘못된 입력으로 거부합니다.

## 영향 범위

- 후속 개인화 급식 조회 API에서 같은 급식이라도 자녀별 allergen 설정에 따라 다른 위험도를 계산할 수 있습니다.
- 라벨링 정보 없음과 라벨링 실패가 위험 없음으로 내려가지 않도록 도메인 기본값을 고정했습니다.
- 기존 공개 급식 조회, 수집, 라벨링 Worker 동작은 변경하지 않았습니다.
- 메뉴 allergen code 조회와 owner-scoped API 응답 연결은 아직 제공하지 않습니다.

## 검증

- `.\gradlew.bat build --no-daemon`: 성공
- Java 21 `jshell` 도메인 위험도 smoke: 교집합 `RISKY`, `UNKNOWN` 비안전, `LABELING_FAILED` 비안전, 급식 변경 시 `riskVersion` 변경 성공
- `git diff --check`: 성공

# 커밋 메시지

```text
feat: 자녀별 급식 위험도 계산 추가

- 자녀 알레르기와 메뉴 알레르기 코드의 교집합 계산 계약 추가
- UNKNOWN, LABELING_FAILED, PENDING 메뉴가 안전으로 반환되지 않도록 위험 상태 분리
- 급식과 메뉴, 자녀 알레르기 입력 변경을 반영하는 riskVersion 생성
```
