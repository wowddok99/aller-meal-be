# Task 4.3 자녀별 알림 설정 완료 보고

## 작업 범위

- 자녀별 이메일 알림 활성화, 알림 시각, 시간대를 관리하는 API와 저장 모델을 구현했습니다.

## 주요 변경

- `NotificationPreference` 도메인과 application port·service를 추가했습니다.
- `GET/PUT /api/v1/children/{childId}/notification-preference`를 추가했습니다.
- 소유자 범위 조회와 upsert를 적용했습니다.
- Flyway V14에 `notification_preferences` 1:1 테이블, `Asia/Seoul` CHECK 제약, 활성 알림 시각 index를 추가했습니다.
- 허용하지 않는 시간대는 `400 INVALID_REQUEST`로 응답합니다.

## 검증

- `sh ./gradlew clean build --no-daemon`: 성공
- Compose health 확인: PostgreSQL, Redis, RabbitMQ, MinIO, Mailpit 모두 healthy
- API 실제 기동 및 Flyway V14 적용: 성공
- 실제 API: 설정 `PUT 200`, 조회 `GET 200`, `UTC` 시간대 요청 `400 INVALID_REQUEST`, 검증 자녀 삭제 `204`

## 리뷰

- 전체 diff 리뷰 및 직접 영향 범위 압축 재검토 완료
- 미해결 blocker·major 없음

## 다음 행동

- Task 4.4 등록 학교 수집 구독의 계약과 저장 모델을 확인합니다.
