# Task 4.4 등록 학교 수집 구독 완료 보고

## 작업 범위

- 자녀 학교 등록과 연동되는 학교별 정기 수집 구독을 구현했습니다.
- 기존 자녀 API의 요청·응답 JSON 계약은 변경하지 않았습니다.

## 주요 변경

- Flyway V15로 `school_collection_subscriptions` 테이블을 추가하고 기존 `child_profiles`를 학교별로 집계해 이관했습니다.
- 구독은 학교당 한 행만 유지하며 `registered_child_count`와 `grace_ends_at`으로 활성 상태와 30일 유예를 표현합니다.
- 자녀 생성, 학교 변경, 삭제와 구독 카운트 변경을 하나의 트랜잭션으로 묶었습니다.
- 학교의 등록 자녀 수가 0에서 1이 되면 `Asia/Seoul` 기준 이번 주 월요일부터 일요일까지 모든 식사 유형의 `CollectionJob`을 생성하고 commit 뒤 비동기 수집을 요청합니다.

## 검증

- `sh ./gradlew :safe-meal-api:build --no-daemon`: 성공
- `sh ./gradlew build --no-daemon`: 성공
- Compose 5개 서비스 health 확인: 성공
- 실제 API와 PostgreSQL 검증: 첫 자녀 등록·같은 학교 두 번째 등록 후 구독 자녀 수 2, 유예 없음, 이번 주 `CollectionJob` 21건 확인
- 실제 API와 PostgreSQL 검증: 두 자녀 삭제 후 구독 자녀 수 0, 유예 종료 시각이 현재 이후이며 30일 이내 확인
- 검증용 자녀, 구독 행, 이번 주 수집 작업 삭제 완료

## 리뷰

- 전체 diff 5축 리뷰: `blocker`, `major`, `minor` 없음
- 하위 에이전트 delegation 제한으로 `cavecrew-reviewer` 대신 수정 범위 압축 로컬 재검토 수행: 새 `blocker`, `major` 없음

## 다음 행동

- Task 4.5에서 NEIS 알레르기 번호 라벨링 Worker와 `MealLabeled` Outbox 흐름을 구현합니다.
