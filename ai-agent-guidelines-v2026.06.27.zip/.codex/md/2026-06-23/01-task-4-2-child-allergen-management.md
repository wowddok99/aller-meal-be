# Task 4.2 자녀 알레르기 관리

## 작업 범위

- 자녀별 알레르기 목록 전체 교체 API와 PostgreSQL 저장 모델을 추가했습니다.
- 유효하지 않은 알레르기 code 거부와 자녀 소유권 검증을 포함했습니다.

## 주요 변경

- `PUT /api/v1/children/{childId}/allergens`가 `allergenCodes` 목록을 중복 제거·오름차순 정렬해 저장하고 반환합니다.
- `child_profile_allergens` 관계 테이블에 자녀·알레르기 FK와 복합 PK를 추가했습니다.
- owner-scoped 부모 행 잠금 뒤 기존 관계를 삭제·삽입하는 트랜잭션으로 동시 교체와 자녀 삭제 경합을 직렬화했습니다.
- null, 비양수, 기준 데이터에 없는 code를 `400 INVALID_REQUEST`로 응답합니다.

## 검증

- `sh ./gradlew clean build --no-daemon`: 성공
- 실제 API 기동 및 Flyway V13 적용: 성공
- 인증 사용자 교체 `[10,2,10]` 후 응답·DB 저장값 `[2,10]`: 성공
- 유효하지 않은 `20` 요청 `400 INVALID_REQUEST` 및 기존 목록 보존: 성공
- 타 사용자 요청 `404 RESOURCE_NOT_FOUND`: 성공
- 빈 목록 전체 해제와 동시 교체 요청의 단일 최종 목록 보존: 성공
- `docker compose --env-file .env.example ps`: PostgreSQL, Redis, RabbitMQ, MinIO, Mailpit 모두 healthy

## 리뷰 및 다음 행동

- 최초 리뷰의 동시 교체 경합 major 1건을 부모 행 잠금으로 수정했습니다.
- 후속 압축 검토에서 blocker·major 없음으로 확인했습니다.
- 다음 행동: Task 4.3 자녀별 알림 설정의 계약과 저장 모델을 확인합니다.
