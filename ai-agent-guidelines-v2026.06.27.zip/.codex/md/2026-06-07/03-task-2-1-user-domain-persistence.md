# Task 2.1 User 도메인과 영속성 완료 보고

## 작업 범위

- User 역할, 계정 상태, 이메일 인증 상태 및 허용 전이 정의
- 암호화 이메일, 검색 해시, 비밀번호 해시 값 객체 정의
- UserRepository 포트와 JPA 영속성 어댑터 구현
- users 테이블과 데이터 무결성 제약 추가

## 주요 변경

- 신규 User를 `MEMBER`, `ACTIVE`, `UNVERIFIED`로 생성하고 허용된 상태 전이만 제공
- 암호화 이메일 versioned envelope와 lowercase 64자리 검색 해시 검증
- 민감값 `toString()` 마스킹
- JPA Entity와 도메인 변환 경계를 infra 모듈에 배치
- 검색 해시 unique 제약, enum·해시·시각 CHECK, 낙관적 잠금 version 추가

## 검증 결과

- Java 21 `.\gradlew.bat clean build --no-daemon`: 성공
- API 실제 기동 및 JPA repository 발견: 성공
- Flyway V4 적용: 성공
- 실제 PostgreSQL 저장, 검색 해시 조회, unique 및 enum/hash CHECK 확인: 성공
- 도메인 상태 전이, 이메일 인증 멱등성, DISABLED 종료 상태 확인: 성공
- 민감값 `toString()` 마스킹 확인: 성공
- `docker compose --env-file .env.example ps`: 5개 서비스 모두 `healthy`
- 최종 리뷰: 미해결 blocker/major 없음

## 최종 점검

- 현재 변경은 이미 명확하고 역할별 책임이 분리되어 있어 동작 변경 없는 추가 단순화를 적용하지 않음
- 성공한 빌드와 실제 JPA/PostgreSQL 검증은 운영 코드 변경이 없어 반복하지 않음

## 잔여 위험 및 다음 행동

- 사용자 요청에 따라 도메인 단위 테스트와 JPA 통합 테스트 코드를 작성하지 않아 자동 회귀 탐지 범위가 제한됨
- `restoreFromPersistence`는 신뢰된 영속성 어댑터 전용 계약으로 유지하며 호출처 확장 시 검토 필요
- 다음 행동: Task 2.2 회원가입 및 이메일 인증 요청 명세 확정
