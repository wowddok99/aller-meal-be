# feat(user): 사용자 도메인 및 영속성 구현

## 개요

회원가입과 이메일 인증 기능을 구현하기 위해서는 User의 역할, 계정 상태,
이메일 인증 상태와 허용 가능한 상태 전이를 일관되게 관리할 도메인 모델이
필요했습니다.

또한 이메일 원문을 데이터베이스에 저장하지 않으면서 동일 이메일 가입 여부를
검색할 수 있어야 하며, 애플리케이션 도메인이 JPA에 직접 의존하지 않도록
영속성 경계를 분리할 필요가 있었습니다.

이에 따라 User 도메인 모델과 민감정보 값 객체를 정의하고, application port를
통해 JPA 영속성 adapter와 연결했습니다. PostgreSQL `users` 테이블에는
애플리케이션 검증을 우회한 잘못된 데이터 저장도 방지할 수 있도록 데이터
무결성 제약을 추가했습니다.

## 주요 변경

### User 도메인 모델을 추가했습니다.

- 신규 User를 `MEMBER`, `ACTIVE`, `UNVERIFIED` 상태로 생성하도록 했습니다.
- 계정 비활성화, 탈퇴 대기, 이메일 인증 등 허용된 상태 전이만 제공하도록
  했습니다.
- `DISABLED` 상태를 종료 상태로 처리해 이후 상태 변경을 차단했습니다.

### 이메일과 비밀번호 민감정보 값 객체를 추가했습니다.

- 암호화 이메일을 versioned envelope 형식으로 검증하도록 했습니다.
- 동일 이메일 검색을 위한 lowercase 64자리 검색 해시를 정의했습니다.
- 암호화 이메일, 검색 해시, 비밀번호 해시의 `toString()`에서 실제 값이
  노출되지 않도록 마스킹했습니다.

### User 영속성 경계를 구현했습니다.

- application 모듈에 `UserRepository` port를 추가했습니다.
- infra 모듈에 JPA Entity, Spring Data repository, repository adapter를
  추가했습니다.
- JPA repository와 Entity 탐색 범위를 runtime configuration에 연결했습니다.

### `users` 테이블 무결성 제약을 추가했습니다.

- 이메일 검색 해시에 unique 제약을 적용했습니다.
- 역할, 계정 상태, 이메일 인증 상태, 검색 해시 형식에 CHECK 제약을
  적용했습니다.
- 동시 수정 충돌 감지를 위한 낙관적 잠금 `version` 컬럼을 추가했습니다.

## 영향 범위

- 이후 회원가입과 이메일 인증 기능에서 User 도메인과 repository port를 사용할
  수 있습니다.
- 이메일 원문 대신 암호화 이메일과 검색 해시가 저장됩니다.
- 허용되지 않은 상태값, 잘못된 검색 해시, 중복 이메일 저장은 데이터베이스
  제약으로 차단됩니다.
- 기존 API와 비동기 이벤트 처리 흐름에는 변경이 없습니다.

## 검증 결과

- Java 21 `.\gradlew.bat clean build --no-daemon`: 성공
- API 실제 기동 및 JPA repository 발견: 성공
- Flyway V4 적용: 성공
- 실제 PostgreSQL 저장, 검색 해시 조회, unique 및 CHECK 제약 확인: 성공
- 도메인 상태 전이, 이메일 인증 멱등성, DISABLED 종료 상태 확인: 성공
- 민감값 `toString()` 마스킹 확인: 성공
- `docker compose --env-file .env.example ps`: 5개 서비스 모두 `healthy`
- 최종 리뷰: 미해결 blocker/major 없음
