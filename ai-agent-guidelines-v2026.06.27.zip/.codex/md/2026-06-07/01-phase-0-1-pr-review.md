# Phase 0~1 PR 리뷰 보완 결과

## 작업 범위

- Release 1 Phase 0~1 전체 Git change 검토
- `pr-reviewer` findings를 `impl-runner`로 수정
- `pr-reviewer`가 `CLEAN`을 반환할 때까지 반복

## 주요 변경

- API, Batch, Worker PostgreSQL·RabbitMQ 환경변수 연결
- Batch Outbox scheduler, Worker listener, RabbitMQ main/retry/DLQ topology 추가
- Publisher 및 Retry/DLQ 전송 confirm·return 검증
- Outbox insert-only 저장과 조건부 `PENDING→PUBLISHED` 전이
- Consumer 멱등 기록과 handler를 동일 DB transaction으로 연결
- Spring MVC 및 `/error` 응답을 공통 `ApiErrorResponse`와 `traceId` 계약으로 통일
- API 내부 details·임의 code·stack trace 노출 차단
- 루트 JUnit 5 공통 설정과 테스트 fixture·통합 테스트 분류 규칙 문서화

## 리뷰 결과

- 1차: Critical 4건, High 2건, Medium 1건
- 2차: Critical 1건, High 1건
- 3차: High 1건
- 4차: Medium 1건
- 5차: `CLEAN`

## 검증 결과

- Java 21 `.\gradlew.bat projects clean test build --no-daemon`: 성공
- API, Batch, Worker 실제 기동 및 Flyway V3 적용: 성공
- `docker compose --env-file .env.example ps`: 5개 서비스 모두 `healthy`
- Outbox 발행·Worker 소비: 성공
- 동일 이벤트 재전달 시 소비 기록 1건 유지: 성공
- retry 초과 후 DLQ 이동: 성공
- Retry unroutable 시 예외 전파 및 원본 unacked 유지: 성공
- RabbitMQ 중단 중 Outbox `PENDING` 유지, 복구 후 발행·소비: 성공
- 일반 404, 직접 `/error`, 실제 500 공통 응답과 `traceId`: 성공
- 검증 프로세스·데이터·DLQ 정리: 완료
- 테스트 코드 작성·수정: 없음

## 남은 작업

- Phase 0~1 변경 PR 생성
- 다음 구현 태스크: Task 2.1 User 도메인과 영속성

## 환경 조건

- Gradle 실행 전 Java 21 `JAVA_HOME` 설정 필요
- 실제 서비스 흐름 검증 시 Docker daemon 기동 필요
