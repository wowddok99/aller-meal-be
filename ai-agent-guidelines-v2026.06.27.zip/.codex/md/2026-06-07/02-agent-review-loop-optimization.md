# Agent 리뷰 루프 최적화

## 작업 범위

- `impl-runner` 유지
- `pr-reviewer` 전체 깊은 재검토 반복 제한
- Main orchestration 종료 조건 명시

## 주요 변경

- 최초 리뷰는 현재 태스크 diff 전체를 깊게 검토하도록 유지
- 후속 리뷰는 압축 출력 `cavecrew-reviewer`가 이전 발견사항, 수정 줄 및 직접
  영향 범위만 확인하도록 제한
- 새 `blocker` 또는 `major`, 공통 계약, 보안·트랜잭션·동시성 위험이 있을
  때만 전체 깊은 재검토 수행
- 리뷰 발견사항을 `impl-runner`가 가능한 한 한 번에 수정하도록 명시
- 미해결 `blocker`와 `major`가 없으면 리뷰 루프 종료
- 영향 변경 없이 성공한 검증 명령을 반복 실행하지 않도록 명시

## 검증

- Python `tomllib`로 `impl-runner.toml`, `pr-reviewer.toml` 파싱: 성공
- 변경 파일 후행 공백 검사: 없음
- `rg`로 orchestration 및 후속 리뷰 규칙 존재 확인: 성공
- `git diff --check`: 성공. 단, 변경 파일은 `.gitignore` 대상이라 diff에
  표시되지 않음

## 다음 행동

- 다음 구현 태스크부터 새 리뷰 흐름 적용
- 실제 사용 후 후속 리뷰가 범위를 과도하게 넓히는지 확인
- 팀 공유가 필요하면 agent 설정과 `AGENTS.md` 추적 정책을 별도로 결정
