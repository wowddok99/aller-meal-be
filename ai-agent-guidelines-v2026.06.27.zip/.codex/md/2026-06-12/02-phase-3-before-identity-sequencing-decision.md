# Phase 3 연속 진행 순서 결정

## 결정

- 현재 태스크를 Task 3.4 Meal 및 CollectionJob 도메인으로 지정한다.
- Task 3.4~3.7과 Checkpoint 3을 연속 완료한다.
- Checkpoint 3 완료 직후 Task 2.2로 복귀한다.
- Task 2.2~2.6과 Checkpoint 2를 완료한 뒤 Phase 4를 시작한다.

## 이유

- Task 3.1~3.3이 구현 및 실제 흐름 검증까지 완료되었다.
- Task 3.4~3.7은 `NEIS 원본 저장 -> 정규화 -> 공개 조회` 순서의 연속
  흐름이다.
- Checkpoint 3까지 진행하면 비회원 공개 급식 조회라는 독립적인 수직 기능이
  완성된다.
- 지금 Identity로 전환하면 NEIS 수집과 공개 조회 작업 컨텍스트가 끊긴다.
- Task 3.4~3.7은 Task 2.2~2.6에 의존하지 않는다.

## Task 2 재개 시점

- Checkpoint 3 검증 완료 직후 Task 2.2를 시작한다.
- Task 2.2~2.6과 Checkpoint 2는 중간에 다른 Phase로 전환하지 않고 순서대로
  완료한다.
- Task 4.1은 Task 2.3과 Task 3.2에 의존하므로 Checkpoint 2 완료 전에는
  Phase 4를 시작하지 않는다.

## 다음 행동

- Task 3.4 명세를 확정하고 Meal 및 CollectionJob 도메인을 구현한다.
