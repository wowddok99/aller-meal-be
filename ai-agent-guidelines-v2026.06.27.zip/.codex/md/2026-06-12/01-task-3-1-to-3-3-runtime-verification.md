# Task 3.1~3.3 실제 흐름 검증 완료 보고

## 작업 범위

- Task 3.1 Allergen 기준 데이터
- Task 3.2 School 도메인 및 NEIS 학교 검색
- Task 3.3 MinIO 원본 객체 저장 포트와 어댑터

## 주요 확인 결과

- Flyway V5~V7 마이그레이션 적용
- 알레르기 기준 데이터 19건과 목록 API 응답 확인
- 실제 NEIS 학교 검색 결과의 PostgreSQL 저장 확인
- 동일 학교 검색 반복 시 학교 row 중복 생성 없음 확인
- 빈 검색어 `400`, NEIS no-data 응답 `200`과 빈 목록 확인
- `MinioRawPayloadStorage.store()` 직접 호출로 실제 객체 저장 확인
- 객체 SHA-256과 만료 metadata의 MinIO·PostgreSQL 저장 확인

## 검증 명령과 결과

- Java 21 `.\gradlew.bat clean build --no-daemon`: 성공
- `docker compose --env-file .env.example config --quiet`: 성공
- `docker compose --env-file .env.example ps`: 검증 시점 5개 서비스 모두 `healthy`
- API 실제 기동: 성공
- Flyway schema history V1~V7: 모두 성공
- `GET /api/v1/allergens`: 19건 반환
- `GET /api/v1/public/schools?keyword=서울&page=1&pageSize=3`: 실제 NEIS 호출 및 DB 저장 성공
- 동일 학교 검색 반복: DB 학교 수 5건 유지
- `GET /api/v1/public/schools?keyword=%20`: `400`
- 존재하지 않는 학교 검색: `200`, 빈 목록
- `MinioRawPayloadStorage.store()` 직접 호출: 성공
  - 객체 key: `neis/2026/06/12/bd664856-17b2-4935-8f3a-ed3a63b28602.json`
  - 크기: 27 bytes
  - SHA-256: `9b5109fc32ddb3ca1591b4c56cedbbb9e26d9691121297e7afa5b847c5c52e2c`
  - PostgreSQL metadata 및 만료 시각 제약 확인

## 남은 블로커 및 다음 행동

- Task 3.1~3.3은 완료 처리한다.
- NEIS 작업 컨텍스트를 이어 Task 3.4~3.7과 Checkpoint 3을 먼저 완료한다.
- Checkpoint 3 완료 직후 Task 2.2로 복귀해 Task 2.2~2.6과 Checkpoint 2를
  순서대로 완료한다.
- Checkpoint 2와 Checkpoint 3이 모두 완료된 뒤 Phase 4를 시작한다.
