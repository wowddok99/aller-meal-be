# Task 2.2 회원가입 및 이메일 인증 요청

## 작업 범위

- `POST /api/v1/auth/signup` 추가
- `POST /api/v1/auth/email-verifications` 추가
- 회원가입 시 사용자 생성, 중복 이메일 방지, 인증 토큰 생성·해시 저장·TTL 적용
- Mailpit SMTP 인증 메일 발송
- 인증 토큰, 이메일 hash, 암호화 이메일, 비밀번호 hash API 응답 미노출

## 주요 변경

- API 계층에 auth controller, request, response 계약을 추가했다.
- application 계층에 `SignupService`, `EmailVerificationRequester`, 관련 command/result/예외를 추가했다.
- outbound port로 이메일 암호화, 이메일 검색 hash, 비밀번호 hash, 인증 토큰 생성·hash·저장, 인증 메일 발송 계약을 추가했다.
- infra 계층에 AES-GCM 이메일 envelope, SHA-256 검색/hash, PBKDF2 비밀번호 hash, Redis 인증 토큰 저장, SMTP 인증 메일 발송 구현을 추가했다.
- 인증 설정을 추가하고 `AUTH_EMAIL_ENCRYPTION_KEY`는 기본값 없이 환경변수로 요구한다.
- `.env.example`에 로컬 검증용 auth/mail 환경변수를 추가했다.
- signup 경계는 `TransactionalSignupHandler`에서 transaction으로 감싸 메일 발송 실패 시 사용자 저장이 rollback되도록 했다.

## 검증 명령과 결과

- `AUTH_EMAIL_ENCRYPTION_KEY=... sh ./gradlew :safe-meal-api:build --no-daemon`: 성공
- `AUTH_EMAIL_ENCRYPTION_KEY=... sh ./gradlew :safe-meal-api:bootRun`: 성공, Flyway 11개 migration 검증
- `POST /api/v1/auth/signup`: `201 Created`, `UNVERIFIED` 사용자 응답
- 중복 `POST /api/v1/auth/signup`: `409 EMAIL_ALREADY_EXISTS`
- `POST /api/v1/auth/email-verifications`: `202 Accepted`
- PostgreSQL `users`: `MEMBER`, `ACTIVE`, `UNVERIFIED`, encrypted email envelope, PBKDF2 password hash 확인
- Redis `email-verification:v1:{userId}`: TTL `1800`, SHA-256 hash 저장 확인
- Mailpit API: 인증 메일 수신 2건 확인
- `sh ./gradlew :safe-meal-api:dependencyInsight --dependency spring-tx --configuration runtimeClasspath --no-daemon`: `spring-tx:7.0.7` 선택 확인
- `AUTH_EMAIL_ENCRYPTION_KEY=... sh ./gradlew build --no-daemon`: 성공

## 리뷰 및 수정

- 최초 리뷰 발견사항 수정:
  - 암호화 key 기본값 제거
  - signup transaction 경계 추가
  - 이메일 형식 검증 강화
  - JSON `null` body 400 처리
- 후속 cavecrew 범위 검토:
  - `spring-tx` 직접 버전 지정으로 Spring Framework downgrade 위험 발견 후 Boot 관리 버전 사용으로 수정
  - 컨트롤러 final 관례 복구 및 transaction handler 분리

## 남은 블로커 또는 다음 행동

- Task 2.2 블로커 없음.
- 다음 작업은 `Task 2.3 이메일 인증 완료 및 로그인`이다.
