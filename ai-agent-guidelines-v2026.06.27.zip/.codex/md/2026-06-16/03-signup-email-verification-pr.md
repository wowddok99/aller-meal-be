# PR 제목

feat: 회원가입 및 이메일 인증 요청 구현

# PR 본문

## 개요

회원이 이메일과 비밀번호로 가입하고, 가입 직후 이메일 인증을 요청할 수 있는 Identity 시작 흐름을 추가했습니다. 이번 변경은 이메일 인증 완료와 로그인 전 단계까지만 다루며, JWT, Refresh Token, 비밀번호 재설정, CSRF 및 rate limit은 후속 태스크 범위로 남깁니다.

회원가입 시 이메일을 정규화하고 검색용 SHA-256 hash로 중복을 확인한 뒤, 암호화된 이메일과 비밀번호 hash를 사용자 정보로 저장합니다. 인증 토큰 원문은 API 응답, Redis, 로그에 남기지 않고 Redis에는 SHA-256 hash와 만료 시간만 저장합니다.

API, application, infra 계층의 책임을 분리했습니다. API는 요청·응답과 오류 code 매핑을 담당하고, application은 회원가입 및 인증 요청 유스케이스를 담당하며, infra는 AES-GCM 이메일 암호화, PBKDF2 비밀번호 hash, Redis 토큰 저장, SMTP 메일 발송을 담당합니다.

## 주요 변경

### 회원가입 API

- `POST /api/v1/auth/signup`을 추가해 `201 Created`와 `userId`, `emailVerificationStatus`를 반환합니다.
- 일반 회원가입은 항상 `MEMBER`, `ACTIVE`, `UNVERIFIED` 사용자로 생성됩니다.
- 정규화된 이메일의 SHA-256 hash로 중복 가입을 방지하고, 동시 요청으로 DB unique 제약에 걸린 경우도 `EMAIL_ALREADY_EXISTS`로 매핑합니다.
- 요청 본문이 없거나 이메일·비밀번호가 유효하지 않으면 기존 오류 응답 형식으로 `INVALID_REQUEST`를 반환합니다.

### 이메일 인증 요청

- `POST /api/v1/auth/email-verifications`를 추가해 미인증 계정의 인증 메일을 다시 발송할 수 있게 했습니다.
- Redis key `email-verification:v1:{userId}`에 인증 토큰의 SHA-256 hash를 저장하고 기본 30분 TTL을 적용합니다.
- 존재하지 않는 이메일은 `RESOURCE_NOT_FOUND`, 이미 인증된 이메일은 `EMAIL_ALREADY_VERIFIED`로 응답합니다.
- 회원가입 흐름은 transaction 경계 안에서 사용자 저장과 인증 메일 발송을 묶어 메일 발송 실패 시 사용자 저장이 rollback되도록 했습니다.

### 보안 및 저장 방식

- 이메일은 AES-GCM 기반 versioned envelope 형식으로 저장하고, 검색에는 정규화 이메일의 SHA-256 hash를 사용합니다.
- 비밀번호는 PBKDF2-HMAC-SHA256으로 salt와 반복 횟수를 포함한 hash 문자열로 저장합니다.
- 인증 토큰 원문, 이메일 검색 hash, 암호화 이메일, 비밀번호 hash는 API 응답에 포함하지 않습니다.
- `AUTH_EMAIL_ENCRYPTION_KEY`는 애플리케이션 설정 기본값 없이 환경변수로 요구하고, `.env.example`에는 로컬 검증용 값을 문서화했습니다.

### 메일 및 설정

- Spring Mail 의존성과 SMTP 설정을 추가해 Compose Mailpit `localhost:1025`로 인증 메일을 받을 수 있게 했습니다.
- `safe-meal.auth.email-verification-token-ttl`, `safe-meal.auth.email-verification-base-url`, `safe-meal.auth.email-from`, `safe-meal.auth.password-hash-iterations` 설정을 추가했습니다.
- `spring-tx`는 Spring Boot dependency management가 관리하는 버전을 사용하도록 선언했습니다.

## 영향 범위

- 새 회원은 가입 즉시 `UNVERIFIED` 상태로 저장되고 인증 메일을 받을 수 있습니다.
- Redis에는 인증 토큰 원문이 아니라 hash와 만료 시간만 저장되어 토큰 저장소 노출 시 피해 범위를 줄입니다.
- 이메일 인증 완료, 로그인, 세션 쿠키, Refresh Token rotation은 아직 동작하지 않습니다.
- API 기동 시 `AUTH_EMAIL_ENCRYPTION_KEY` 환경변수가 필요합니다. 로컬 실행은 `.env.example` 값을 사용할 수 있습니다.
- 기존 공개 학교·급식 조회 API와 수집 흐름은 변경하지 않았습니다.

## 검증

- `AUTH_EMAIL_ENCRYPTION_KEY=... sh ./gradlew :safe-meal-api:build --no-daemon`: 성공
- `AUTH_EMAIL_ENCRYPTION_KEY=... sh ./gradlew :safe-meal-api:bootRun`: 성공, Flyway 11개 migration 검증
- `POST /api/v1/auth/signup`: `201 Created`, `UNVERIFIED` 사용자 응답 확인
- 중복 `POST /api/v1/auth/signup`: `409 EMAIL_ALREADY_EXISTS` 확인
- `POST /api/v1/auth/email-verifications`: `202 Accepted` 확인
- PostgreSQL `users`: `MEMBER`, `ACTIVE`, `UNVERIFIED`, encrypted email envelope, PBKDF2 password hash 확인
- Redis `email-verification:v1:{userId}`: TTL `1800`, SHA-256 hash 저장 확인
- Mailpit API: 인증 메일 수신 2건 확인
- `sh ./gradlew :safe-meal-api:dependencyInsight --dependency spring-tx --configuration runtimeClasspath --no-daemon`: `spring-tx:7.0.7` 선택 확인
- `AUTH_EMAIL_ENCRYPTION_KEY=... sh ./gradlew build --no-daemon`: 성공
