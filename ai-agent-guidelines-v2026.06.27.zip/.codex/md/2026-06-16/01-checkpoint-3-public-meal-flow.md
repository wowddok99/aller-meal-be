# Checkpoint 3 공개 급식 조회 통합 검증

## 작업 범위

- `Checkpoint 3` 검증 수행
- 비회원 학교 검색, 학교 단건 조회, 일간·주간 급식 조회 확인
- NEIS 장애 상황에서 저장 데이터 fallback 확인
- PostgreSQL 정규화 데이터와 MinIO 원본 객체 metadata 정합성 확인

## 주요 결과

- `docker compose --env-file .env.example ps`에서 PostgreSQL, Redis, RabbitMQ, MinIO, Mailpit 5개 서비스가 모두 `healthy` 상태임을 확인했다.
- Java 21로 `safe-meal-api`를 실제 기동했고 Flyway 11개 migration 검증 및 schema 최신 상태를 확인했다.
- `/api/v1/public/schools?keyword=서울미동초등학교&page=1&pageSize=5`가 학교 1건을 반환했다.
- `/api/v1/public/schools/{schoolId}`가 `200`으로 학교 단건을 반환했다.
- `/api/v1/public/schools/{schoolId}/meals/2026-06-12`가 `200 READY`와 Meal 1건, MealItem 7건을 반환했다.
- `/api/v1/public/schools/{schoolId}/meals/weekly?date=2026-06-12`가 `200 READY`, `2026-06-08`~`2026-06-14` 범위, Meal 5건을 반환했다.
- Redis `public-meal-*` key를 삭제하고 `NEIS_BASE_URL=http://127.0.0.1:9`로 API를 재기동한 뒤에도 일간·주간 조회가 PostgreSQL 저장 데이터로 `200 READY`를 반환했다.
- PostgreSQL에서 서울미동초등학교 `2026-06-08`~`2026-06-12` 중식 Meal 5건과 각 MealItem 7건을 확인했다.
- `collection_jobs.raw_object_id`로 연결된 MinIO 원본 객체 metadata의 SHA-256 값이 PostgreSQL `raw_meal_objects.sha256_hash`와 일치했다.

## 검증 명령과 결과

- `docker compose --env-file .env.example up -d && docker compose --env-file .env.example ps`: 성공, 5개 서비스 `healthy`
- `sh ./gradlew :safe-meal-api:bootRun`: 성공, Java 21, Flyway 11개 migration 검증
- `curl /api/v1/public/schools?keyword=서울미동초등학교&page=1&pageSize=5`: 성공, 학교 1건
- `curl /api/v1/public/schools/{schoolId}`: 성공, `200`
- `curl /api/v1/public/schools/{schoolId}/meals/2026-06-12`: 성공, `200 READY`
- `curl /api/v1/public/schools/{schoolId}/meals/weekly?date=2026-06-12`: 성공, `200 READY`
- Redis `public-meal-*` key 삭제 후 `NEIS_BASE_URL=http://127.0.0.1:9 sh ./gradlew :safe-meal-api:bootRun`: 성공
- NEIS 장애 endpoint 상태의 일간·주간 조회: 성공, PostgreSQL fallback `200 READY`
- PostgreSQL `meals`, `meal_items`, `collection_jobs`, `raw_meal_objects` 조회: 성공
- MinIO `mc stat local/safe-meal-raw/{objectKey}`: 성공, SHA-256 metadata 확인

## 남은 블로커 또는 다음 행동

- Checkpoint 3 블로커 없음.
- 다음 작업은 `Task 2.2 회원가입 및 이메일 인증 요청`이다.
- Task 2.2는 `feature/signup-email-verification` 브랜치에서 `spec-writer → impl-runner → pr-reviewer → impl-runner findings 수정 → cavecrew-reviewer → 고위험 blocker/major 시 pr-reviewer → pr-finalizer` 흐름으로 진행한다.
