# pr-finalizer 에이전트 PR 문서 생성 지시 개선

## 작업 범위

- `.codex/agents/pr-finalizer.toml`의 PR 제목·본문 작성 지시를 명확화했다.
- 일반적인 PR 작성 지시 대신 `.agents/skills/pr-markdown-writer` Skill을 사용해 PR Markdown 문서를 생성하도록 변경했다.

## 주요 변경

- `pr-finalizer`가 PR 문서를 직접 임의 작성하지 않고 `pr-markdown-writer` Skill을 따르도록 지시했다.
- `SKILL.md`와 필요한 reference를 읽도록 명시했다.
- 현재 diff와 검증 결과에 근거한 한글 PR 제목·본문을 `.codex/md/YYYY-MM-DD/` 아래 Markdown 파일로 저장하도록 명시했다.

## 검증 명령과 결과

- `sed -n '1,220p' .codex/agents/pr-finalizer.toml`
  - 성공
  - 변경된 developer instructions 문구 확인
- `git diff -- .codex/agents/pr-finalizer.toml`
  - 출력 없음
  - `.codex/`가 로컬 전용/ignore 대상이라 Git diff에 표시되지 않음

## 남은 블로커 또는 다음 행동

- 없음
