# 에이전트 지침 패키저 Skill 생성

## 작업 범위

- `AGENTS.md`, `.agents/`, `.codex/`를 버전 zip으로 묶는 로컬 Skill을 생성했다.
- GitHub Wiki 업로드 기능은 제외하고 파일 생성 전용으로 구성했다.

## 주요 변경

- `.agents/skills/agent-guidelines-packager/SKILL.md`
  - Skill trigger와 사용 절차 작성
  - 기본 파일명 규칙 `ai-agent-guidelines-vYYYY.MM.DD.zip` 문서화
  - 동일 날짜 중복 시 `-r1`, `-r2` 자동 suffix 규칙 문서화
- `.agents/skills/agent-guidelines-packager/scripts/package_guidelines.py`
  - 필수 경로 `AGENTS.md`, `.agents`, `.codex` 검증
  - zip 생성 및 common local noise 제외
  - `--date`, `--revision`, `--output-dir`, `--overwrite` 옵션 지원
- `.agents/skills/agent-guidelines-packager/agents/openai.yaml`
  - 파일 생성 전용 설명으로 갱신
- 사용자 피드백 반영
  - `SKILL.md`, `agents/openai.yaml`, script 도움말·오류 문구를 한글로 변경
  - 구조화 key, 파일명, 명령 옵션은 그대로 유지

## 검증 명령과 결과

- `python3 .agents/skills/agent-guidelines-packager/scripts/package_guidelines.py`
  - 성공
  - `ai-agent-guidelines-v2026.06.16.zip` 생성
  - 포함 대상: `AGENTS.md`, `.agents`, `.codex`
- `ruby -e '...'`
  - 성공
  - `SKILL.md` YAML frontmatter 파싱 및 필수 field 확인
- `unzip -l ai-agent-guidelines-v2026.06.16.zip`
  - 성공
  - archive 내부 top-level entry 확인
- 한글화 후 `python3 .agents/skills/agent-guidelines-packager/scripts/package_guidelines.py --overwrite`
  - 성공
  - `ai-agent-guidelines-v2026.06.16.zip` 재생성
  - `files=87`
  - 최신 Skill 내용을 같은 날짜 zip에 재반영
- 한글화 후 `python3 .agents/skills/agent-guidelines-packager/scripts/package_guidelines.py --help`
  - 성공
  - script 설명과 옵션 도움말 한글 출력 확인

## 남은 블로커 또는 다음 행동

- `quick_validate.py`는 현재 Python 환경에 `PyYAML`이 없어 실행 실패했다.
  - 오류: `ModuleNotFoundError: No module named 'yaml'`
  - 필요 시 `PyYAML` 설치 후 재실행하면 된다.
- GitHub Wiki 업로드는 이번 요청 범위에서 제외했다.
