# AI Agent Guidelines

AI 코딩 에이전트 지침 파일 묶음을 버전별 zip 파일로 관리합니다.

## Latest

- [ai-agent-guidelines-v2026.06.27.zip](ai-agent-guidelines-v2026.06.27.zip)

## Versions

| Version | Date | File |
| --- | --- | --- |
| v2026.06.27 | 2026-06-27 | [Download](ai-agent-guidelines-v2026.06.27.zip) |
| v2026.06.23 | 2026-06-23 | [Download](https://github.com/user-attachments/files/29256314/ai-agent-guidelines-v2026.06.23.zip) |
| v2026.06.21 | 2026-06-21 | [Download](https://github.com/user-attachments/files/29173797/ai-agent-guidelines-v2026.06.21.zip) |
| v2026.06.20 | 2026-06-20 | [Download](https://github.com/user-attachments/files/29156439/ai-agent-guidelines-v2026.06.20.zip) |
| v2026.06.16 | 2026-06-16 | [Download](https://github.com/user-attachments/files/29000537/ai-agent-guidelines-v2026.06.16.zip) |
| v2026.06.15 | 2026-06-15 | [Download](https://github.com/user-attachments/files/28957092/ai-agent-guidelines-v2026.06.15.zip) |

## Package Contents

각 버전 zip에는 아래 파일/폴더가 포함됩니다.

- AGENTS.md
- .agents/
- .codex/

## Version Rule

버전명은 아래 형식을 사용합니다.

- ai-agent-guidelines-vYYYY.MM.DD.zip

같은 날짜에 추가 갱신이 필요한 경우 revision suffix를 붙입니다.

- ai-agent-guidelines-vYYYY.MM.DD-r1.zip
- ai-agent-guidelines-vYYYY.MM.DD-r2.zip

## Update Rule

새 버전을 등록할 때는 아래 항목을 갱신합니다.

- Latest 링크를 새 zip 파일로 교체
- Versions 표 맨 위에 새 버전 한 줄 추가
