# Task 3.6 공개 학교·급식 조회 API 명세

## 목표

- 비회원이 저장된 학교와 일간·주간 일반 급식을 조회한다.
- 저장 여부가 아직 확정되지 않은 급식 target은 멱등한 `CollectionJob`을 만들고
  비동기 수집을 시작한다.
- 급식 없음 tombstone을 완성 데이터로 취급해 반복 수집하지 않는다.
- 공개 응답에 개인화 위험도를 포함하지 않는다.

## API 계약

```http
GET /api/v1/public/schools/{schoolId}
GET /api/v1/public/schools/{schoolId}/meals/{date}
GET /api/v1/public/schools/{schoolId}/meals/weekly?date={date}
```

- `schoolId`: UUID
- `date`: ISO-8601 `LocalDate`
- 일간 조회 target: 지정 날짜의 `BREAKFAST`, `LUNCH`, `DINNER`
- 주간 조회 target: 지정 날짜가 속한 월요일부터 일요일까지 각 meal type
- 학교가 없으면 `404 RESOURCE_NOT_FOUND`
- 하나 이상의 target이 미확인 또는 처리 중이면 `202 Accepted`와
  `Retry-After: 3` 반환
- 모든 target이 확인 완료이면 `200 OK`

## 응답 계약

- 학교 응답: 기존 검색 계약과 같은 `id`, `neisSchoolCode`,
  `educationOfficeCode`, `name`, `address`, `region`
- 급식 조회 응답:
  - `schoolId`
  - `rangeStart`, `rangeEnd`
  - `collectionStatus`: `READY` 또는 `COLLECTING`
  - `retryAfterSeconds`: `READY`면 `null`, `COLLECTING`이면 `3`
  - `meals`: 저장된 일반 급식 목록
  - `pendingTargets`: 아직 완료되지 않은 날짜·meal type 목록
- 급식은 메뉴명, NEIS 원문, 라벨링 상태, 영양·원산지 정보와 원본 수신 시각을
  제공한다.
- 자녀, 개인 알레르기 교집합, 위험 수준 등 개인화 필드는 제공하지 않는다.

## 조회 완료 판정

- `meal_collection_versions` row 존재: 조회 완료. `has_meal=false`도 완료로 취급.
- row 미존재: 미확인. `CollectionJobRepository.createOrGetActive()`로 target별
  활성 작업을 멱등 생성한다.
- `PENDING` 작업은 프로세스 재시작과 executor 거절 후 복구할 수 있도록 비동기
  실행기에 전달한다. 상태 CAS가 외부 호출 전 단일 `RUNNING` 전이를 보장한다.
- 기존 `RUNNING` 작업은 재사용하고 실행기에 다시 전달하지 않는다.

## 구현 계획

1. 학교 단건 조회와 기간 급식 조회를 위한 outbound query 계약을 확장한다.
2. 공개 급식 조회 유스케이스와 독립 application 결과 계약을 추가한다.
3. PostgreSQL 조회와 비동기 수집 dispatch 어댑터를 추가한다.
4. 공개 학교 단건·일간·주간 controller 및 독립 API 응답 계약을 추가한다.
5. Java 21 clean build, 실제 API `200/202`, 중복 작업, tombstone 재조회 흐름을
   검증한다.
