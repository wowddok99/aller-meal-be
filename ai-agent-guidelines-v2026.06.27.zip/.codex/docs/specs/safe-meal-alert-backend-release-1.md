# SafeMeal Alert Backend Release 1 명세

## 1. 문서 상태

- 상태: 승인 대기
- 대상 저장소: `aller-meal-be`
- 기준 런타임: Java 21, Spring Boot 4.0.6
- 배포 환경: 온프레미스 Docker Compose
- 범위: 백엔드 및 로컬·온프레미스 운영 구성
- 제외: Next.js 프론트엔드 구현

## 2. 목표

SafeMeal Alert는 NEIS 학교 급식 데이터를 수집·정규화하고, 회원이 등록한
자녀별 알레르기 조건과 급식을 비교해 위험 메뉴를 탐지하고 이메일로 알리는
웹서비스다.

비회원은 학교와 날짜를 검색해 일반 급식 및 NEIS 알레르기 정보를 조회할 수
있다. 회원은 여러 자녀의 학교·알레르기·알림 설정을 관리하고 개인화된 위험도,
알림 및 알림 이력을 사용할 수 있다.

### 핵심 성공 조건

- 비회원이 학교를 검색하고 특정 날짜의 급식을 조회할 수 있다.
- 회원이 여러 자녀와 자녀별 학교·알레르기·알림 설정을 관리할 수 있다.
- NEIS 알레르기 번호만 사용해 개인별 위험 메뉴를 정확히 계산한다.
- 등록 학교의 급식을 자동 수집하고 수집 원본을 MinIO에 보존한다.
- RabbitMQ와 Outbox를 사용해 라벨링 및 이메일 알림을 안정적으로 처리한다.
- 실패한 수집·이벤트·알림을 관리자가 조회하고 재처리할 수 있다.
- 핵심 데이터는 Redis 또는 RabbitMQ 장애에도 유실되지 않는다.

## 3. 비목표

Release 1에는 다음을 포함하지 않는다.

- 웹푸시 알림
- 주간 요약 알림
- 메뉴명 기반 알레르기 추론
- 여러 보호자의 자녀 공동 관리
- 전국 학교 급식 사전 수집
- Prometheus, Grafana, Loki 대시보드
- k6 부하 테스트
- AWS SQS, S3, ECS 어댑터 및 배포
- 프론트엔드 구현

## 4. 사용자 및 권한

### 비회원

- 학교 검색
- 학교별 날짜·주간 일반 급식 조회
- 메뉴별 NEIS 알레르기 정보 조회
- 개인 알레르기 매칭 및 알림 사용 불가

### 회원

- 이메일 인증 기반 계정 사용
- 여러 자녀 등록
- 자녀별 학교, 알레르기, 알림 설정 관리
- 자녀별 오늘·주간 위험 급식 조회
- 이메일 알림 및 알림 이력 조회
- 본인 소유 자녀 데이터에만 접근

### 관리자

- 수집·외부 API·이벤트·알림 실패 조회
- 멱등 키를 사용한 수동 재수집 및 재처리
- 사용자 권한 승격
- 관리자 액션 감사 로그 조회

## 5. 확정 기술 스택

### 애플리케이션

- Java 21
- Spring Boot 4.0.6
- Gradle Kotlin DSL
- Spring MVC
- Spring Security
- Spring Data JPA
- Spring Validation
- Spring AMQP
- Spring Data Redis
- Spring Actuator
- Springdoc OpenAPI 호환 버전
- Flyway 호환 버전
- Resilience4j 호환 버전

Spring Boot 4.0.6과 호환되는 서드파티 라이브러리 버전은 각 의존성 도입 태스크
시 공식 문서와 릴리스 정보를 확인한 후 고정한다.

### 데이터 및 인프라

- PostgreSQL: 정규화 데이터, 메타데이터, 감사 로그, Outbox
- Redis: 토큰, 인증 코드, 잠금, rate limit, 조회 캐시, 단기 멱등 키
- RabbitMQ: 라벨링 및 알림 비동기 이벤트
- MinIO: NEIS 원본 응답
- Mailpit: 개발 이메일 수신 확인
- Caddy: 단일 도메인 TLS 및 리버스 프록시
- Docker Compose: 개발 및 온프레미스 실행

## 6. 배포 및 실행 구조

### 실행 애플리케이션

```text
safe-meal-api     사용자·관리자 REST API 및 인증
safe-meal-batch   등록 학교 급식 수집 및 알림 대상 생성 스케줄러
safe-meal-worker  RabbitMQ 이벤트 소비, 라벨링, 이메일 발송
```

### 라이브러리 모듈

```text
safe-meal-application  유스케이스, 트랜잭션 경계, 포트
safe-meal-domain       도메인 모델과 순수 비즈니스 규칙
safe-meal-infra        DB, Redis, RabbitMQ, MinIO, NEIS, SMTP 어댑터
```

### 모듈 의존 방향

```text
api ------\
batch -----+--> application --> domain
worker ---/

infra --> application
infra --> domain

domain은 다른 프로젝트 모듈에 의존하지 않는다.
application은 infra에 의존하지 않는다.
```

실행 모듈은 필요한 어댑터를 조립하기 위해 `infra`에 런타임 의존할 수 있다.

### 온프레미스 진입 구조

```text
https://safemeal.example.com/api/*  -> safe-meal-api
https://safemeal.example.com/*      -> 별도 Next.js 서비스
```

Caddy만 외부에 공개한다. PostgreSQL, Redis, RabbitMQ, MinIO, Mailpit 및 내부
애플리케이션 포트는 외부에 공개하지 않는다.

## 7. DDD 경계

### Identity

- `User`
- 이메일 인증
- 로그인 및 토큰 세션
- 비밀번호 재설정
- 역할 및 계정 상태

### Child Management

- `ChildProfile`
- 자녀 학교
- 자녀 알레르기
- 자녀별 알림 설정
- 사용자 소유권 규칙

### School and Meal

- `School`
- `Meal`
- `MealItem`
- `Allergen`
- `CollectionJob`
- NEIS 수집 및 정규화

### Risk Assessment

- 자녀 알레르기와 급식 항목 비교
- 위험 수준 및 일치 항목 계산
- 판정 실패 상태 관리

### Notification

- `Notification`
- 이메일 발송
- 중복 방지 및 정정 알림
- 실패 및 재시도

### Operations

- Outbox 이벤트
- Consumer 처리 이력
- 관리자 감사 로그
- 실패 조회 및 재처리

경계 간 호출은 application 포트와 명시적인 이벤트 계약을 통해 수행한다.

## 8. 핵심 도메인 규칙

### 자녀 및 학교

- 한 사용자는 여러 자녀를 소유할 수 있다.
- 자녀는 현재 학교 하나를 가진다.
- 모든 자녀 API는 현재 사용자의 소유권을 검증한다.
- 자녀가 학교를 등록하면 당일 및 현재 주 급식을 즉시 수집 요청한다.
- 등록 자녀가 존재하는 학교만 정기 수집한다.
- 마지막 등록 자녀가 제거된 학교는 유예기간 30일 후 정기 수집을 중단한다.

### 공개 급식 조회

- 비회원 조회 데이터가 DB 또는 Redis에 있으면 저장된 데이터를 반환한다.
- 데이터가 없으면 비동기 수집 작업을 생성하고 `202 Accepted`와 재조회 정보를
  반환한다. 클라이언트는 같은 급식 조회 URL을 다시 호출한다.
- 비회원 조회만으로 해당 학교를 정기 수집 대상으로 등록하지 않는다.
- 실시간 호출 실패 시 저장된 최신 데이터가 있으면 기준 시각과 함께 반환한다.
- 공개 조회 API에는 IP 기반 rate limit을 적용한다.

### 알레르기 판정

- NEIS가 제공한 알레르기 번호만 판정에 사용한다.
- 메뉴명 텍스트로 알레르기를 추론하지 않는다.
- 번호 정보가 없으면 `UNKNOWN`이며 안전으로 간주하지 않는다.
- 파싱 실패 급식은 `LABELING_FAILED`로 처리하고 개인화 위험도를 제공하지 않는다.
- 서비스 결과는 참고 정보이며 의료적 안전을 보장하지 않음을 API와 UI 계약에
  포함한다.

### 알림

- 알림 설정은 자녀별로 관리한다.
- Release 1 알림 채널은 이메일만 구현한다.
- 위험 메뉴가 있을 때만 이메일을 발송한다.
- 위험 없음은 `SKIPPED_NO_RISK`, 급식 없음은 `SKIPPED_NO_MEAL` 이력으로 남긴다.
- 중복 키는 `childId + mealDate + mealType + channel + riskVersion`이다.
- 급식 변경으로 위험 항목이 달라지면 새 `riskVersion`으로 정정 알림을 발송한다.

### 시간

- DB의 시각은 UTC `Instant`로 저장한다.
- 급식 날짜는 한국 학교 기준 `LocalDate`다.
- 초기 허용 시간대는 `Asia/Seoul`만 사용한다.
- API 시각 응답은 ISO-8601 offset 형식이다.
- 서버 운영체제 시간대에 의존하지 않는다.

## 9. 인증 및 보안

### 인증 토큰

- Access Token: JWT, 15분 만료
- Refresh Token: 랜덤 불투명 토큰, 14일 만료
- 두 토큰 모두 `HttpOnly`, `Secure` 쿠키로 전달
- Access 쿠키는 `SameSite=Lax`
- Refresh 쿠키는 가능한 범위에서 `SameSite=Strict` 및 제한된 path 사용
- Refresh Token은 Redis에 해시로 저장
- 갱신 시 rotation 및 재사용 탐지
- 로그아웃 시 Redis 세션 폐기 및 쿠키 삭제

### 계정 보안

- 이메일 인증 완료 전 주요 회원 기능 사용 제한
- 이메일 인증 및 비밀번호 재설정 토큰은 Redis에 해시로 저장하고 일회성 사용
- 로그인 실패 횟수 제한과 임시 잠금
- 인증 API rate limit
- 비밀번호는 강한 단방향 해시 사용
- 사용자 이메일은 암호화 저장하고 정규화 검색용 해시를 별도 저장
- 쿠키 인증 요청은 SameSite, Origin 검증 및 CSRF 방어를 적용

### 관리자

- 일반 회원가입으로 관리자 생성 금지
- 최초 관리자는 환경변수 기반 bootstrap 명령으로 생성
- 이후 관리자는 기존 관리자가 승격
- 관리자 변경 작업은 실행자, 시각, 대상, 요청 멱등 키 및 결과를 감사 로그로 저장

## 10. 수집 및 비동기 처리

### 등록 학교 정기 수집

```text
safe-meal-batch
-> 활성 수집 학교 조회
-> NEIS API 호출
-> MinIO 원본 저장
-> PostgreSQL CollectionJob 및 원본 메타데이터 저장
-> Outbox MealCollected 생성
-> Outbox Publisher가 RabbitMQ 발행
-> safe-meal-worker가 라벨링
-> 정규화 Meal 및 MealItem 저장
-> Outbox MealLabeled 생성
-> 알림 대상 계산 및 NotificationRequested 발행
-> 이메일 발송 및 Notification 이력 저장
```

### 안정성 규칙

- 외부 API 응답은 신뢰하지 않고 경계에서 검증한다.
- NEIS 호출에는 timeout, 제한된 retry, 지수 backoff, circuit breaker를 적용한다.
- DB 변경과 이벤트 생성은 같은 트랜잭션의 Outbox로 처리한다.
- Consumer는 이벤트 ID 기반으로 멱등 처리한다.
- 재시도 한도 초과 메시지는 DLQ로 이동한다.
- RabbitMQ 장애 시 Outbox에 이벤트가 남아 복구 후 재발행된다.
- MinIO 저장 성공 전에 원본 저장 완료 상태로 기록하지 않는다.

## 11. 주요 데이터 모델

### Identity

- `users`: 계정, 암호화 이메일, 이메일 해시, 비밀번호 해시, 역할, 상태
- `user_sessions`: 선택적 영속 세션 감사 메타데이터

### Child Management

- `child_profiles`: 사용자, 이름, 학년, 반, 학교
- `child_allergens`: 자녀와 알레르기 관계
- `notification_preferences`: 자녀별 이메일 활성화, 알림 시각, 시간대

### School and Meal

- `schools`: NEIS 학교 코드, 교육청 코드, 이름, 주소, 지역
- `school_collection_subscriptions`: 정기 수집 상태 및 유예 종료일
- `collection_jobs`: 대상 학교·날짜, 상태, 응답 시간, 실패 정보
- `raw_meal_objects`: MinIO 객체 키, 해시, 크기, 수신 시각, 만료 시각
- `meals`: 학교, 날짜, 식사 타입, 상태, 영양·원산지 메타데이터
- `meal_items`: 메뉴명, 원본 텍스트, 순서, 라벨링 상태
- `allergens`: NEIS 알레르기 코드 및 이름
- `meal_item_allergens`: 메뉴와 알레르기 관계

### Notification and Operations

- `notifications`: 자녀, 날짜, 채널, 상태, 제목, 본문, 재시도, 실패 사유
- `outbox_events`: 이벤트 ID, 타입, payload, 상태, 발행 시각
- `consumed_events`: Consumer와 이벤트 ID 멱등 처리 이력
- `admin_audit_logs`: 관리자 변경 액션 감사 로그

모든 주요 테이블은 생성·수정 시각을 가진다. 사용자 소유 데이터와 운영 데이터의
삭제 정책을 분리한다.

## 12. 이벤트 계약

### `MealCollected`

- `eventId`
- `occurredAt`
- `collectionJobId`
- `schoolId`
- `mealDate`
- `rawObjectKey`
- `rawObjectHash`

### `MealLabeled`

- `eventId`
- `occurredAt`
- `mealId`
- `schoolId`
- `mealDate`
- `mealType`
- `riskVersion`

### `NotificationRequested`

- `eventId`
- `occurredAt`
- `notificationId`
- `childId`
- `mealId`
- `channel`
- `riskVersion`

이벤트는 추가 가능한 버전 필드를 가지며 이미 발행한 필드를 제거하거나 의미를
변경하지 않는다. Consumer는 중복 및 순서 역전을 허용하도록 설계한다.

## 13. REST API 계약

모든 응답 필드는 `camelCase`, enum 값은 `UPPER_SNAKE`를 사용한다. 목록 API는
페이지네이션을 제공한다. 오류 응답 형식은 전체 API에서 동일하다.

### 공통 오류

```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "요청 값이 올바르지 않습니다.",
    "details": [],
    "traceId": "..."
  }
}
```

### 공개 API

```http
GET /api/v1/public/schools?keyword={keyword}&page={page}&pageSize={pageSize}
GET /api/v1/public/schools/{schoolId}
GET /api/v1/public/schools/{schoolId}/meals/{date}
GET /api/v1/public/schools/{schoolId}/meals/weekly?date={date}
```

### 인증 API

```http
POST /api/v1/auth/signup
POST /api/v1/auth/email-verifications
POST /api/v1/auth/email-verifications/confirm
POST /api/v1/auth/login
POST /api/v1/auth/refresh
POST /api/v1/auth/logout
POST /api/v1/auth/password-resets
POST /api/v1/auth/password-resets/confirm
```

### 자녀 및 개인화 API

```http
POST   /api/v1/children
GET    /api/v1/children
GET    /api/v1/children/{childId}
PATCH  /api/v1/children/{childId}
DELETE /api/v1/children/{childId}

GET /api/v1/allergens
PUT /api/v1/children/{childId}/allergens

GET /api/v1/children/{childId}/notification-preference
PUT /api/v1/children/{childId}/notification-preference

GET /api/v1/children/{childId}/meals/today
GET /api/v1/children/{childId}/meals/weekly?date={date}
GET /api/v1/children/{childId}/meals/{date}

GET /api/v1/children/{childId}/notifications?page={page}&pageSize={pageSize}
```

### 사용자 API

```http
DELETE /api/v1/users/me
POST   /api/v1/users/me/deletion-cancellation
```

### 관리자 API

```http
GET  /api/v1/admin/dashboard
GET  /api/v1/admin/collections
GET  /api/v1/admin/collections/failures
POST /api/v1/admin/collections/{collectionId}/retry
GET  /api/v1/admin/external-api-logs
GET  /api/v1/admin/notifications/failures
POST /api/v1/admin/notifications/{notificationId}/retry
GET  /api/v1/admin/dead-letters
POST /api/v1/admin/dead-letters/{eventId}/retry
GET  /api/v1/admin/audit-logs
POST /api/v1/admin/users/{userId}/roles/admin
```

관리자 변경 API는 `Idempotency-Key` 헤더를 필수로 받는다.

## 14. 공개 급식 조회 처리

```text
1. Redis 캐시 조회
2. PostgreSQL 정규화 급식 조회
3. 저장 데이터가 있으면 Redis 캐시 저장 후 응답
4. 저장 데이터가 없으면 멱등한 CollectionJob 생성
5. 수집 이벤트 발행
6. 202 Accepted + Retry-After + collectionStatus 응답
7. Worker가 NEIS 조회, MinIO 원본 저장, 정규화 및 라벨링
8. 클라이언트 재조회 시 완성된 데이터 응답
```

- 동일 학교·날짜·식사 타입에 대한 동시 요청은 single-flight 또는 분산 잠금으로
  외부 API 중복 호출을 제한한다.
- 처리 중인 동일 수집 작업이 있으면 새 작업을 만들지 않고 기존 작업 상태를
  반환한다.
- 저장된 최신 데이터가 있지만 갱신이 필요한 경우에는 최신 데이터를 즉시
  반환하면서 백그라운드 갱신 작업을 생성할 수 있다.
- 캐시 키는 스키마 버전을 포함한다.
- 캐시가 없어도 PostgreSQL에서 정상 응답할 수 있어야 한다.

## 15. 데이터 보존 및 삭제

- 회원 탈퇴 요청 즉시 계정을 비활성화한다.
- 탈퇴 후 7일 동안 취소 가능하며 이후 사용자·자녀·설정 데이터를 영구 삭제한다.
- 탈퇴 요청 시 알림 본문과 수신 이메일을 즉시 마스킹한다.
- 관리자 감사 로그 및 개인정보 없는 운영 로그는 1년 보존한다.
- NEIS 원본 응답은 MinIO에 90일 보존 후 삭제한다.
- 정규화 급식 데이터는 장기 보존한다.

## 16. 관측성 및 운영

- 모든 요청에 `traceId`를 부여하고 오류 응답 및 구조화 로그에 포함한다.
- 외부 API 호출 시간, 수집 성공·실패, Outbox 대기, Consumer 실패, DLQ,
  이메일 성공·실패 지표를 기록한다.
- Actuator health는 PostgreSQL, Redis, RabbitMQ, MinIO 의존성을 구분해 노출한다.
- readiness와 liveness를 분리한다.
- 비밀값은 저장소에 commit하지 않고 환경변수 또는 Docker Secret으로 주입한다.

## 17. 검증 전략

- 테스트 코드는 사용자가 명시적으로 요청한 경우에만 작성하거나 수정한다.
- 컴파일과 전체 빌드 성공을 확인한다.
- 실제 애플리케이션을 기동해 설정과 의존성 연결을 확인한다.
- PostgreSQL, Redis, RabbitMQ, MinIO, Mailpit의 실제 상태와 데이터 흐름을
  확인한다.
- API, 권한, 멱등성, 장애 복구 같은 핵심 동작은 실제 요청과 운영 데이터로
  검증한다.
- 검증 결과와 재현 명령을 계획 문서의 재개 스냅샷에 기록한다.

### 필수 명령

초기 멀티모듈 전환 후 아래 명령을 표준으로 사용한다.

```powershell
.\gradlew.bat clean build
docker compose config
docker compose up -d
docker compose ps
```

## 18. 코딩 규칙

- 패키지는 기능 또는 바운디드 컨텍스트 기준으로 구성한다.
- 도메인 계층에 Spring, JPA, Redis, RabbitMQ 타입을 노출하지 않는다.
- application 계층은 포트 인터페이스에만 의존한다.
- 외부 응답과 사용자 입력은 경계에서 검증한다.
- Controller에서 비즈니스 규칙을 구현하지 않는다.
- 엔티티를 API 응답으로 직접 노출하지 않는다.
- 트랜잭션 경계는 application 유스케이스에 둔다.
- API DTO와 이벤트 DTO는 도메인 객체와 분리한다.

## 19. 작업 경계

### 항상 수행

- 외부 API 응답을 검증한다.
- 소유권과 권한을 API 경계에서 검증한다.
- DB 변경은 Flyway 마이그레이션으로 관리한다.
- 이벤트 Consumer를 멱등하게 구현한다.
- 변경 후 빌드와 관련 실제 동작을 검증한다.

### 먼저 승인 필요

- 확정된 바운디드 컨텍스트 또는 모듈 의존 방향 변경
- 새로운 인프라 구성 요소 도입
- 공개 API의 호환성을 깨는 변경
- 데이터 보존 기간 변경
- 메뉴명 기반 알레르기 추론 도입

### 절대 금지

- 비밀값 commit
- Redis를 핵심 데이터의 유일한 저장소로 사용
- 알레르기 정보 없음 또는 파싱 실패를 안전으로 표시
- Outbox 없이 DB 변경과 이벤트 발행을 이중 쓰기
- 관리자 변경 작업을 감사 로그 없이 실행

## 20. 승인 게이트

구현 시작 전에 다음을 승인해야 한다.

- [ ] Release 1 범위 및 비목표
- [ ] 6개 모듈과 의존 방향
- [ ] 공개 API와 회원 전용 API 분리
- [ ] 인증 및 관리자 보안 정책
- [ ] RabbitMQ, Outbox, MinIO 및 Redis 역할
- [ ] 데이터 모델과 보존 정책
- [ ] 구현 계획
