# Task 2.2 회원가입 및 이메일 인증 요청 스펙

## 범위

- `POST /api/v1/auth/signup`
- `POST /api/v1/auth/email-verifications`
- 신규 회원 저장
- 중복 이메일 방지
- 이메일 인증 토큰 생성, 해시 저장, TTL 적용
- SMTP 발송 및 Mailpit 수신 확인

## 제외 범위

- 이메일 인증 완료
- 로그인
- JWT 및 Refresh Token 쿠키
- 세션 rotation
- 비밀번호 재설정
- CSRF, Origin, rate limit

## 계약

### 회원가입 요청

```http
POST /api/v1/auth/signup
Content-Type: application/json
```

```json
{
  "email": "user@example.com",
  "password": "password"
}
```

- 성공: `201 Created`
- 응답:

```json
{
  "userId": "uuid",
  "emailVerificationStatus": "UNVERIFIED"
}
```

### 이메일 인증 재요청

```http
POST /api/v1/auth/email-verifications
Content-Type: application/json
```

```json
{
  "email": "user@example.com"
}
```

- 성공: `202 Accepted`
- 응답:

```json
{
  "emailVerificationStatus": "UNVERIFIED"
}
```

## 동작

- 이메일은 trim 후 lowercase로 정규화한다.
- 이메일 검색 해시는 정규화 이메일의 SHA-256 lowercase hex로 만든다.
- 이메일은 versioned envelope 형식으로 암호화 저장한다.
- 비밀번호는 BCrypt로 해시한다.
- 일반 회원가입은 항상 `MEMBER`, `ACTIVE`, `UNVERIFIED` 사용자만 생성한다.
- 같은 정규화 이메일이 이미 있으면 새 사용자를 만들지 않고 중복 오류를 반환한다.
- 회원가입 성공 시 인증 토큰을 생성하고 Redis에 해시와 TTL로 저장한다.
- 이메일 인증 재요청은 존재하고 미인증인 계정에 대해서만 새 토큰을 저장하고 메일을 발송한다.
- 인증 토큰 원문은 Redis와 로그에 저장하지 않는다.
- API 응답에는 인증 토큰, 암호화 이메일, 이메일 검색 해시, 비밀번호 해시를 노출하지 않는다.

## Redis key

- key: `email-verification:v1:{userId}`
- value: SHA-256 lowercase hex token hash
- TTL: 기본 30분, `safe-meal.auth.email-verification-token-ttl`

## Mail

- SMTP 설정은 Spring Boot mail 설정을 사용한다.
- 로컬 기본 대상은 Compose Mailpit `localhost:1025`다.
- 제목과 본문은 사용자 친화적인 한글 문구를 사용한다.
- 본문에는 인증 링크 또는 토큰을 포함한다.
- Release 1 로컬 검증에서는 Mailpit API 또는 UI로 수신 여부를 확인한다.

## 오류

- 중복 이메일: `409 CONFLICT`, code `EMAIL_ALREADY_EXISTS`
- 존재하지 않는 이메일 인증 재요청: `404 RESOURCE_NOT_FOUND`
- 이미 인증된 이메일 인증 재요청: `409 CONFLICT`, code `EMAIL_ALREADY_VERIFIED`
- 요청 형식 오류: 기존 `INVALID_REQUEST` 또는 `MALFORMED_REQUEST`
- 내부 오류: 기존 `INTERNAL_SERVER_ERROR`

## 구현 태스크

1. API request/response 계약 추가
2. application 회원가입 유스케이스와 인증 메일 재요청 유스케이스 추가
3. application outbound port 추가: 이메일 암호화, 비밀번호 해시, 인증 토큰 저장, 메일 발송
4. infra 구현 추가: SHA-256 이메일 hash, AES-GCM 이메일 envelope, BCrypt password, Redis token store, SMTP sender
5. infra configuration 추가
6. 실제 Redis, PostgreSQL, Mailpit 흐름 검증
