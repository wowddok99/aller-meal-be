# Task 3.7 공개 조회 Redis 캐시와 중복 호출 방지 명세

## 목표

- 공개 급식 READY 결과를 Redis에서 먼저 조회한다.
- 동시 동일 요청이 같은 `PENDING` 작업을 반복 dispatch하지 않도록 제한한다.
- Redis 장애 시 PostgreSQL 조회와 DB 상태 CAS 기반 비동기 수집이 계속 동작한다.

## 캐시 계약

- key: `public-meal-query:v1:{schoolId}:{rangeStart}:{rangeEnd}`
- value: `PublicMealQueryResult` JSON
- TTL: 10분
- `READY` 결과만 저장한다. `COLLECTING` 결과는 저장하지 않는다.
- Redis miss 또는 오류면 PostgreSQL을 조회한다.
- PostgreSQL에서 READY 결과를 조립하면 Redis 저장을 시도한 뒤 반환한다.

## Dispatch Lock 계약

- key: `public-meal-dispatch:v1:{schoolId}:{mealDate}:{mealType}`
- Redis `SET NX`, TTL 10초
- lock 획득 시에만 `PENDING` 작업을 executor에 dispatch한다.
- Redis 장애 시 lock 획득으로 간주하고 dispatch한다. PostgreSQL 상태 CAS가
  외부 API 호출 전 최종 단일 실행을 보장한다.
- lock TTL 만료 후 남은 `PENDING` 작업은 후속 재조회가 복구 dispatch한다.

## 구현 계획

1. application 공개 조회 cache port를 정의하고 query service에 cache-first와
   dispatch lock 흐름을 추가한다.
2. Spring Data Redis 의존성과 장애 허용 Redis adapter를 추가한다.
3. Redis 정상 cache hit, 동시 요청 dispatch 제한, Redis 중단 fallback을 실제
   API와 Redis·PostgreSQL 상태로 검증한다.
