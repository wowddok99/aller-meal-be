# 계약 타입 독립 파일 구조 리팩터링 스펙

## 1. 목적

API 응답, application 유스케이스 결과, outbound port 입출력 계약을 소유 클래스나
interface의 중첩 타입에서 분리한다.

외부에서 참조 가능한 계약 타입을 독립 파일과 예측 가능한 패키지에 배치하여 다음을
달성한다.

- 타입의 위치와 책임을 이름과 패키지만으로 식별할 수 있다.
- Controller, Service, port interface가 계약 타입의 물리적 소유자가 되는 결합을
  제거한다.
- 후속 API와 유스케이스 추가 시 기존 계약 타입을 안정적으로 확장·재사용할 수 있다.
- 계약 타입 배치 기준을 프로젝트 전체에 일관되게 적용한다.

이번 작업은 구조 리팩터링이다. 런타임 동작과 외부 계약은 변경하지 않는다.

## 2. 현재 문제

현재 외부에서 참조 가능한 계약 타입이 Controller, Service, port interface 내부에
중첩 선언되어 있다.

- API 계약이 `SchoolController.SchoolResponse`처럼 Controller에 종속된다.
- application 호출자가 `MealCollectionService.CollectionResult`처럼 구현 Service를
  통해 결과 타입을 참조한다.
- port 구현체가 `NeisMealClient.RawMealResponse`처럼 port interface 내부 타입을
  참조한다.
- `CompletionResult`처럼 이름만으로 책임을 알기 어려운 타입이 존재한다.
- 새로운 계약 타입을 어디에 배치해야 하는지 명시된 프로젝트 규칙이 없다.

## 3. 아키텍처 결정

### 3.1 중첩 타입 허용 기준

- `private` 구현 helper만 중첩 타입으로 허용한다.
- 외부에서 참조 가능한 `public` 및 package-private class, record, enum은 독립
  파일로 선언한다.
- 계약 타입을 단일 클래스에서만 사용한다는 이유로 중첩 선언하지 않는다.
- 현재 `NeisMealJsonNormalizer.Rows`는 private 구현 helper이므로 유지한다.

### 3.2 패키지 배치 기준

| 계약 종류 | 목표 패키지 |
|---|---|
| API 기능 응답 | `com.allermeal.api.<feature>.response` |
| API 공통 오류 응답 | `com.allermeal.api.error.response` |
| application 유스케이스 결과 | 해당 기능 패키지 `com.allermeal.application.<feature>` |
| outbound port 반환 계약 | `com.allermeal.application.port.out.result` |
| outbound port 입력 계약 | `com.allermeal.application.port.out.command` |
| private 구현 helper | 소유 구현 클래스 내부 |

### 3.3 명명 기준

- 역할을 이름만으로 식별할 수 있는 구체적인 이름을 사용한다.
- API 응답은 `Response`, port 반환 계약은 `Result`, port 입력 계약은 행위 또는
  payload 의미가 드러나는 이름을 사용한다.
- 의미가 약한 `CompletionResult`는 `MealCollectionCompletionResult`로 변경한다.
- 기존에 충분히 구체적인 이름은 유지한다.

### 3.4 강제 방식

- 이번 작업에서는 `AGENTS.md`에 타입 배치 규칙을 문서화한다.
- ArchUnit, Checkstyle, 별도 Gradle source 검사 task는 추가하지 않는다.
- 자동 강제 검증은 필요성이 확인될 경우 별도 태스크로 설계한다.

## 4. 목표 구조

```text
safe-meal-api/src/main/java/com/allermeal/api/
├── allergen/
│   ├── AllergenController.java
│   └── response/
│       └── AllergenResponse.java
├── school/
│   ├── SchoolController.java
│   └── response/
│       ├── SchoolResponse.java
│       └── SchoolSearchResponse.java
└── error/
    ├── ApiErrorController.java
    ├── ApiExceptionHandler.java
    └── response/
        ├── ApiError.java
        └── ApiErrorResponse.java

safe-meal-application/src/main/java/com/allermeal/application/
├── meal/
│   ├── MealCollectionResult.java
│   └── MealCollectionService.java
└── port/out/
    ├── command/
    │   └── RawPayload.java
    └── result/
        ├── MealCollectionCompletionResult.java
        ├── MealSaveResult.java
        ├── RawMealResponse.java
        └── SchoolSearchResult.java
```

## 5. 타입 이동 매핑

| 현재 타입 | 목표 타입 | 목표 파일 |
|---|---|---|
| `AllergenController.AllergenResponse` | `AllergenResponse` | `api/allergen/response/AllergenResponse.java` |
| `SchoolController.SchoolResponse` | `SchoolResponse` | `api/school/response/SchoolResponse.java` |
| `SchoolController.SchoolSearchResponse` | `SchoolSearchResponse` | `api/school/response/SchoolSearchResponse.java` |
| `ApiErrorResponse.ApiError` | `ApiError` | `api/error/response/ApiError.java` |
| 기존 top-level `ApiErrorResponse` | `ApiErrorResponse` | `api/error/response/ApiErrorResponse.java` |
| `MealCollectionService.CollectionResult` | `MealCollectionResult` | `application/meal/MealCollectionResult.java` |
| `MealCollectionPersistence.CompletionResult` | `MealCollectionCompletionResult` | `application/port/out/result/MealCollectionCompletionResult.java` |
| `MealRepository.MealSaveResult` | `MealSaveResult` | `application/port/out/result/MealSaveResult.java` |
| `NeisMealClient.RawMealResponse` | `RawMealResponse` | `application/port/out/result/RawMealResponse.java` |
| `NeisSchoolClient.SchoolSearchResult` | `SchoolSearchResult` | `application/port/out/result/SchoolSearchResult.java` |
| `RawPayloadStorage.RawPayload` | `RawPayload` | `application/port/out/command/RawPayload.java` |
| `NeisMealJsonNormalizer.Rows` | 변경 없음 | private 중첩 helper 유지 |

## 6. 범위

### 포함

- 매핑표에 명시된 계약 타입의 독립 파일 분리
- 목표 패키지로 타입 이동
- `CompletionResult`의 `MealCollectionCompletionResult` 명명 변경
- 기존 참조 import와 생성 코드 갱신
- 타입 내부의 불변식, defensive copy, 변환 메서드 보존
- `AGENTS.md`에 계약 타입 배치 규칙 문서화
- 동작 보존 검증

### 제외

- endpoint 추가·삭제·경로 변경
- 요청 parameter 및 JSON field 이름·타입·중첩 구조 변경
- HTTP status, 오류 code, 사용자 응답 문구 변경
- application port 메서드 의미와 실행 흐름 변경
- 도메인 모델, DB schema, Flyway migration 변경
- NEIS, MinIO, PostgreSQL 처리 흐름 변경
- ArchUnit, Checkstyle, 신규 Gradle 검증 task 추가
- 테스트 코드 작성·수정
- unrelated package 또는 클래스 구조 정리

## 7. 작업 경계

### 항상 수행

- 타입의 record component, compact constructor, defensive copy와 validation을 그대로
  보존한다.
- 타입 이동 후 모든 직접 참조 import를 명시적으로 갱신한다.
- 태스크마다 Java 21 compile 또는 clean build를 수행한다.
- 외부 API 응답 shape는 실제 애플리케이션 응답으로 확인한다.

### 먼저 확인

- 본 스펙에 없는 타입 이동 또는 이름 변경
- endpoint, JSON field, port 메서드 signature의 의미 변경
- 신규 의존성, Gradle plugin, 자동 구조 검사 도입
- 테스트 코드 작성 또는 수정

### 절대 수행하지 않음

- 동작 변경을 구조 리팩터링에 함께 포함하지 않는다.
- 기존 public 계약을 삭제하거나 의미를 변경하지 않는다.
- private 구현 helper를 재사용 가능 계약 타입으로 승격하지 않는다.
- DB migration과 외부 연동 설정을 변경하지 않는다.

## 8. 동작 보존 계약

리팩터링 전후 다음 관찰 가능한 동작은 동일해야 한다.

### API 계약

- `GET /api/v1/allergens`의 endpoint와 배열 응답 구조를 유지한다.
- `GET /api/v1/public/schools`의 endpoint, query parameter, pagination field와 학교
  field를 유지한다.
- 모든 오류 응답은 기존 `{ "error": { ... } }` JSON 구조를 유지한다.
- 오류 응답의 `code`, `message`, `details`, `traceId` field를 유지한다.
- 기존 HTTP status와 오류 code 매핑을 유지한다.

### Application 및 port 계약

- port 메서드 parameter와 반환 데이터 의미를 유지한다.
- 독립 타입으로 이동한 record의 불변식과 defensive copy를 유지한다.
- Meal 수집 성공·실패, 저장, 정규화, CircuitBreaker 결과 기록 흐름을 유지한다.
- 학교 검색 결과 저장과 전체 건수 반환 흐름을 유지한다.

### Infra 및 데이터 계약

- SQL, transaction 경계, DB schema를 변경하지 않는다.
- NEIS 요청·응답 처리와 MinIO 원본 저장 동작을 변경하지 않는다.
- private 구현 helper `Rows`는 중첩 타입으로 유지한다.

## 9. 구현 태스크

각 태스크는 순서대로 수행한다. 한 번에 하나의 태스크만 구현한다.

### Task 1. API 알레르기·학교 응답 타입 분리

**작업**

- 알레르기와 학교 API 응답 record를 각 기능의 `response` 패키지로 분리한다.
- `SchoolResponse.from(School)` 변환 계약을 독립 타입에서 유지한다.
- Controller는 endpoint 처리와 응답 조립만 담당하도록 갱신한다.

**Acceptance**

- `AllergenController`, `SchoolController` 내부에 외부 참조 가능한 중첩 타입이 없다.
- 기존 endpoint와 JSON field가 변경되지 않는다.
- 응답 타입은 목표 패키지에서 독립 파일로 선언된다.

**Verify**

- Java 21 `.\gradlew.bat :safe-meal-api:compileJava --no-daemon`
- API 실제 기동 후 `/api/v1/allergens`, `/api/v1/public/schools` 응답 shape 확인

**예상 파일**

- `safe-meal-api/.../allergen/AllergenController.java`
- `safe-meal-api/.../allergen/response/AllergenResponse.java`
- `safe-meal-api/.../school/SchoolController.java`
- `safe-meal-api/.../school/response/SchoolResponse.java`
- `safe-meal-api/.../school/response/SchoolSearchResponse.java`

### Task 2. API 오류 응답 타입 분리

**작업**

- `ApiError`를 독립 파일로 분리한다.
- `ApiErrorResponse`를 `api.error.response` 패키지로 이동한다.
- 오류 Controller와 handler의 참조를 갱신한다.

**Acceptance**

- API 오류 응답 패키지에 중첩 타입이 없다.
- 기존 오류 JSON 구조, HTTP status, 오류 code, 사용자 메시지가 유지된다.

**Verify**

- Java 21 `.\gradlew.bat :safe-meal-api:compileJava --no-daemon`
- API 실제 기동 후 기존 404와 오류 응답 shape 확인

**예상 파일**

- `safe-meal-api/.../error/ApiErrorController.java`
- `safe-meal-api/.../error/ApiExceptionHandler.java`
- `safe-meal-api/.../error/response/ApiError.java`
- `safe-meal-api/.../error/response/ApiErrorResponse.java`

### Task 3. 학교 검색 port 결과 타입 분리

**작업**

- `SchoolSearchResult`를 `application.port.out.result` 패키지로 분리한다.
- port, application service, API Controller, infra client 참조를 갱신한다.

**Acceptance**

- `NeisSchoolClient` 내부에 중첩 결과 타입이 없다.
- 학교 목록 defensive copy와 전체 건수 불변식이 유지된다.
- 학교 검색과 저장 흐름이 변경되지 않는다.

**Verify**

- Java 21 `.\gradlew.bat clean build --no-daemon`
- API 실제 기동 후 실제 학교 검색 응답 shape 확인

**예상 파일**

- `safe-meal-application/.../port/out/NeisSchoolClient.java`
- `safe-meal-application/.../port/out/result/SchoolSearchResult.java`
- `safe-meal-application/.../school/SchoolSearchService.java`
- `safe-meal-api/.../school/SchoolController.java`
- `safe-meal-infra/.../school/NeisHttpSchoolClient.java`

### Task 4. 원본 payload command 타입 분리

**작업**

- `RawPayload`를 port command 패키지로 분리한다.
- port, application service, MinIO adapter 참조를 갱신한다.

**Acceptance**

- `RawPayloadStorage` 내부에 중첩 계약 타입이 없다.
- `RawPayload` byte array defensive copy와 기존 validation을 유지한다.
- MinIO 원본 저장 흐름이 변경되지 않는다.

**Verify**

- Java 21 `.\gradlew.bat clean build --no-daemon`

**예상 파일**

- `safe-meal-application/.../port/out/RawPayloadStorage.java`
- `safe-meal-application/.../port/out/command/RawPayload.java`
- `safe-meal-application/.../meal/MealCollectionService.java`
- `safe-meal-infra/.../raw/MinioRawPayloadStorage.java`

### Task 5. NEIS 급식 응답 result 타입 분리

**작업**

- `RawMealResponse`를 port result 패키지로 분리한다.
- port, application service, NEIS HTTP client 참조를 갱신한다.

**Acceptance**

- `NeisMealClient` 내부에 중첩 계약 타입이 없다.
- `RawMealResponse` byte array defensive copy와 기존 validation을 유지한다.
- NEIS fetch와 수집 service 흐름이 변경되지 않는다.

**Verify**

- Java 21 `.\gradlew.bat clean build --no-daemon`
- 기존 실제 NEIS 수집 진입점이 동일 설정으로 기동 가능한지 확인

**예상 파일**

- `safe-meal-application/.../port/out/NeisMealClient.java`
- `safe-meal-application/.../port/out/result/RawMealResponse.java`
- `safe-meal-application/.../meal/MealCollectionService.java`
- `safe-meal-infra/.../meal/NeisHttpMealClient.java`

### Task 6. Meal 저장 result 타입 분리

**작업**

- `MealSaveResult`를 port result 패키지로 분리한다.
- repository와 직접 참조하는 persistence adapter를 갱신한다.

**Acceptance**

- `MealRepository` 내부에 중첩 결과 타입이 없다.
- 기존 저장 결과 의미와 null 불변식을 유지한다.
- Meal 저장 및 조회 동작이 변경되지 않는다.

**Verify**

- Java 21 `.\gradlew.bat clean build --no-daemon`

**예상 파일**

- `safe-meal-application/.../port/out/MealRepository.java`
- `safe-meal-application/.../port/out/result/MealSaveResult.java`
- `safe-meal-infra/.../meal/JdbcMealRepository.java`
- `safe-meal-infra/.../meal/TransactionalMealCollectionPersistence.java`

### Task 7. Meal 수집 완료 result 타입 분리

**작업**

- `MealCollectionCompletionResult`를 port result 패키지로 분리한다.
- `CompletionResult`를 `MealCollectionCompletionResult`로 변경한다.
- port, service와 infra persistence 참조를 갱신한다.

**Acceptance**

- `MealCollectionPersistence` 내부에 중첩 결과 타입이 없다.
- 결과 목록 defensive copy와 기존 저장 결과 의미를 유지한다.
- Meal 수집 완료 transaction과 CollectionJob 상태 전이가 변경되지 않는다.

**Verify**

- Java 21 `.\gradlew.bat clean build --no-daemon`
- 기존 batch run-once 진입점이 동일 설정으로 기동 가능한지 확인

**예상 파일**

- `safe-meal-application/.../meal/MealCollectionService.java`
- `safe-meal-application/.../port/out/MealCollectionPersistence.java`
- `safe-meal-application/.../port/out/result/MealCollectionCompletionResult.java`
- `safe-meal-infra/.../meal/TransactionalMealCollectionPersistence.java`

### Task 8. Meal 수집 유스케이스 result 타입 분리

**작업**

- `MealCollectionResult`를 application meal 패키지의 독립 파일로 분리한다.
- service와 entrypoint 반환 타입 참조를 갱신한다.

**Acceptance**

- `MealCollectionService` 내부에 외부 참조 가능한 중첩 결과 타입이 없다.
- 결과 목록 defensive copy와 유스케이스 반환 의미를 유지한다.
- Meal 수집 실행 흐름이 변경되지 않는다.

**Verify**

- Java 21 `.\gradlew.bat clean build --no-daemon`
- 기존 batch run-once 진입점이 동일 설정으로 기동 가능한지 확인

**예상 파일**

- `safe-meal-application/.../meal/MealCollectionResult.java`
- `safe-meal-application/.../meal/MealCollectionService.java`
- `safe-meal-application/.../meal/MealCollectionEntrypoint.java`

### Task 9. 프로젝트 규칙 문서화 및 최종 검증

**작업**

- `AGENTS.md`에 계약 타입 배치와 중첩 타입 허용 규칙을 추가한다.
- 전체 저장소에서 private이 아닌 중첩 타입 잔존 여부를 검토한다.
- 전체 동작 보존 검증을 수행한다.

**Acceptance**

- `AGENTS.md`에 본 스펙의 타입 배치 규칙이 기록된다.
- `NeisMealJsonNormalizer.Rows` 외 대상 중첩 타입이 모두 독립 파일로 분리된다.
- 구현 코드의 동작 변경이 없다.

**Verify**

- `rg`로 private이 아닌 중첩 class·record·enum 잔존 여부 확인
- Java 21 `.\gradlew.bat clean build --no-daemon`
- `docker compose --env-file .env.example config --quiet`
- API 실제 기동 및 기존 공개 endpoint 응답 shape 확인
- `git diff --check`

## 10. 검증 명령

```powershell
$env:JAVA_HOME='C:\Program Files\Eclipse Adoptium\jdk-21.0.8.9-hotspot'
$env:Path="$env:JAVA_HOME\bin;$env:Path"
.\gradlew.bat clean build --no-daemon
docker compose --env-file .env.example config --quiet
git diff --check
```

private 구현 helper를 제외한 중첩 타입 잔존 여부는 `rg` 검색 결과를 사람이
검토한다. 자동 source 검사 task는 추가하지 않는다.

## 11. 위험 및 완화

| 위험 | 영향 | 완화 |
|---|---|---|
| 타입 이동 중 JSON field 또는 중첩 구조 변경 | 기존 클라이언트 계약 파손 | record component 이름과 응답 조립 순서를 유지하고 실제 응답 shape 확인 |
| import 갱신 누락 | 모듈 compile 실패 | 태스크별 compile 후 최종 clean build 수행 |
| 이름 변경 중 의미 또는 불변식 손실 | 저장·수집 동작 회귀 | record compact constructor와 defensive copy를 그대로 이동 |
| 구조 리팩터링에 unrelated 정리 혼입 | 리뷰 범위 확대 | 매핑표 타입과 직접 참조 파일만 수정 |
| 규칙이 문서에만 존재해 재발 | 후속 중첩 계약 타입 생성 | 리뷰 규칙으로 적용하고 자동 강제는 별도 태스크로 평가 |

## 12. 승인 게이트

- 사용자가 본 스펙을 승인하기 전에는 구현을 시작하지 않는다.
- 승인 후 Task 1부터 순서대로 한 태스크씩 구현한다.
- 각 태스크의 Acceptance와 Verify가 충족된 후 다음 태스크를 시작한다.
- 범위 또는 아키텍처 결정이 변경되면 구현보다 스펙을 먼저 갱신한다.

## 13. 완료 조건

- 매핑표의 모든 외부 참조 가능 중첩 계약 타입이 독립 파일로 분리된다.
- private 구현 helper만 중첩 타입으로 남는다.
- 목표 패키지 및 명명 기준이 코드와 `AGENTS.md`에 반영된다.
- endpoint, JSON 계약, 오류 계약, port 동작, DB schema와 외부 연동 흐름이
  변경되지 않는다.
- Java 21 clean build와 실제 API 응답 shape 검증이 성공한다.
- 테스트 코드는 작성하거나 수정하지 않는다.
- 자동 강제 검증 도구는 추가하지 않는다.
