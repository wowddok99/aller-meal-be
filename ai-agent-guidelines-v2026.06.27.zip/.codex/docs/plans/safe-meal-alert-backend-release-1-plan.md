# SafeMeal Alert Backend Release 1 구현 계획

## 재개 스냅샷

- 마지막 갱신: 2026-06-27 12:01 KST
- 현재 태스크: `Task 5.2 알림 대상 생성 Scheduler` (`미착수`)
- 완료된 작업:
  - Task 0.1 멀티모듈 Gradle 골격
  - Task 0.2 공통 품질 및 테스트 설정
  - Task 0.3 Docker Compose 기반 인프라
  - Checkpoint 0
  - Task 1.1 공통 오류 및 식별자 계약
  - Task 1.2 Flyway 및 기본 감사 필드
  - Task 1.3 Outbox 도메인 및 저장 포트
  - Task 1.4 RabbitMQ Outbox Publisher
  - Task 1.5 Consumer 멱등성 및 DLQ 기반
  - Checkpoint 1
  - Task 2.1 User 도메인과 영속성
  - Task 2.2 회원가입 및 이메일 인증 요청
  - Task 2.3 이메일 인증 완료 및 로그인
  - Task 2.4 Refresh rotation, 로그아웃, 재사용 탐지
  - Task 2.5 비밀번호 재설정
  - Task 2.6 로그인 제한, Origin·CSRF 및 인증 rate limit
  - Checkpoint 2
  - Task 3.1 Allergen 기준 데이터
  - Task 3.2 School 도메인 및 NEIS 학교 검색
  - Task 3.3 MinIO 원본 객체 저장 포트와 어댑터
  - Task 3.4 Meal 및 CollectionJob 도메인
  - Task 3.5 NEIS 급식 수집 및 정규화
  - Task 3.6 공개 학교·급식 조회 API
  - Task 3.7 공개 조회 Redis 캐시와 중복 호출 방지
  - Checkpoint 3
  - Task 4.1 ChildProfile 소유권 모델
  - Task 4.2 자녀 알레르기 관리
  - Task 4.3 자녀별 알림 설정
  - Task 4.4 등록 학교 수집 구독
  - Task 4.5 NEIS 알레르기 번호 라벨링 Worker
  - Task 4.6 자녀별 위험도 계산
  - Task 4.7 개인화 오늘·주간 급식 API
  - Checkpoint 4
  - Task 5.1 등록 학교 수집 Scheduler
- 미착수:
  - Task 5.2 이후 자동 수집과 이메일 알림 태스크
- 현재 변경:
  - Meal, MealItem, CollectionJob 도메인과 PostgreSQL 멱등 저장 기반 구현
  - reviewer findings에 따라 CollectionJob 상태 CAS, Meal source CAS, labeling·응답시간
    불변식, 메뉴 allergen 관계 삭제, 외부 문자열 길이 제한 보강
  - pr-finalizer 동작 보존 단순화 및 Java 21 최종 clean build 완료
  - 실제 NEIS 급식 원본 fetch, MinIO 보존, strict 정규화, Meal 저장, CollectionJob
    성공·실패 및 응답시간 기록 구현
  - Resilience4j core Retry·지수 backoff·CircuitBreaker 적용
  - Task 3.5 reviewer findings 수정: 원자 완료 트랜잭션, 무자료 tombstone CAS,
    RUNNING lease 회수, 응답시간·전체 수집시간 분리, strict 검증·payload 제한,
    opt-in batch run-once 진입점
  - 실패 job raw object 연결, 실패 문자열 정규화, 408·429 Retry-After+jitter,
    MinIO bucket 생성 경쟁 보강
  - Task 3.5 cavecrew major 수정: 동일 hash 최신 수신 watermark 전진 및
    fetch+validation 단일 CircuitBreaker 결과 기록
  - Task 3.5 재리뷰 수정: raw 저장 실패 시 외부 호출 성공으로 permission 명시 반환,
    내부 저장 실패 breaker 통계 분리, normalizer `head[0]` strict 검증
  - Task 3.5 후속 리뷰 수정: `INFO-200`와 급식 배열이 함께 존재하는 충돌 payload를
    `NEIS_INVALID_RESPONSE`로 거부해 잘못된 무자료 tombstone 적용 방지
  - 계약 타입 독립 파일 구조 리팩터링 완료: API 응답, application 유스케이스 결과,
    outbound port command/result를 지정 패키지의 독립 파일로 분리
  - private 구현 helper만 중첩 타입으로 허용하는 프로젝트 규칙 문서화
  - Task 3.6 공개 학교 단건·일간·주간 급식 조회와 멱등 비동기 수집 요청 구현
  - Task 3.7 공개 READY 조회 Redis 캐시와 dispatch lock, Redis 장애 fallback 구현
  - Task 2.2 회원가입 API, 이메일 인증 재요청 API, Redis 인증 토큰 hash+TTL 저장,
    Mailpit SMTP 인증 메일 발송 구현
  - 이메일 암호화 key는 환경변수로 요구하고 `.env.example`에 로컬 값을 문서화
  - Task 2.3 이메일 인증 완료 API, 로그인 API, Access JWT, Refresh Token Redis 저장,
    HttpOnly 쿠키 발급, 주요 `/api/v1/**` 인증 필터 구현
  - cavecrew-reviewer major 수정: 이메일 인증 토큰 consume을 Redis Lua script로
    원자화하고 confirm 유스케이스가 consume 결과만 신뢰하도록 변경
  - Task 2.4 Refresh Token Redis session chain을 `active`, `used`, `family`,
    `revoked-family` key로 확장하고 Lua 기반 rotation·재사용 탐지·logout revoke 구현
  - `POST /api/v1/auth/refresh`와 `POST /api/v1/auth/logout` API 및 쿠키 재발급·삭제 구현
  - Task 2.5 비밀번호 재설정 요청·확인 API, hash+TTL+단회 Redis token, Mailpit SMTP 메일,
    비밀번호 변경 후 Refresh Token 전체 폐기 구현
  - 기존 Refresh Token도 비밀번호 재설정 뒤 갱신되지 않도록 사용자별 폐기 시각 적용
  - Task 4.2 자녀 알레르기 교체 API, PostgreSQL 관계 테이블, owner-scoped 트랜잭션 잠금 구현
  - Task 4.3 자녀별 이메일 알림 활성화·알림 시각·`Asia/Seoul` 시간대 설정 API 및 PostgreSQL 저장 구현
  - Task 4.4 학교별 단일 수집 구독, 등록 자녀 수 집계, 마지막 자녀 해제 뒤 30일 유예 구현
  - 첫 자녀 등록 시 `Asia/Seoul` 기준 이번 주 21개 `CollectionJob`을 트랜잭션으로 요청하고 commit 뒤 비동기 dispatch
  - Task 4.5 NEIS 번호 기반 메뉴 알레르기 parser, `MealCollected` Worker 소비,
    `meal_item_allergens` 저장, `MealLabeled` Outbox 생성, 공개 급식 Redis cache
    삭제 구현
  - Task 4.6 자녀 알레르기와 메뉴 allergen code 교집합 계산, `UNKNOWN`·`LABELING_FAILED`
    비안전 위험도, 급식 변경 감지용 `riskVersion` 도메인 계약 구현
  - Task 4.7 인증 자녀의 오늘·날짜·주간 개인화 급식 API, owner-scoped 자녀 조회,
    메뉴별 위험도 응답, 미인증·교차 소유권 차단 구현
  - Checkpoint 4 실제 API 기동 후 회원 1명이 자녀 2명을 등록하고 각 자녀의 개인화
    위험도를 조회하는 E2E 검증 완료
  - Task 5.1 활성 학교 수집 구독 조회, `Asia/Seoul` 기준 대상 날짜별 CollectionJob 멱등 생성,
    기존 수집 완료 target skip, 신규 작업만 비동기 dispatch하는 Batch Scheduler 구현
  - Batch 애플리케이션 스캔 범위를 수집 Scheduler 필요 패키지와 설정으로 제한해 Auth 메일 Bean 없이 기동 가능하도록 정리
- 실행 순서 결정:
  - Task 3.1~3.3 기반과 작업 컨텍스트를 이어 공개 급식 조회 수직 흐름을 먼저 완성한다.
  - Task 3.4~3.7과 Checkpoint 3을 순서대로 완료한 직후 Task 2.2로 복귀한다.
  - 이후 Task 2.2~2.6과 Checkpoint 2를 순서대로 완료하고 Phase 4를 시작한다.
  - Task 4.1은 Task 2.3과 Task 3.2에 의존하므로 Checkpoint 2 전에는 Phase 4를 시작하지 않는다.
- 다음 행동:
  - Task 5.2 알림 대상 생성 Scheduler 범위와 시간 경계·중복 실행 검증 기준을 확정한다.
- 최근 검증:
  - API 실제 기동 및 Flyway V1~V7 적용: 성공
  - 알레르기 seed 19건과 `/api/v1/allergens` 조회: 성공
  - 실제 NEIS 학교 검색, PostgreSQL 저장 및 반복 upsert 멱등성: 성공
  - `MinioRawPayloadStorage.store()` 실제 호출, 객체·SHA-256·만료 metadata 저장: 성공
  - Java 21 `.\gradlew.bat clean build --no-daemon`: 성공
  - Flyway V8 적용 및 실제 PostgreSQL 급식 upsert·메뉴 교체·활성 CollectionJob
    중복 방지·완료 후 재생성 assertion: 성공
  - Flyway V9 적용 및 실제 PostgreSQL CollectionJob 상태 CAS·영향 행, Meal stale·동일
    source version 거부, 최신 source 갱신, 메뉴 allergen 관계 삭제, DB CHECK assertion: 성공
  - Java 21 `jshell` Meal·MealItem·CollectionJob 도메인 불변식 assertion: 성공
  - Java 21 `sh ./gradlew clean build --no-daemon`: 성공
  - API 실제 기동 및 Flyway V14 적용, 자녀 알림 설정 `PUT 200`·`GET 200`·`UTC` 거부 `400`: 성공
  - Java 21 `.\gradlew.bat :safe-meal-batch:bootJar --no-daemon`: 성공
  - Compose health 확인: PostgreSQL, Redis, RabbitMQ, MinIO, Mailpit healthy
  - Batch 실제 기동 및 등록 학교 수집 Scheduler Fixture 검증: 활성 구독 target 6건 중 기존 LUNCH 1건 skip, 신규 5건 dispatch, 검증 Fixture 학교 BREAKFAST·DINNER 실패 작업 `NEIS_IO_ERROR` 기록 성공
  - 검증 Fixture 및 검증 중 생성된 실패 CollectionJob 5건 정리: 성공
  - Java 21 `.\gradlew.bat build --no-daemon`: 성공
  - `git diff --check`: 성공
  - 실제 NEIS 서울미동초등학교 2026-06-12 중식 수집: `SUCCEEDED`, 응답시간
    `577ms`, Meal 1건·MealItem 7건·MinIO 원본 1653 bytes 저장 성공
  - 실제 NEIS 무자료 2099-01-01 중식: 원본 저장 후 Meal 0건·CollectionJob
    `SUCCEEDED`, 응답시간 `362ms`
  - 연결 거부 endpoint: 2회 retry와 300ms backoff 후 `FAILED,347ms,NEIS_IO_ERROR`;
    다음 호출은 열린 CircuitBreaker로 `FAILED,1ms,NEIS_CIRCUIT_OPEN`
  - 실제 PostgreSQL 원자 rollback, 무자료 tombstone stale 방지, RUNNING lease 회수:
    성공
  - 로컬 HTTP mock 429 Retry-After+jitter, payload 초과 중단, HTTP 200 validation
    실패 CircuitBreaker 기록, strict 빈 성공/count 검증: 성공
  - 실제 batch run-once 진입점 정상 수집·정규화·CollectionJob 성공: 성공
  - 실제 HTTP 200 비정상 JSON: `FAILED/NEIS_INVALID_RESPONSE`, NEIS 응답 `45ms`,
    전체 수집 `183ms`, 실패 job raw object·MinIO 원본 연결 성공
  - 실제 PostgreSQL `A(t1 tombstone) -> A(t3 동일 hash) -> B(t2 stale meal)`:
    최종 `A/t3/has_meal=false` 유지 및 검증 데이터 정리 성공
  - 같은 JVM 실제 invalid HTTP 200 5회 및 `IllegalArgumentException` 5회:
    각각 다음 호출 `NEIS_CIRCUIT_OPEN`
  - raw 저장 실패 service 흐름: 외부 성공 callback 1회, validation callback 0회
  - 실제 CircuitBreaker OPEN→HALF_OPEN 후 내부 실패 반환 계약 12회:
    permission 누수 없이 다음 외부 호출 허용
  - `head[0]=null` 및 비객체 응답: 각각 `NEIS_INVALID_RESPONSE`
  - `INFO-200`와 급식 배열 충돌 응답: `NEIS_INVALID_RESPONSE`
  - Flyway V9~V11 적용·검증 및 Java 21 `.\gradlew.bat clean build --no-daemon`: 성공
  - Task 3.5 후속 리뷰 후 Java 21 `.\gradlew.bat clean build --no-daemon`: 성공
  - 계약 타입 구조 리팩터링 후 Java 21 `.\gradlew.bat clean build --no-daemon`: 성공
  - private이 아닌 중첩 계약 타입과 이전 중첩 타입 참조: 0건
  - API 응답 record component reflection 확인: 기존 JSON field 계약 유지
  - `docker compose --env-file .env.example config --quiet`: 성공
  - 계약 타입 구조 리팩터링 후 실제 API 기동 및 Flyway 11개 migration 검증: 성공
  - 실제 `/api/v1/allergens`, `/api/v1/public/schools` 응답 JSON field 계약 유지:
    성공
  - 실제 잘못된 학교 검색 요청의 `ApiErrorResponse` JSON field 계약 유지: 성공
  - Task 3.5 실제 흐름 검증 데이터와 MinIO 객체 정리: 성공
  - 검증 시점 `docker compose --env-file .env.example ps`: 5개 서비스 모두 `healthy`
  - Task 3.6 Java 21 clean build: 성공
  - 공개 학교 단건 `200`, 미존재 학교 `404 RESOURCE_NOT_FOUND`: 성공
  - 공개 일간 급식 최초 `202 + Retry-After: 3`, 재조회 `200 READY`: 성공
  - 공개 주간 급식 월~일 범위 최초 `202`, 재조회 `200 READY`: 성공
  - 동일 학교·날짜 동시 5요청 후 meal type별 CollectionJob 1건: 성공
  - Task 3.7 Redis READY cache hit 상태에서 PostgreSQL 중단 후 공개 조회 `200`: 성공
  - Redis 중단 시 PostgreSQL READY fallback `200` 0.22초, 미확인 target `202`
    0.03초: 성공
  - 동시 동일 요청 5건에서 Redis dispatch lock 3개와 meal type별 CollectionJob
    1건: 성공
  - Checkpoint 3 실제 API 기동 및 Flyway 11개 migration 검증: 성공
  - Checkpoint 3 비회원 학교 검색과 학교 단건 조회: 성공
  - Checkpoint 3 일간 급식 조회 `200 READY`, Meal 1건·MealItem 7건 확인: 성공
  - Checkpoint 3 주간 급식 조회 `200 READY`, 월~일 범위 Meal 5건 확인: 성공
  - Checkpoint 3 `NEIS_BASE_URL=http://127.0.0.1:9` 및 Redis public meal key 삭제 후
    PostgreSQL 저장 데이터 fallback `200 READY`: 성공
  - Checkpoint 3 PostgreSQL 정규화 데이터와 MinIO 원본 객체 metadata SHA-256 확인:
    성공
  - Task 2.2 Java 21 `sh ./gradlew :safe-meal-api:build --no-daemon`: 성공
  - Task 2.2 실제 API 기동 및 Flyway 11개 migration 검증: 성공
  - Task 2.2 `POST /api/v1/auth/signup`: `201`, `UNVERIFIED` 사용자 생성,
    API 응답에 token/hash/password/encrypted email 미노출: 성공
  - Task 2.2 중복 회원가입: `409 EMAIL_ALREADY_EXISTS`: 성공
  - Task 2.2 `POST /api/v1/auth/email-verifications`: `202`, Redis
    `email-verification:v1:{userId}` TTL 1800초 및 SHA-256 hash 저장: 성공
  - Task 2.2 Mailpit 인증 메일 수신 2건 확인: 성공
  - Task 2.2 `spring-tx` dependencyInsight: Boot 관리 버전 `7.0.7` 선택 확인
  - Task 2.2 Java 21 `sh ./gradlew build --no-daemon`: 성공
  - Task 2.3 Java 21 `sh ./gradlew :safe-meal-api:build --no-daemon`: 성공
  - Task 2.3 실제 API 기동 및 Flyway 11개 migration 검증: 성공
  - Task 2.3 `POST /api/v1/auth/signup`: `201`, `UNVERIFIED` 사용자 생성: 성공
  - Task 4.2 Flyway V13 적용, 실제 인증 API 알레르기 교체·중복 제거·빈 목록 해제,
    유효하지 않은 code `400`, 교차 소유권 `404`, 동시 교체 직렬화: 성공
  - Task 4.2 Java 21 `sh ./gradlew clean build --no-daemon`: 성공
  - Task 2.3 미인증 사용자 `POST /api/v1/auth/login`: `403 EMAIL_NOT_VERIFIED`: 성공
  - Task 2.3 Mailpit 인증 메일 token 추출 후 `GET /api/v1/auth/email-verifications/confirm`:
    `200 VERIFIED`: 성공
  - Task 2.3 동일 인증 token 재사용: `400 INVALID_EMAIL_VERIFICATION_TOKEN`: 성공
  - Task 2.3 인증 사용자 `POST /api/v1/auth/login`: `200`, `access_token` 및
    `refresh_token` HttpOnly 쿠키 발급, refresh token Redis 저장: 성공
  - Task 2.3 미로그인 보호 경로 `/api/v1/me`: `401 UNAUTHORIZED`, 로그인 쿠키 포함 시
    인증 필터 통과 후 라우팅 `404 RESOURCE_NOT_FOUND`: 성공
  - Task 2.3 cavecrew-reviewer major 수정 후 Java 21 `sh ./gradlew build --no-daemon`:
    성공
  - Task 2.4 Java 21 `sh ./gradlew :safe-meal-api:build --no-daemon`: 성공
  - Task 2.4 실제 API 기동 및 Flyway 11개 migration 검증: 성공
  - Task 2.4 인증 사용자 `POST /api/v1/auth/refresh`: `200`, 새 Refresh Token 발급 및
    기존 token `used` 전환 확인: 성공
  - Task 2.4 폐기된 Refresh Token 재사용: `401 UNAUTHORIZED`, session chain active 제거 및
    `revoked-family` 기록 확인: 성공
  - Task 2.4 재사용 탐지 후 직전에 발급된 Refresh Token 사용: `401 UNAUTHORIZED`: 성공
  - Task 2.4 `POST /api/v1/auth/logout`: `204`, `access_token`·`refresh_token` 쿠키
    `Max-Age=0` 삭제와 Redis active/family 제거 확인: 성공
  - Task 2.4 검증 후 Redis `refresh-token:v2:*` key 정리: 완료
  - Task 2.4 Java 21 `sh ./gradlew build --no-daemon`: 성공
  - Task 2.5 Java 21 `./gradlew.bat :safe-meal-api:build --no-daemon`: 성공
  - Task 2.5 Java 21 `./gradlew.bat build --no-daemon`: 성공
  - Task 2.5 실제 API 기동 및 Flyway 11개 migration 검증: 성공
  - Task 2.5 `POST /api/v1/auth/password-resets`: 인증·미존재 이메일 모두 `202`: 성공
  - Task 2.5 Mailpit 재설정 메일 token 추출 후 확인: `204`, 기존 비밀번호 로그인 `401`,
    새 비밀번호 로그인 `200`: 성공
  - Task 2.5 기존 Refresh Token 1개·동시 2개 모두 재설정 후 `/refresh` `401`: 성공
  - Task 2.5 재설정 token 재사용: `400 INVALID_PASSWORD_RESET_TOKEN`: 성공
  - Task 2.5 공개 경로 누락 수정 후 Java 21 `./gradlew.bat build --no-daemon`: 성공
  - Task 2.6 Java 21 `./gradlew.bat build --no-daemon`: 성공
  - Task 2.6 실제 Redis 로그인 실패 6회: 마지막 요청 `429 LOGIN_TEMPORARILY_LOCKED`: 성공
  - Task 2.6 cookie 인증 변경 요청 CSRF 누락: `403 CSRF_VALIDATION_FAILED`: 성공
  - Task 2.6 인증 API rate limit 21회: 마지막 요청 `429 AUTH_RATE_LIMITED`: 성공
  - Task 2.6 전체 diff reviewer finding 수정 후 Java 21 `./gradlew.bat build --no-daemon`: 성공
  - Task 2.6 cavecrew-reviewer: `No issues.`
  - Checkpoint 2 Compose 5개 서비스 health 및 API 실제 기동: 성공
  - Checkpoint 2 회원가입 `201`, 이메일 인증 `200`, login·refresh `200`, logout `204`,
    logout 후 refresh `401`, 비밀번호 재설정 `204`, 기존 비밀번호 `401`, 신규 비밀번호 login `200`: 성공
  - Checkpoint 2 login·refresh 응답 본문에 `accessToken`·`refreshToken` 없음 및
    `access_token`·`refresh_token` HttpOnly cookie 발급: 성공
  - Task 4.4 Flyway V15 적용 및 실제 인증 API 자녀 등록: 첫 등록과 동일 학교 두 번째 등록 뒤
    구독 `registered_child_count=2`, `grace_ends_at=null`, 이번 주 CollectionJob 21건: 성공
  - Task 4.4 마지막 자녀 삭제 뒤 구독 `registered_child_count=0`, `grace_ends_at` 30일 이내: 성공
  - Task 4.4 Java 21 `sh ./gradlew build --no-daemon`: 성공
  - Task 4.5 Java 21 `.\gradlew.bat build --no-daemon`: 성공
  - Task 4.5 Java 21 `jshell` NEIS 알레르기 parser smoke:
    번호 suffix `LABELED`, suffix 없음 `UNKNOWN`, 번호 없는 suffix `UNKNOWN`, malformed 번호 suffix
    `LABELING_FAILED`: 성공
  - Task 4.5 `docker compose --env-file .env.example config --quiet`: 성공
  - Task 4.5 `git diff --check`: 성공
  - Task 4.5 `docker compose --env-file .env.example ps`: 실패 - Docker daemon pipe 없음
  - Task 4.5 Docker daemon 기동 후 Compose 5개 서비스 health 확인: 성공
  - Task 4.5 Worker 실제 기동 및 Flyway V1~V15 검증: 성공
  - Task 4.5 실제 RabbitMQ `MealCollected` publish routed true, Worker 소비,
    메뉴 상태 `LABELED`·`UNKNOWN`·`LABELING_FAILED`, allergen 관계 4건,
    `MealLabeled` Outbox 1건 생성: 성공
  - Task 4.5 동일 `message_id` 재전송 후 `MealLabeled` Outbox 1건,
    consumed 1건, allergen 관계 4건 유지: 성공
  - Task 4.5 검증 데이터와 Worker 프로세스 정리: 완료
  - Task 4.6 Java 21 `.\gradlew.bat build --no-daemon`: 성공
  - Task 4.6 Java 21 `jshell` 도메인 위험도 smoke: 교집합 `RISKY`, `UNKNOWN` 비안전,
    `LABELING_FAILED` 비안전, 급식 변경 시 `riskVersion` 변경: 성공
  - Task 4.6 `git diff --check`: 성공
  - Task 4.7 Java 21 `.\gradlew.bat :safe-meal-api:compileJava --no-daemon`: 성공
  - Task 4.7 Java 21 `.\gradlew.bat build --no-daemon`: 성공
  - Task 4.7 Docker daemon 기동 후 Compose 5개 서비스 health 확인: 성공
  - Task 4.7 API 실제 기동 및 Flyway V1~V15 검증: 성공
  - Task 4.7 인증된 자녀 날짜 급식 `GET /api/v1/children/{childId}/meals/2026-06-27`:
    `200 READY`, meal 1건, 전체 위험도 `RISKY`, item 위험도 `RISKY`·`UNKNOWN`·`LABELING_FAILED`,
    matched allergen `[2]`, `riskVersion` 64자: 성공
  - Task 4.7 인증된 자녀 주간 급식 `GET /api/v1/children/{childId}/meals/weekly?date=2026-06-27`:
    `200 READY`, range `2026-06-22`~`2026-06-28`, meal 1건: 성공
  - Task 4.7 인증된 자녀 오늘 급식 `GET /api/v1/children/{childId}/meals/today`:
    `200 READY`, `Asia/Seoul` 기준 `2026-06-27`, 위험도 응답: 성공
  - Task 4.7 미인증 개인화 급식 조회: `401 UNAUTHORIZED`: 성공
  - Task 4.7 교차 소유권 자녀 조회: `404 RESOURCE_NOT_FOUND`: 성공
  - Task 4.7 검증 데이터와 API 프로세스 정리: 완료
  - Task 4.7 `git diff --check`: 성공
  - Checkpoint 4 Java 21 `.\gradlew.bat build --no-daemon`: 성공
  - Checkpoint 4 Compose 5개 서비스 health 확인: 성공
  - Checkpoint 4 API 실제 기동 및 Flyway V1~V15 검증: 성공
  - Checkpoint 4 실제 API로 회원 1명 기준 자녀 2명 등록 및 PostgreSQL 자녀 2건 확인:
    성공
  - Checkpoint 4 첫째 자녀 알레르기 `[2]` 기준 날짜 개인화 급식:
    `200 READY`, 전체 위험도 `RISKY`, 메뉴 위험도 `RISKY`·`UNKNOWN`·`LABELING_FAILED`,
    matched allergen `[2]`: 성공
  - Checkpoint 4 둘째 자녀 알레르기 `[5]` 기준 날짜 개인화 급식:
    `200 READY`, 전체 위험도 `LABELING_FAILED`, 메뉴 위험도 `SAFE`·`UNKNOWN`·`LABELING_FAILED`,
    matched allergen 없음: 성공
  - Checkpoint 4 주간 개인화 급식:
    `200 READY`, range `2026-06-22`~`2026-06-28`, meal 1건: 성공
  - Checkpoint 4 `UNKNOWN` 및 `LABELING_FAILED` 메뉴가 모든 자녀 응답에서 `SAFE`가 아님:
    성공
  - Checkpoint 4 검증 데이터와 API 프로세스 정리: 완료
- 블로커 및 환경:
  - 기본 `java`는 Java 8을 가리킨다. Gradle 실행 전 Java 21 `JAVA_HOME` 설정 필요
  - Docker daemon 미기동 시 Compose health와 실제 Outbox 흐름 검증 불가
  - 사용자 요청에 따라 도메인 단위 테스트와 JPA 통합 테스트 코드는 작성하지 않음
- 상태 범례: `미착수` | `진행 중` | `부분 완료` | `차단됨` | `완료`

## 1. 계획 원칙

- 명세 승인 후 구현을 시작한다.
- 한 번에 다음 태스크 하나만 구현한다.
- 각 태스크는 가능한 한 5개 이하 파일 변경으로 유지한다.
- 공유 계약을 먼저 정의한 뒤 실행 모듈과 어댑터를 연결한다.
- 각 체크포인트에서 전체 빌드와 실제 서비스 흐름을 검증한다.
- 테스트 코드는 사용자가 명시적으로 요청한 경우에만 작성한다.
- 각 태스크의 `Verify`에 테스트가 적혀 있어도 기본 검증은 빌드, 실제 서비스
  기동 및 API·데이터베이스·메시지 흐름 확인으로 대체한다.
- 구현 세션 시작과 종료 시 이 문서의 `재개 스냅샷`을 갱신한다.
- 태스크를 시작하면 상태를 표시하고, 검증 명령이 통과한 뒤에만 `완료`로 변경한다.

## 2. 주요 아키텍처 결정

- 6개 Gradle 모듈과 3개 실행 애플리케이션을 사용한다.
- 도메인은 프레임워크에 독립적이며 application 포트가 infra를 역전시킨다.
- PostgreSQL을 시스템 오브 레코드로 사용한다.
- Redis는 단기 상태와 캐시에만 사용한다.
- RabbitMQ 이벤트는 Outbox를 통해 발행하고 Consumer는 멱등 처리한다.
- NEIS 원본은 MinIO, 정규화 데이터와 객체 메타데이터는 PostgreSQL에 저장한다.
- 공개 급식 조회와 회원 개인화 조회를 분리한다.

## 3. 단계별 태스크

### Phase 0. 저장소 기반

#### Task 0.1: 멀티모듈 Gradle 골격

- Status: 완료 - 공통 연결 설정 및 세 실행 애플리케이션 실제 기동 검증 통과
- Acceptance:
  - 6개 모듈이 생성되고 의존 방향이 명세와 일치한다.
  - API, Batch, Worker 애플리케이션이 독립 실행 가능하다.
- Verify:
  - `.\gradlew.bat projects`
  - `.\gradlew.bat clean test`
- Dependencies: 없음
- Scope: M

#### Task 0.2: 공통 품질 및 테스트 설정

- Status: 완료 - 루트 JUnit 5 공통 설정과 테스트 fixture·통합 테스트 분류 규칙 문서화
- Acceptance:
  - Java 21, JUnit 5 및 공통 컴파일 설정이 루트에서 관리된다.
  - 테스트 fixture 및 통합 테스트 분류 규칙이 문서화된다.
- Verify:
  - `.\gradlew.bat build`
- Dependencies: 0.1
- Scope: S

#### Task 0.3: Docker Compose 기반 인프라

- Status: 완료 - `.env.example` 기준 정적 설정, 실제 기동 및 전체 health 검증 통과
- Acceptance:
  - PostgreSQL, Redis, RabbitMQ, MinIO, Mailpit이 실행된다.
  - 영속 볼륨과 healthcheck가 정의된다.
  - 내부 서비스는 기본적으로 외부에 공개되지 않는다.
- Verify:
  - `docker compose config`
  - `docker compose up -d`
  - 컨테이너 health 확인
- Dependencies: 없음
- Scope: M

#### Checkpoint 0

- Status: 완료 - 전체 빌드, 세 실행 애플리케이션 기동, Compose health 검증 통과
- 전체 빌드 성공
- 세 실행 애플리케이션 기동
- Compose 의존성 health 확인

### Phase 1. 공통 계약과 운영 기반

#### Task 1.1: 공통 오류 및 식별자 계약

- Status: 완료 - 직접 `/error` 404와 실제 500 error dispatch 구분 및 로그 검증 통과
- Acceptance:
  - API 오류 형식, 도메인 식별자, 시간 규칙이 정의된다.
  - 오류 응답에 `traceId`가 포함된다.
- Verify:
  - 단위 테스트
- Dependencies: 0.1
- Scope: S

#### Task 1.2: Flyway 및 기본 감사 필드

- Status: 완료 - 공통 PostgreSQL 연결 설정 및 세 앱 동일 Flyway schema v3 기동 검증 통과
- Acceptance:
  - Flyway가 API, Batch, Worker에서 동일 스키마를 검증한다.
  - UTC 생성·수정 시각 규칙이 적용된다.
- Verify:
  - PostgreSQL Testcontainers 마이그레이션 테스트
- Dependencies: 0.2, 0.3
- Scope: M

#### Task 1.3: Outbox 도메인 및 저장 포트

- Status: 완료 - insert-only 저장 및 조건부 PENDING→PUBLISHED 상태 전이 검증 통과
- Acceptance:
  - Outbox 이벤트 상태와 저장 포트가 정의된다.
  - 유스케이스 트랜잭션에서 도메인 변경과 Outbox 생성이 함께 가능하다.
- Verify:
  - 도메인 및 저장 통합 테스트
- Dependencies: 1.2
- Scope: M

#### Task 1.4: RabbitMQ Outbox Publisher

- Status: 완료 - 런타임 연결, topology, confirm/return 및 실제 발행 검증 통과
- Acceptance:
  - 미발행 Outbox가 RabbitMQ로 발행되고 성공 상태로 전환된다.
  - RabbitMQ 실패 시 Outbox가 미발행 상태로 남는다.
- Verify:
  - RabbitMQ Testcontainers 통합 테스트
- Dependencies: 1.3
- Scope: M

#### Task 1.5: Consumer 멱등성 및 DLQ 기반

- Status: 완료 - Retry/DLQ 전송 confirm/return 검증 및 실패 예외 전파 검증 통과
- Acceptance:
  - 이벤트 ID 중복 소비가 한 번만 처리된다.
  - 재시도 한도 초과 이벤트가 DLQ로 이동한다.
- Verify:
  - RabbitMQ 및 PostgreSQL 통합 테스트
- Dependencies: 1.4
- Scope: M

#### Checkpoint 1

- Status: 완료 - Retry/DLQ 정상 흐름과 unroutable 전송 실패 시 원본 보존 검증 통과
- Outbox 발행 및 중복 Consumer 테스트 통과
- RabbitMQ 중단 후 복구 시 이벤트 유실 없음

### Phase 2. Identity

#### Task 2.1: User 도메인과 영속성

- Status: 완료 - 실제 PostgreSQL 저장·검색·제약과 도메인 상태 전이 검증 통과
- Acceptance:
  - 사용자 상태, 역할, 이메일 인증 상태 전이가 정의된다.
  - 암호화 이메일과 검색 해시가 저장된다.
- Verify:
  - 도메인 단위 테스트
  - JPA 통합 테스트
- Dependencies: 1.2
- Scope: M

#### Task 2.2: 회원가입 및 이메일 인증 요청

- Status: 완료 - 실제 Redis/PostgreSQL/Mailpit 흐름과 Java 21 전체 build 검증 통과
- Acceptance:
  - 중복 이메일을 방지한다.
  - 인증 토큰 해시가 Redis에 만료시간과 함께 저장된다.
  - Mailpit으로 인증 메일을 확인할 수 있다.
- Verify:
  - Redis 통합 테스트
  - Mailpit 수동 확인
- Dependencies: 2.1, 0.3
- Scope: M

#### Task 2.3: 이메일 인증 완료 및 로그인

- Status: 완료 - 실제 API 인증 완료·로그인·HttpOnly 쿠키 발급·보호 경로 인증 필터 검증 통과
- Acceptance:
  - 일회성 인증 토큰으로 계정을 활성화한다.
  - Access JWT와 Refresh Token을 HttpOnly 쿠키로 발급한다.
  - 미인증 계정의 주요 기능 접근을 차단한다.
- Verify:
  - API 통합 테스트
- Dependencies: 2.2
- Scope: M

#### Task 2.4: Refresh rotation, 로그아웃, 재사용 탐지

- Status: 완료 - 실제 API Refresh rotation·재사용 탐지·로그아웃 Redis session 제거 검증 통과
- Acceptance:
  - Refresh Token 갱신 시 기존 토큰이 폐기된다.
  - 폐기된 토큰 재사용 시 세션 체인을 무효화한다.
  - 로그아웃 시 쿠키와 Redis 세션을 제거한다.
- Verify:
  - 보안 통합 테스트
- Dependencies: 2.3
- Scope: M

#### Task 2.5: 비밀번호 재설정

- Status: 완료 - 실제 API·Redis·Mailpit 비밀번호 재설정, token 재사용 거부, 기존 Refresh Token 전체 폐기 검증 통과
- Acceptance:
  - 재설정 토큰이 해시·일회성·만료 방식으로 동작한다.
  - 비밀번호 변경 후 기존 Refresh 세션이 폐기된다.
- Verify:
  - API 및 Redis 통합 테스트
- Dependencies: 2.4
- Scope: M

#### Task 2.6: 로그인 제한, Origin·CSRF 및 인증 rate limit

- Status: 완료 - 실제 Redis 로그인 잠금, cookie CSRF 거부, 인증 API rate limit과 Java 21 전체 build 검증 통과
- Acceptance:
  - 로그인 실패 제한과 임시 잠금이 적용된다.
  - 쿠키 인증 변경 요청에 Origin·CSRF 방어가 적용된다.
  - 인증 API rate limit이 적용된다.
- Verify:
  - 보안 API 통합 테스트
- Dependencies: 2.3
- Scope: M

#### Checkpoint 2

- Status: 완료 - 실제 Compose·API·Mailpit E2E 흐름과 인증 token HttpOnly cookie 노출 규칙 검증 통과
- 회원가입부터 로그아웃·비밀번호 재설정까지 E2E API 테스트 통과
- 토큰이 응답 본문 또는 JavaScript 접근 가능 저장소에 노출되지 않음

### Phase 3. 학교와 공개 급식 조회

#### Task 3.1: Allergen 기준 데이터

- Status: 완료 - Flyway seed 19건과 실제 알레르기 목록 API 조회 검증 통과
- Acceptance:
  - NEIS 알레르기 코드와 이름이 마이그레이션 또는 seed로 관리된다.
  - 알레르기 목록 API가 제공된다.
- Verify:
  - 데이터 및 API 테스트
- Dependencies: 1.2
- Scope: S

#### Task 3.2: School 도메인 및 NEIS 학교 검색

- Status: 완료 - 실제 NEIS 학교 검색, 정규화 저장, no-data 및 입력 오류 구분 검증 통과
- Acceptance:
  - 학교 검색 결과가 정규화되어 저장된다.
  - NEIS 응답 오류와 잘못된 응답이 구분된다.
- Verify:
  - Mock NEIS 계약 테스트
- Dependencies: 1.1
- Scope: M

#### Task 3.3: MinIO 원본 객체 저장 포트와 어댑터

- Status: 완료 - 실제 MinIO 객체와 SHA-256·만료 metadata PostgreSQL 저장 검증 통과
- Acceptance:
  - 원본 payload가 해시와 함께 MinIO에 저장된다.
  - 객체 키와 만료 메타데이터가 PostgreSQL에 저장된다.
- Verify:
  - MinIO Testcontainers 통합 테스트
- Dependencies: 0.3, 1.2
- Scope: M

#### Task 3.4: Meal 및 CollectionJob 도메인

- Status: 완료 - reviewer findings 수정 후 Java 21 빌드와 실제 PostgreSQL CAS·멱등 저장 검증 통과
- Acceptance:
  - 수집 작업, 급식, 메뉴, 라벨링 상태가 정의된다.
  - 동일 학교·날짜·식사 타입 데이터가 멱등하게 갱신된다.
- Verify:
  - 도메인 및 JPA 테스트
- Dependencies: 3.1, 3.2
- Scope: M

#### Task 3.5: NEIS 급식 수집 및 정규화

- Status: 완료 - 후속 리뷰 발견사항 수정 후 충돌 응답 거부와 Java 21 clean build 검증 통과
- Acceptance:
  - NEIS 응답 원본 저장 후 급식을 정규화한다.
  - timeout, retry, backoff 및 circuit breaker를 적용한다.
  - 수집 성공·실패 및 응답 시간이 기록된다.
- Verify:
  - Mock NEIS 정상·지연·장애 테스트
- Dependencies: 3.3, 3.4
- Scope: M

#### Task 3.6: 공개 학교·급식 조회 API

- Status: 완료 - 공개 학교 단건·일간·주간 조회와 멱등 비동기 수집 실제 흐름 검증 통과
- Acceptance:
  - 비회원이 학교와 일간·주간 급식을 조회할 수 있다.
  - 저장 데이터가 없으면 멱등한 수집 작업을 만들고 `202 Accepted`와 재조회
    정보를 반환한다.
  - 처리 중인 동일 수집 작업이 있으면 중복 작업을 생성하지 않는다.
  - 개인화 위험도는 공개 응답에 포함하지 않는다.
- Verify:
  - 공개 API 통합 테스트
- Dependencies: 3.2, 3.5
- Scope: M

#### Task 3.7: 공개 조회 Redis 캐시와 중복 호출 방지

- Status: 완료 - Redis cache-first, dispatch lock, Redis 장애 fallback 실제 검증 통과
- Acceptance:
  - Redis와 PostgreSQL 순서로 완성된 데이터를 조회한다.
  - 동시 동일 요청이 수집 작업과 외부 API 호출의 중복을 제한한다.
  - Redis 장애 시 PostgreSQL과 비동기 수집 작업으로 정상 동작한다.
- Verify:
  - 동시성 및 Redis 장애 통합 테스트
- Dependencies: 3.6
- Scope: M

#### Checkpoint 3

- Status: 완료 - 실제 API 기동 후 비회원 조회, NEIS 장애 fallback, PostgreSQL·MinIO 정합성 검증 통과
- 비회원 학교 검색 및 일간·주간 급식 조회 가능
- NEIS 장애 시 저장 데이터 fallback 확인
- MinIO 원본과 PostgreSQL 정규화 데이터 확인

### Phase 4. 자녀와 개인화 위험도

#### Task 4.1: ChildProfile 소유권 모델

- Status: 완료 - ChildProfile CRUD, PostgreSQL owner-scoped 저장소, 실제 인증 API 교차 소유권 검증 통과
- Acceptance:
  - 회원이 여러 자녀를 생성·조회·수정·삭제할 수 있다.
  - 타 사용자 자녀 접근이 차단된다.
- Verify:
  - 도메인 및 API 권한 테스트
- Dependencies: 2.3, 3.2
- Scope: M

#### Task 4.2: 자녀 알레르기 관리

- Status: 완료 - owner-scoped 알레르기 교체 API, PostgreSQL 원자 저장 및 실제 API 검증 통과
- Acceptance:
  - 자녀별 알레르기 목록을 교체할 수 있다.
  - 유효하지 않은 알레르기 코드를 거부한다.
- Verify:
  - API 통합 테스트
- Dependencies: 4.1, 3.1
- Scope: S

#### Task 4.3: 자녀별 알림 설정

- Status: 완료 - owner-scoped 조회·upsert API, PostgreSQL 저장 및 실제 API 검증 통과
- Acceptance:
  - 이메일 활성화, 알림 시각, 시간대를 자녀별로 관리한다.
  - 초기 허용 시간대는 `Asia/Seoul`이다.
- Verify:
  - 도메인 및 API 테스트
- Dependencies: 4.1
- Scope: S

#### Task 4.4: 등록 학교 수집 구독

- Status: 완료 - 학교별 단일 구독, 현재 주 수집 요청, 마지막 자녀 해제 30일 유예 실제 검증 통과
- Acceptance:
  - 첫 자녀 학교 등록 시 현재 주 즉시 수집을 요청한다.
  - 동일 학교는 한 번만 정기 수집된다.
  - 마지막 자녀 삭제 후 30일 유예가 설정된다.
- Verify:
  - 유스케이스 및 JPA 통합 테스트
- Dependencies: 4.1, 1.3
- Scope: M

#### Task 4.5: NEIS 알레르기 번호 라벨링 Worker

- Status: 완료 - 실제 Worker 기동, RabbitMQ 소비, 라벨 저장, `MealLabeled` Outbox 및 중복 메시지 멱등성 검증 통과
- Acceptance:
  - NEIS 번호만 사용해 메뉴 알레르기를 저장한다.
  - 정보 없음은 `UNKNOWN`, 파싱 실패는 `LABELING_FAILED`로 처리한다.
  - 처리 완료 시 `MealLabeled` Outbox를 생성한다.
- Verify:
  - 파서 단위 테스트
  - Worker 멱등 통합 테스트
- Dependencies: 3.4, 1.5
- Scope: M

#### Task 4.6: 자녀별 위험도 계산

- Status: 완료 - 도메인 위험도 계산 계약과 Java 21 빌드·smoke 검증 통과
- Acceptance:
  - 자녀 알레르기와 메뉴 알레르기 교집합을 계산한다.
  - `UNKNOWN`과 `LABELING_FAILED`를 안전으로 반환하지 않는다.
  - 급식 변경 시 `riskVersion`이 변경된다.
- Verify:
  - 도메인 단위 테스트
- Dependencies: 4.2, 4.5
- Scope: M

#### Task 4.7: 개인화 오늘·주간 급식 API

- Status: 완료 - 인증 개인화 급식 API와 실제 소유권·위험도 조회 검증 통과
- Acceptance:
  - 오늘·날짜·주간 개인화 위험 급식을 조회할 수 있다.
  - 소유권 검증과 안전 경고가 적용된다.
- Verify:
  - API 통합 테스트
- Dependencies: 4.6
- Scope: M

#### Checkpoint 4

- Status: 완료 - 여러 자녀 등록과 개인화 위험도 조회 E2E 검증 통과
- 회원이 여러 자녀를 등록하고 개인화 위험도를 조회 가능
- 정보 없음 및 라벨링 실패가 안전으로 표시되지 않음

### Phase 5. 자동 수집과 이메일 알림

#### Task 5.1: 등록 학교 수집 Scheduler

- Status: 완료 - 활성 구독 학교 대상 날짜 수집 Scheduler 구현 및 실제 Batch 기동 검증 완료
- Acceptance:
  - 활성 구독 학교의 대상 날짜를 수집한다.
  - 중복 실행과 중복 수집을 방지한다.
  - 실패 작업을 운영 데이터로 남긴다.
- Verify:
  - Batch 통합 테스트
- Dependencies: 4.4, 3.5
- Scope: M

#### Task 5.2: 알림 대상 생성 Scheduler

- Acceptance:
  - 자녀 알림 시각과 `Asia/Seoul` 기준으로 대상자를 생성한다.
  - 위험 없음과 급식 없음 이력을 구분한다.
- Verify:
  - 시간 경계 및 중복 실행 테스트
- Dependencies: 4.3, 4.6
- Scope: M

#### Task 5.3: Notification 도메인과 중복 방지

- Acceptance:
  - 알림 상태 전이와 재시도 규칙이 정의된다.
  - 중복 키와 정정 알림 규칙이 적용된다.
- Verify:
  - 도메인 단위 테스트
- Dependencies: 4.6
- Scope: M

#### Task 5.4: Mailpit SMTP 이메일 어댑터

- Acceptance:
  - 이메일 포트를 통해 알림을 발송한다.
  - 개발 환경에서 Mailpit으로 내용을 확인할 수 있다.
  - 실패 원인이 저장된다.
- Verify:
  - SMTP 통합 테스트
- Dependencies: 0.3, 5.3
- Scope: S

#### Task 5.5: Notification Worker

- Acceptance:
  - `NotificationRequested`를 멱등하게 소비해 이메일을 발송한다.
  - 재시도 초과 시 DLQ로 이동하고 실패 이력을 남긴다.
- Verify:
  - Worker 및 RabbitMQ 통합 테스트
- Dependencies: 5.4, 1.5
- Scope: M

#### Task 5.6: 자녀별 알림 이력 API

- Acceptance:
  - 회원이 자녀별 알림 이력을 페이지네이션 조회한다.
  - 성공, 실패, 위험 없음, 급식 없음 상태를 구분한다.
- Verify:
  - API 권한 및 페이지네이션 테스트
- Dependencies: 5.3
- Scope: S

#### Checkpoint 5

- 등록 학교 자동 수집부터 Mailpit 이메일 발송까지 E2E 동작
- 중복 실행에도 이메일 중복 발송 없음
- RabbitMQ 장애 복구 후 미처리 알림 발송

### Phase 6. 관리자 및 데이터 수명주기

#### Task 6.1: 관리자 bootstrap 및 권한 승격

- Acceptance:
  - 환경변수 기반 최초 관리자 생성이 가능하다.
  - 관리자만 사용자 권한을 승격할 수 있다.
  - 모든 변경 액션이 감사 로그에 기록된다.
- Verify:
  - 권한 및 감사 로그 테스트
- Dependencies: 2.1
- Scope: M

#### Task 6.2: 수집·외부 API 실패 조회 및 재수집

- Acceptance:
  - 실패 수집과 외부 API 로그를 페이지네이션 조회한다.
  - `Idempotency-Key`를 사용해 안전하게 재수집 요청한다.
- Verify:
  - 관리자 API 통합 테스트
- Dependencies: 5.1, 6.1
- Scope: M

#### Task 6.3: 알림 실패·DLQ 조회 및 재처리

- Acceptance:
  - 실패 알림과 DLQ 이벤트를 조회한다.
  - 관리자 재처리가 멱등하고 감사 로그에 남는다.
- Verify:
  - 관리자 API 및 RabbitMQ 통합 테스트
- Dependencies: 5.5, 6.1
- Scope: M

#### Task 6.4: 관리자 대시보드 요약 API

- Acceptance:
  - 수집, 라벨링, Outbox, DLQ, 알림 성공·실패 요약을 제공한다.
  - 비싼 실시간 집계를 피하고 기준 시각을 응답한다.
- Verify:
  - 집계 API 테스트
- Dependencies: 6.2, 6.3
- Scope: M

#### Task 6.5: 회원 탈퇴 유예 및 개인정보 마스킹

- Acceptance:
  - 탈퇴 즉시 계정 비활성화와 알림 개인정보 마스킹이 적용된다.
  - 7일 이내 탈퇴 취소가 가능하다.
  - 유예 종료 후 개인정보가 삭제된다.
- Verify:
  - 시간 경계 및 삭제 통합 테스트
- Dependencies: 2.1, 4.1, 5.3
- Scope: M

#### Task 6.6: MinIO 원본 및 로그 보존 작업

- Acceptance:
  - 90일 지난 원본 객체와 메타데이터가 안전하게 삭제된다.
  - 비개인 운영 로그 1년 보존 규칙이 적용된다.
- Verify:
  - 보존 기한 통합 테스트
- Dependencies: 3.3, 5.1
- Scope: M

#### Checkpoint 6

- 관리자 실패 조회 및 재처리 가능
- 감사 로그 누락 없음
- 탈퇴 및 보존 정책 테스트 통과

### Phase 7. 공개 계약과 운영 마무리

#### Task 7.1: OpenAPI 계약 완성

- Acceptance:
  - 공개, 회원, 관리자 API와 공통 오류가 문서화된다.
  - 쿠키 인증 및 권한 요구사항이 명시된다.
- Verify:
  - OpenAPI 생성 및 계약 테스트
- Dependencies: Phase 2~6 API
- Scope: M

#### Task 7.2: Actuator 및 구조화 로그

- Acceptance:
  - liveness와 readiness가 분리된다.
  - PostgreSQL, Redis, RabbitMQ, MinIO 상태가 구분된다.
  - 로그와 오류 응답에 `traceId`가 포함된다.
- Verify:
  - health 및 로그 통합 테스트
- Dependencies: 0.3
- Scope: M

#### Task 7.3: Caddy 및 운영 Compose 구성

- Acceptance:
  - 단일 도메인에서 `/api/*`가 API로 전달된다.
  - HTTPS와 보안 쿠키 전제 설정이 문서화된다.
  - 내부 서비스 포트가 외부에 공개되지 않는다.
- Verify:
  - `docker compose config`
  - 프록시 수동 확인
- Dependencies: 0.3, 2.3
- Scope: M

#### Task 7.4: 운영 문서와 장애 복구 절차

- Acceptance:
  - 실행, 백업, 복구, 비밀값, DLQ 재처리, MinIO 보존 절차가 문서화된다.
  - 알려진 한계와 후속 릴리스 범위가 명시된다.
- Verify:
  - 문서 명령을 깨끗한 환경에서 실행
- Dependencies: 7.2, 7.3
- Scope: M

#### Final Checkpoint

- `.\gradlew.bat clean test`
- `.\gradlew.bat build`
- `docker compose config`
- 공개 급식 조회 E2E
- 회원가입·인증·자녀·위험 조회 E2E
- 자동 수집·라벨링·이메일 알림 E2E
- 관리자 실패 조회·재처리 E2E
- Redis 및 RabbitMQ 장애 복구 검증
- 보안 및 데이터 보존 체크리스트 승인

## 4. 병렬화 가능 영역

- 공통 계약 확정 후 Identity와 School 기본 모델은 병렬 구현 가능하다.
- 공개 급식 API 계약 확정 후 프론트엔드는 별도 저장소에서 Mock 기반 개발 가능하다.
- Notification 도메인 확정 후 SMTP 어댑터와 알림 이력 API는 병렬 구현 가능하다.
- 관리자 조회 API는 해당 운영 데이터가 생성된 후 병렬 구현 가능하다.

현재 실행 순서는 다음과 같다.

- Task 3.1~3.3이 먼저 완료되었으므로 NEIS 작업 컨텍스트를 유지해 Task
  3.4~3.7과 Checkpoint 3까지 연속 진행한다.
- Checkpoint 3 완료 직후 Identity로 복귀해 Task 2.2~2.6과 Checkpoint 2를
  완료한다.
- Checkpoint 2와 Checkpoint 3이 모두 완료된 뒤 Phase 4를 시작한다.
- 이 순서는 Phase 번호보다 의존성, 수직 기능 완성, 컨텍스트 전환 비용을
  우선한 것이다. Task 2 범위를 생략하거나 후속 릴리스로 미루는 결정이 아니다.

다음 항목은 순차 진행해야 한다.

- 멀티모듈 골격 -> 공통 설정
- Outbox 모델 -> Publisher -> Consumer 멱등성
- NEIS 원본 저장 -> 정규화 -> 공개 조회
- 자녀 알레르기 -> 위험 계산 -> 개인화 조회 -> 알림

## 5. 주요 위험과 완화

| 위험 | 영향 | 완화 |
|---|---|---|
| Spring Boot 4와 서드파티 호환성 | 빌드 및 런타임 장애 | 도입 태스크마다 공식 호환성 확인 후 버전 고정 |
| NEIS 응답 형식 변경 및 불완전 데이터 | 잘못된 급식·알레르기 표시 | 경계 검증, 원본 보존, 실패 상태, 재처리 |
| 알레르기 정보 오해 | 사용자 안전 위험 | NEIS 번호만 사용, UNKNOWN 경고, 의료 면책 고지 |
| 이벤트 중복 및 순서 역전 | 중복 알림·상태 회귀 | Outbox, 이벤트 ID 멱등성, riskVersion |
| RabbitMQ 또는 Redis 장애 | 처리 지연 | PostgreSQL 원본 보존, 복구 후 재처리, Redis fallback |
| 6개 모듈의 과도한 복잡성 | 개발 속도 저하 | 명시적 의존 방향, 작은 태스크, 경계 없는 추상화 금지 |
| 공개 조회의 외부 API 과호출 | NEIS 제한 및 지연 | Redis·DB 캐시, rate limit, 동시 호출 방지 |

## 6. 후속 릴리스

- 웹푸시 구독 및 발송
- 주간 요약 알림
- Prometheus, Grafana, Loki
- k6 부하 테스트와 용량 계획
- AWS SQS 및 S3 어댑터
- 관리자 고급 운영 지표

## 7. 승인 게이트

이 계획을 승인한 뒤 `Task 0.1: 멀티모듈 Gradle 골격`부터 한 태스크씩
구현한다. 범위나 아키텍처 결정이 변경되면 명세와 계획을 먼저 갱신한다.
