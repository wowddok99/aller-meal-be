---
name: agent-guidelines-packager
description: 저장소의 AGENTS.md, .agents/, .codex/ 파일을 모아 버전이 붙은 AI Agent Guidelines zip 묶음을 생성한다. 사용자가 에이전트 지침 파일을 패키징, 내보내기, 아카이브, 버전 관리하거나 ai-agent-guidelines-vYYYY.MM.DD.zip 파일 생성을 요청할 때 사용한다.
---

# 에이전트 지침 패키저

## 작업 흐름

이 Skill의 `scripts/package_guidelines.py`를 사용한다.

기본 동작:

- 대상 저장소 루트에서 실행한다.
- 아래 항목만 포함한다.
  - `AGENTS.md`
  - `.agents/`
  - `.codex/`
- `ai-agent-guidelines-vYYYY.MM.DD.zip` 파일을 저장소 루트에 생성한다.
- 같은 파일명이 이미 있으면 `ai-agent-guidelines-vYYYY.MM.DD-r1.zip`, `-r2` 순서로 생성한다.
- 로컬 노이즈 파일은 제외한다: `.DS_Store`, `__pycache__/`, `.pytest_cache/`, `.gradle/`, `build/`, `.git/`.

## 명령

오늘 날짜 묶음 생성:

```bash
python3 .agents/skills/agent-guidelines-packager/scripts/package_guidelines.py
```

특정 날짜 묶음 생성:

```bash
python3 .agents/skills/agent-guidelines-packager/scripts/package_guidelines.py --date 2026.06.15
```

다른 디렉터리에 생성:

```bash
python3 .agents/skills/agent-guidelines-packager/scripts/package_guidelines.py --output-dir /tmp
```

revision을 지정하고 기존 파일 덮어쓰기:

```bash
python3 .agents/skills/agent-guidelines-packager/scripts/package_guidelines.py --revision r1 --overwrite
```

## 결과 보고

실행 후 아래 항목을 보고한다.

- 생성된 zip 경로
- 버전 문자열
- 포함된 최상위 항목
- 누락된 필수 경로

필수 경로가 누락되면 중단하고 어떤 경로가 없는지 사용자에게 알린다. 사용자가 명시적으로 요청하지 않은 한 부분 archive는 만들지 않는다.
