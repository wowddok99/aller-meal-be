#!/usr/bin/env python3
"""버전이 붙은 AI Agent Guidelines zip 묶음을 생성한다."""

from __future__ import annotations

import argparse
import datetime as dt
import os
from pathlib import Path
import sys
import zipfile


REQUIRED_PATHS = ("AGENTS.md", ".agents", ".codex")
EXCLUDED_DIR_NAMES = {".git", ".gradle", "build", "__pycache__", ".pytest_cache"}
EXCLUDED_FILE_NAMES = {".DS_Store"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="AGENTS.md, .agents/, .codex/를 버전 zip 파일로 묶습니다."
    )
    parser.add_argument(
        "--root",
        default=".",
        help="AGENTS.md, .agents/, .codex/가 있는 저장소 루트. 기본값: 현재 디렉터리.",
    )
    parser.add_argument(
        "--date",
        help="버전 날짜. 형식: YYYY.MM.DD. 기본값: 현재 로컬 날짜.",
    )
    parser.add_argument(
        "--revision",
        help="r1 같은 revision suffix. 기본값: 없음. 파일명이 있으면 자동 증가.",
    )
    parser.add_argument(
        "--output-dir",
        default=".",
        help="zip 파일을 생성할 디렉터리. 기본값: 저장소 루트.",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="파일명 자동 증가 대신 선택된 파일명을 덮어씁니다.",
    )
    return parser.parse_args()


def version_date(raw: str | None) -> str:
    if raw is None:
        return dt.datetime.now().strftime("%Y.%m.%d")

    try:
        dt.datetime.strptime(raw, "%Y.%m.%d")
    except ValueError as exc:
        raise SystemExit("--date는 YYYY.MM.DD 형식을 사용해야 합니다.") from exc

    return raw


def build_filename(date_value: str, revision: str | None) -> str:
    suffix = f"-{revision}" if revision else ""
    return f"ai-agent-guidelines-v{date_value}{suffix}.zip"


def choose_output_path(
    output_dir: Path, date_value: str, revision: str | None, overwrite: bool
) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)

    selected = output_dir / build_filename(date_value, revision)
    if overwrite or not selected.exists():
        return selected

    if revision:
        raise SystemExit(f"출력 파일이 이미 있습니다: {selected}")

    index = 1
    while True:
        candidate = output_dir / build_filename(date_value, f"r{index}")
        if not candidate.exists():
            return candidate
        index += 1


def validate_required(root: Path) -> None:
    missing = [name for name in REQUIRED_PATHS if not (root / name).exists()]
    if missing:
        joined = ", ".join(missing)
        raise SystemExit(f"필수 경로가 없습니다: {joined}")


def should_skip(path: Path) -> bool:
    if path.name in EXCLUDED_FILE_NAMES:
        return True
    return any(part in EXCLUDED_DIR_NAMES for part in path.parts)


def add_file(archive: zipfile.ZipFile, file_path: Path, root: Path) -> None:
    if should_skip(file_path.relative_to(root)):
        return
    archive.write(file_path, file_path.relative_to(root).as_posix())


def add_directory(archive: zipfile.ZipFile, directory: Path, root: Path) -> None:
    for current_root, dirs, files in os.walk(directory):
        current = Path(current_root)
        dirs[:] = [
            name
            for name in dirs
            if not should_skip((current / name).relative_to(root))
        ]
        for file_name in sorted(files):
            add_file(archive, current / file_name, root)


def create_archive(root: Path, output_path: Path) -> int:
    file_count = 0
    with zipfile.ZipFile(output_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name in REQUIRED_PATHS:
            source = root / name
            before = len(archive.namelist())
            if source.is_file():
                add_file(archive, source, root)
            else:
                add_directory(archive, source, root)
            file_count += len(archive.namelist()) - before
    return file_count


def main() -> int:
    args = parse_args()
    root = Path(args.root).resolve()
    output_dir = Path(args.output_dir)
    if not output_dir.is_absolute():
        output_dir = root / output_dir
    output_dir = output_dir.resolve()

    validate_required(root)

    date_value = version_date(args.date)
    output_path = choose_output_path(
        output_dir=output_dir,
        date_value=date_value,
        revision=args.revision,
        overwrite=args.overwrite,
    )
    file_count = create_archive(root, output_path)

    print(f"created={output_path}")
    print(f"version=v{date_value}")
    print(f"files={file_count}")
    print("included=AGENTS.md,.agents,.codex")
    return 0


if __name__ == "__main__":
    sys.exit(main())
