#!/usr/bin/env python3
"""생성된 AI Agent Guidelines zip을 GitHub Wiki에 게시한다."""

from __future__ import annotations

import argparse
import datetime as dt
from pathlib import Path
import re
import shutil
import subprocess
import sys


DEFAULT_WIKI_URL = "https://github.com/wowddok99/aller-meal-be.wiki.git"
DEFAULT_WIKI_DIR = Path(".codex/tmp/aller-meal-be.wiki")
DEFAULT_PAGE = "AI-Agent-Guidelines.md"
ZIP_PATTERN = re.compile(r"^ai-agent-guidelines-(v\d{4}\.\d{2}\.\d{2}(?:-r\d+)?)\.zip$")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="AI Agent Guidelines zip을 GitHub Wiki 페이지에 반영합니다."
    )
    parser.add_argument("--root", default=".", help="프로젝트 루트. 기본값: 현재 디렉터리.")
    parser.add_argument("--zip", dest="zip_path", help="게시할 zip 경로. 생략 시 최신 zip 자동 선택.")
    parser.add_argument("--wiki-url", default=DEFAULT_WIKI_URL, help="GitHub Wiki git URL.")
    parser.add_argument("--wiki-dir", default=str(DEFAULT_WIKI_DIR), help="Wiki repo clone 디렉터리.")
    parser.add_argument("--page", default=DEFAULT_PAGE, help="갱신할 Wiki Markdown 파일명.")
    parser.add_argument("--push", action="store_true", help="commit 후 원격 Wiki repo에 push합니다.")
    parser.add_argument("--no-commit", action="store_true", help="파일만 갱신하고 commit하지 않습니다.")
    return parser.parse_args()


def run(command: list[str], cwd: Path | None = None) -> str:
    completed = subprocess.run(
        command,
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    if completed.returncode != 0:
        joined = " ".join(command)
        raise SystemExit(f"명령 실패: {joined}\n{completed.stdout}")
    return completed.stdout.strip()


def resolve_zip(root: Path, raw_zip: str | None) -> Path:
    if raw_zip:
        candidate = Path(raw_zip)
        if not candidate.is_absolute():
            candidate = root / candidate
        candidate = candidate.resolve()
        validate_zip(candidate)
        return candidate

    candidates = sorted(
        (path for path in root.glob("ai-agent-guidelines-v*.zip") if ZIP_PATTERN.match(path.name)),
        key=lambda path: path.stat().st_mtime,
        reverse=True,
    )
    if not candidates:
        raise SystemExit("게시할 ai-agent-guidelines-v*.zip 파일을 찾지 못했습니다.")
    validate_zip(candidates[0])
    return candidates[0].resolve()


def validate_zip(zip_path: Path) -> None:
    if not zip_path.exists() or not zip_path.is_file():
        raise SystemExit(f"zip 파일이 없습니다: {zip_path}")
    if not ZIP_PATTERN.match(zip_path.name):
        raise SystemExit(f"zip 파일명이 형식과 다릅니다: {zip_path.name}")


def ensure_wiki_repo(wiki_url: str, wiki_dir: Path) -> None:
    if (wiki_dir / ".git").exists():
        run(["git", "pull", "--ff-only"], cwd=wiki_dir)
        return
    wiki_dir.parent.mkdir(parents=True, exist_ok=True)
    if wiki_dir.exists() and any(wiki_dir.iterdir()):
        raise SystemExit(f"Wiki 디렉터리가 비어 있지 않습니다: {wiki_dir}")
    run(["git", "clone", wiki_url, str(wiki_dir)])


def initial_page(version: str, zip_name: str) -> str:
    today = dt.datetime.now().strftime("%Y-%m-%d")
    return "\n".join(
        [
            "# AI Agent Guidelines",
            "",
            "## Latest",
            "",
            f"- [{zip_name}]({zip_name})",
            "",
            "## Versions",
            "",
            "| Version | Date | File |",
            "|---|---|---|",
            version_row(version, zip_name, today),
            "",
        ]
    )


def update_page(page_path: Path, version: str, zip_name: str) -> None:
    if not page_path.exists():
        page_path.write_text(initial_page(version, zip_name), encoding="utf-8")
        return

    text = page_path.read_text(encoding="utf-8")
    text = remove_stray_generated_table(text)
    text = update_latest(text, zip_name)
    text = update_versions(text, version, zip_name)
    page_path.write_text(text, encoding="utf-8")


def update_latest(text: str, zip_name: str) -> str:
    latest = f"## Latest\n\n- [{zip_name}]({zip_name})"
    pattern = re.compile(r"## Latest\n.*?(?=\n## |\Z)", re.DOTALL)
    if pattern.search(text):
        return pattern.sub(latest + "\n", text)
    return text.rstrip() + "\n\n" + latest + "\n"


def update_versions(text: str, version: str, zip_name: str) -> str:
    today = dt.datetime.now().strftime("%Y-%m-%d")
    row = version_row(version, zip_name, today)
    versions_section = section_text(text, "## Versions")
    if f"| {version} |" in versions_section:
        return text

    header = "## Versions"
    table_header = "| Version | Date | File |\n|---|---|---|"
    if header not in text:
        return text.rstrip() + "\n\n" + header + "\n\n" + table_header + "\n" + row + "\n"

    lines = text.splitlines()
    for index in range(len(lines) - 1):
        normalized_header = lines[index].replace(" ", "").strip()
        normalized_separator = lines[index + 1].replace(" ", "").strip()
        if normalized_header in {"|Version|Date|File|", "|Version|File|Published|"} and normalized_separator == "|---|---|---|":
            lines.insert(index + 2, row)
            return "\n".join(lines).rstrip() + "\n"

    return text.rstrip() + "\n\n" + table_header + "\n" + row + "\n"


def version_row(version: str, zip_name: str, date_value: str) -> str:
    return f"| {version} | {date_value} | [Download]({zip_name}) |"


def section_text(text: str, heading: str) -> str:
    pattern = re.compile(rf"{re.escape(heading)}\n.*?(?=\n## |\Z)", re.DOTALL)
    match = pattern.search(text)
    return match.group(0) if match else ""


def remove_stray_generated_table(text: str) -> str:
    pattern = re.compile(
        r"\n\| Version \| File \| Published \|\n\|---\|---\|---\|\n"
        r"(?:\| v\d{4}\.\d{2}\.\d{2}(?:-r\d+)? \| .*? \| \d{4}-\d{2}-\d{2} \|\n?)+",
        re.DOTALL,
    )
    return pattern.sub("\n", text)


def has_changes(wiki_dir: Path) -> bool:
    return bool(run(["git", "status", "--porcelain"], cwd=wiki_dir))


def commit_changes(wiki_dir: Path, version: str) -> str:
    run(["git", "add", "."], cwd=wiki_dir)
    run(["git", "commit", "-m", f"docs: AI Agent Guidelines {version} 게시"], cwd=wiki_dir)
    return run(["git", "rev-parse", "--short", "HEAD"], cwd=wiki_dir)


def main() -> int:
    args = parse_args()
    if args.push and args.no_commit:
        raise SystemExit("--push와 --no-commit은 함께 사용할 수 없습니다.")

    root = Path(args.root).resolve()
    wiki_dir = Path(args.wiki_dir)
    if not wiki_dir.is_absolute():
        wiki_dir = root / wiki_dir
    wiki_dir = wiki_dir.resolve()

    zip_path = resolve_zip(root, args.zip_path)
    match = ZIP_PATTERN.match(zip_path.name)
    assert match is not None
    version = match.group(1)

    ensure_wiki_repo(args.wiki_url, wiki_dir)
    shutil.copy2(zip_path, wiki_dir / zip_path.name)
    page_path = wiki_dir / args.page
    update_page(page_path, version, zip_path.name)

    commit_hash = "none"
    if has_changes(wiki_dir):
        if not args.no_commit:
            commit_hash = commit_changes(wiki_dir, version)
    else:
        commit_hash = "unchanged"

    pushed = "skipped"
    if args.push:
        run(["git", "push"], cwd=wiki_dir)
        pushed = "done"

    print(f"zip={zip_path}")
    print(f"wiki_dir={wiki_dir}")
    print(f"page={page_path}")
    print(f"version={version}")
    print(f"commit={commit_hash}")
    print(f"push={pushed}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
