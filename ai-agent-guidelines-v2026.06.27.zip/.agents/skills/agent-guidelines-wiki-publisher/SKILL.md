---
name: agent-guidelines-wiki-publisher
description: 생성된 AI Agent Guidelines zip 파일을 GitHub Wiki의 AI-Agent-Guidelines 페이지에 반영하고 선택적으로 commit/push한다. 사용자가 agent-guidelines-packager 결과물을 Wiki에 올리기, Wiki 페이지 자동 갱신, AI-Agent-Guidelines.md 버전 표 업데이트, aller-meal-be.wiki.git push 자동화를 요청할 때 사용한다.
---

# Agent Guidelines Wiki Publisher

## 역할

이 Skill은 이미 생성된 `ai-agent-guidelines-vYYYY.MM.DD*.zip` 파일을 GitHub Wiki 저장소에 게시한다.

`agent-guidelines-packager`와 분리한다.

- packager: zip 생성만 담당
- wiki publisher: 생성된 zip을 Wiki repo에 복사하고 Wiki Markdown 갱신·commit·선택 push 담당

## 기본 명령

최신 zip을 찾아 Wiki repo에 반영하고 local commit까지 생성:

```powershell
python .agents/skills/agent-guidelines-wiki-publisher/scripts/publish_guidelines_wiki.py
```

특정 zip 지정:

```powershell
python .agents/skills/agent-guidelines-wiki-publisher/scripts/publish_guidelines_wiki.py --zip ai-agent-guidelines-v2026.06.27.zip
```

원격 Wiki까지 push:

```powershell
python .agents/skills/agent-guidelines-wiki-publisher/scripts/publish_guidelines_wiki.py --push
```

commit 없이 파일만 갱신:

```powershell
python .agents/skills/agent-guidelines-wiki-publisher/scripts/publish_guidelines_wiki.py --no-commit
```

## 동작

스크립트는 다음을 수행한다.

1. 대상 zip을 확인한다. `--zip`이 없으면 저장소 루트의 최신 `ai-agent-guidelines-v*.zip`을 선택한다.
2. Wiki repo를 `.codex/tmp/aller-meal-be.wiki`에 clone한다. 이미 있으면 `git pull --ff-only` 한다.
3. zip을 Wiki repo 루트로 복사한다.
4. `AI-Agent-Guidelines.md`의 `Latest`와 `Versions` 섹션을 갱신한다.
5. 변경이 있으면 commit한다.
6. `--push`가 있으면 `git push` 한다.

## 주의

- GitHub Wiki remote 기본값은 `https://github.com/wowddok99/aller-meal-be.wiki.git`이다.
- `--push`는 로컬 GitHub credential이 push 가능한 상태일 때만 성공한다.
- `.codex/tmp/` 아래의 Wiki clone은 작업용 cache다. 프로젝트 코드나 packager 결과를 수정하지 않는다.
- `.codex/`와 생성 zip은 로컬 전용이다. 본 저장소 staging에 포함하지 않는다.

## 결과 보고

실행 후 아래 항목을 보고한다.

- 사용한 zip 경로
- Wiki working directory
- 갱신한 page
- commit hash 또는 변경 없음
- push 실행 여부와 결과
